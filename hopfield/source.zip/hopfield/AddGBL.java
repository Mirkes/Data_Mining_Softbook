package hopfield;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.Insets;

import java.awt.event.ItemListener;

import java.util.Enumeration;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 * Service library for simplicity of interface construction.
 * 
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 **/
public class AddGBL {
    private static Insets insets = new Insets(5, 5, 5, 5);
    private static int hDir = GridBagConstraints.CENTER;

    /**
     * @param ins new insets to use
     */
    public static void setInsets(Insets ins) {
        insets = ins;
    }

    /**
     * Set standard insets.
     */
    public static void stdInsets() {
        insets = new Insets(5, 5, 5, 5);
    }

    /**
     * @param dir new direction to use
     */
    public static void setHDir(int dir) {
        hDir = dir;
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     */
    public static void addGBL(Container pan, Component com, int col, int row) {
        pan.add(com, new GridBagConstraints(col, row, 1, 1, 0, 0, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param hDir direction for adding component
     */
    public static void addGBL(Container pan, Component com, int col, int row, int hDir) {
        pan.add(com, new GridBagConstraints(col, row, 1, 1, 0, 0, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param width number of rows for component
     * @param height number of columns for component
     * @param hDir direction for adding component
     */
    public static void addGBL(Container pan, Component com, int col, int row, int width, int height, int hDir) {
        pan.add(com,
                new GridBagConstraints(col, row, width, height, 0, 0, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param width number of rows for component
     * @param height number of columns for component
     */
    public static void addGBL(Container pan, Component com, int col, int row, int width, int height) {
        pan.add(com,
                new GridBagConstraints(col, row, width, height, 0, 0, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param exp expansion for hte adding component
     */
    public static void addGBLExp(Container pan, Component com, int col, int row, int exp) {
        pan.add(com, new GridBagConstraints(col, row, 1, 1, 0, 0, hDir, exp, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param width number of rows for component
     * @param height number of columns for component
     * @param exp expansion for hte adding component
     */
    public static void addGBLExp(Container pan, Component com, int col, int row, int width, int height, int exp) {
        pan.add(com, new GridBagConstraints(col, row, width, height, 0, 0, hDir, exp, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param width number of rows for component
     * @param height number of columns for component
     * @param dx proportion for horizontal expansion
     * @param dy proportion for vertical expansion
     * @param exp expansion for hte adding component
     */
    public static void addGBLExps(Container pan, Component com, int col, int row, int width, int height, int dx,
                                  int dy, int exp) {
        pan.add(com, new GridBagConstraints(col, row, width, height, dx, dy, hDir, exp, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param width number of rows for component
     * @param height number of columns for component
     * @param dx proportion for horizontal expansion
     * @param dy proportion for vertical expansion
     */
    public static void addGBLExps(Container pan, Component com, int col, int row, int width, int height, int dx,
                                  int dy) {
        pan.add(com,
                new GridBagConstraints(col, row, width, height, dx, dy, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param dx proportion for horizontal expansion
     * @param dy proportion for vertical expansion
     * @param exp expansion for the adding component
     */
    public static void addGBLExps(Container pan, Component com, int col, int row, int dx, int dy, int exp) {
        pan.add(com, new GridBagConstraints(col, row, 1, 1, dx, dy, hDir, exp, insets, 0, 0));
    }

    /**
     * @param pan panel to which component would be added
     * @param com component to add
     * @param col column to add component
     * @param row row to add component
     * @param dx proportion for horizontal expansion
     * @param dy proportion for vertical expansion
     */
    public static void addGBLExps(Container pan, Component com, int col, int row, int dx, int dy) {
        pan.add(com, new GridBagConstraints(col, row, 1, 1, dx, dy, hDir, GridBagConstraints.NONE, insets, 0, 0));
    }

    /**
     * @param pan JPanel to enabled/disabled components
     * @param enb true to enabled and false to disabled
     */
    public static void setChildEnabled(JPanel pan, boolean enb) {
        int n = pan.getComponentCount();
        for (int i = 0; i < n; i++) {
            pan.getComponent(i).setEnabled(enb);
        }
    }

    /**
     * @param com component to set sizes
     * @param width
     * @param height
     */
    public static void setAllSizes(Component com, int width, int height) {
        Dimension d = new Dimension(width, height);
        setAllSizes(com, d);
    }

    /**
     * @param com component to set sizes
     * @param d - new sizes
     */
    public static void setAllSizes(Component com, Dimension d) {
        com.setSize(d);
        com.setMaximumSize(d);
        com.setMinimumSize(d);
        com.setPreferredSize(d);
    }

    /**
     * @param title of radio buttons group border
     * @return new panel with border. Direction is vertical
     */
    public static JPanel createRadioButtons(String title) {
        return createRadioButtons(title, BoxLayout.Y_AXIS);
    }


    /**
     * @param title of radio buttons group border
     * @param direction direction to add buttons
     * @return  new panel with border
     */
    public static JPanel createRadioButtons(String title, int direction) {
        JPanel pan = new JPanel();
        pan.setLayout(new BoxLayout(pan, direction));
        pan.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), title));
        return pan;
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param comand action command of button
     * @param sel true if this button is selected
     * @param l - ItemListener to work with events
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, String comand, boolean sel,
                                      ItemListener l) {
        JRadioButton rb = new JRadioButton(title, sel);
        rb.addItemListener(l);
        rb.setActionCommand(comand);
        bg.add(rb);
        pan.add(rb);
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param comand action command of button
     * @param l - ItemListener to work with events
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, String comand, ItemListener l) {
        addRadioButton(pan, bg, title, comand, false, l);
    }


    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param sel true if this button is selected
     * @param l - ItemListener to work with events
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, boolean sel, ItemListener l) {
        addRadioButton(pan, bg, title, title, sel, l);
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param l - ItemListener to work with events
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, ItemListener l) {
        addRadioButton(pan, bg, title, title, false, l);
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param comand action command of button
     * @param sel true if this button is selected
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, String comand, boolean sel) {
        JRadioButton rb = new JRadioButton(title, sel);
        rb.setActionCommand(comand);
        bg.add(rb);
        pan.add(rb);
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param comand action command of button
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, String comand) {
        addRadioButton(pan, bg, title, comand, false);
    }


    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     * @param sel true if this button is selected
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title, boolean sel) {
        addRadioButton(pan, bg, title, title, sel);
    }

    /**
     * @param pan JPanel to add radio button
     * @param bg ButtonGroup to add radio button
     * @param title text of button
     */
    public static void addRadioButton(JPanel pan, ButtonGroup bg, String title) {
        addRadioButton(pan, bg, title, title, false);
    }

    /**
     * Create the radiobuttons group with numerical actions commands.
     * @param title is title of frame
     * @param bg is button group
     * @param names is array of names for buttons
     * @return JPanel with frame and radiobuttons
     */
    public static JPanel createRadioButtonGroup(String title, ButtonGroup bg, String[] names) {
        return createRadioButtonGroup(title, bg, BoxLayout.Y_AXIS, names);
    }

    /**
     * Create the radiobuttons group with numerical actions commands.
     * @param title is title of frame
     * @param bg is button group
     * @param dir is direction
     * @param names is array of names for buttons
     * @return JPanel with frame and radiobuttons
     */
    public static JPanel createRadioButtonGroup(String title, ButtonGroup bg, int dir, String[] names) {
        JPanel pan = createRadioButtons(title, dir);
        for (int i = 0; i < names.length; i++)
            addRadioButton(pan, bg, names[i], "" + i, true);
        return pan;
    }

    /**
     * Set selected button with action command equals name.
     * @param bg is button grout to set selected button in.
     * @param name is the action command of button to set selected
     * @return true if selection set and false otherwise
     */
    public static boolean setSelected(ButtonGroup bg, String name) {
        Enumeration e = bg.getElements();
        AbstractButton ab;
        while (e.hasMoreElements()) {
            ab = (AbstractButton)e.nextElement();
            if (ab.getActionCommand().equals(name)) {
                bg.clearSelection();
                bg.setSelected(ab.getModel(), true);
                return true;
            }
        }
        return false;
    }

    /**
     * Add ItemListener for each button in button group.
     * @param bg is ButtonGroup to add listener
     * @param cl is listener to add
     */
    public static void addItemListener(ButtonGroup bg, ItemListener cl) {
        Enumeration e = bg.getElements();
        AbstractButton ab;
        while (e.hasMoreElements()) {
            ab = (AbstractButton)e.nextElement();
            ab.addItemListener(cl);
        }
    }
}
