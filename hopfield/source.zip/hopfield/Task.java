package hopfield;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Task extends JPanel implements FocusListener {
    @SuppressWarnings("compatibility:6665259291137532111")
    private static final long serialVersionUID = -8194530427145934157L;

    //Static data for all Tasks
    protected static int imSize = 10;
    protected static int cellSize = 10;
    protected static Network net = null;
    protected transient CompOwner owner = null;

    // Data arrays
    TaskPane input, output;
    JLabel dist = new JLabel();

    /**
     * @param data is input data for new Task
     */
    protected Task(boolean[] data) {
        input = new TaskPane(data);
        boolean[] tmp = new boolean[data.length];
        int dists = -1;
        if (net != null)
            dists = net.testTask(input.data, tmp);
        output = new TaskPane(tmp);
        this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        add(input);
        add(Box.createHorizontalStrut(5));
        add(output);
        add(Box.createHorizontalStrut(5));
        dist.setText("100");
        dist.doLayout();
        Dimension d = dist.getPreferredSize();
        dist.setText("" + dists);
        Utils.settAllSizes(dist, d);
        add(dist);
        setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.RED));
        doLayout();
        d = getPreferredSize();
        //        d.height+=5;
        Utils.settAllSizes(this, d);
        setFocusable(true);
        requestFocusInWindow();
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                requestFocusInWindow();
                if (e.getButton()==MouseEvent.BUTTON1 && e.getClickCount()>1)
                    editTask();
            }
        });
        addFocusListener(this);
    }

    /**
     * @param newNet is network to use for testing
     */
    protected static final void setNetwork(Network newNet) {
        net = newNet;
    }

    /**
     * @param newSize is new size of image to use
     */
    protected static final void setImageSize(int newSize) {
        if (imSize == newSize)
            return;
        //Calculate new sizes
        imSize = newSize;
        cellSize = 100 / imSize;
        if (cellSize < 1)
            cellSize = 1;
    }

    /**
     * @param newOwner is new owner to register active component
     */
    protected final void setOwner(CompOwner newOwner) {
        owner = newOwner;
    }

    /**
     * @return is new task to add or null
     */
    protected static final Task addTask() {
        boolean[] inputs = new boolean[imSize * imSize];
        Editor.Answer ans = Editor.showDialog(imSize, inputs);
        if (ans.outcome > 1)
            return null;
        return new Task(ans.data);
    }

    protected final void editTask() {
        Editor.Answer ans = Editor.showDialog(imSize, input.data);
        if (ans.outcome > 1)
            return;
        if (ans.outcome == 0) {
            System.arraycopy(ans.data, 0, input.data, 0, imSize * imSize);
            int dists = net.testTask(input.data, output.data);
            dist.setText("" + dists);
            repaint();
        } else
            owner.setTask(new Task(ans.data));
    }
    
    protected final void testTask(){
        dist.setText("" + net.testTask(input.data, output.data));
    }

    /**
     * @param e is event to handle
     */
    @Override
    public void focusGained(FocusEvent e) {
        setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLUE));
        if (owner != null)
            owner.setActive(this);
    }

    /**
     * @param e is event to handle
     */
    @Override
    public void focusLost(FocusEvent e) {
        setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
    }


    protected static class TaskPane extends JPanel {
        @SuppressWarnings("compatibility:1506405346613862791")
        private static final long serialVersionUID = -8194530427145934157L;

        // Data arrays
        final boolean[] data;

        /**
         * @param dat are data for new TaskPane
         */
        protected TaskPane(boolean[] dat) {
            data = dat;
            setLayout(null);
            setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
            Utils.settAllSizes(this, imSize * cellSize + 6, imSize * cellSize + 6);
        }

        /**
         * @param g is Graphics to draw
         */
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            for (int y = 0; y < imSize; y++)
                for (int x = 0; x < imSize; x++) {
                    if (data[y * imSize + x])
                        g.setColor(Color.BLACK);
                    else
                        g.setColor(Color.WHITE);
                    g.fillRect(x * cellSize + 3, y * cellSize + 3, cellSize, cellSize);
                }
        }
    }
}
