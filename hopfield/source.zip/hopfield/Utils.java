package hopfield;

import java.awt.Dimension;
import java.awt.Toolkit;

import java.io.IOException;

import java.util.Random;

import javax.swing.JComponent;
import javax.swing.JDialog;

public class Utils {

    protected static final Random rnd = new Random();

    /**
     * @param dial is dialog to adjust size.
     */
    public static final void adjustSize(JDialog dial) {
        dial.pack();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = dial.getSize();
        if (frameSize.height > screenSize.height * 8 / 10) {
            frameSize.height = screenSize.height * 8 / 10;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        dial.setPreferredSize(frameSize);
        dial.setSize(frameSize);
        dial.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    }

    /**
     * Set all possible sizes of component.
     * @param comp is component to set sizes
     * @param w is width to set
     * @param h is heght to set
     */
    public static final void settAllSizes(JComponent comp, int w, int h) {
        settAllSizes(comp, new Dimension(w, h));
    }

    /**
     * Set all possible sizes of component.
     * @param comp is component to set sizes
     * @param d is Dimension to set
     */
    public static final void settAllSizes(JComponent comp, Dimension d) {
        comp.setMaximumSize(d);
        comp.setSize(d);
        comp.setMinimumSize(d);
        comp.setPreferredSize(d);
    }

    /**
     * Convert zero/one string to array of boolean.
     * @param n is size of image
     * @param str is String representation of image
     * @param count is string number for messages
     * @return arra of boolean
     * @throws IOException
     */
    public static final boolean[] imageDecode(int n, final String str, int count) throws IOException {
        boolean[] b = null;
        if (str == null)
            return b;
        int p = str.indexOf(' ');
        String line;
        if (p==-1)
            line = str;
        else
            line = str.substring(0, p);
        if (n != line.length())
            throw new IOException("Wrong length of string in row " + count);
        b = new boolean[n];
        for (int i = 0; i < n; i++)
            switch (line.charAt(i)) {
            case '0':
                b[i] = false;
                break;
            case '1':
                b[i] = true;
                break;
            default:
                throw new IOException("Wrong symbol in position " + (i + 1) + " of row " + count);
            }
        return b;
    }

    /**
     * Convert boolean representation of image into String representeation.
     * @param data is array of boolean
     * @return String representation of image.
     */
    public static final String imageEncode(boolean[] data) {
        StringBuilder sb = new StringBuilder(data.length);
        for (boolean b : data)
            if (b)
                sb.append('1');
            else
                sb.append('0');
        return sb.toString();
    }

}
