package hopfield;


import java.awt.Component;
import java.awt.GridLayout;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Taskbook extends JPanel implements CompOwner {
    @SuppressWarnings("compatibility:-7072446761290044690")
    private static final long serialVersionUID = 3931415906462118857L;

    // Singleton!
    private static final Taskbook tb = new Taskbook();

    // Data
    private final transient TaskSet train = new TaskSet();
    private final transient TaskSet test = new TaskSet();
    private final TaskSetViewer trainView = new TaskSetViewer(train, 10, "Training set", this);
    private final TaskSetViewer testView = new TaskSetViewer(test, 10, "Test set", this);
    private TaskSetViewer active = trainView;

    private static int imSize = 10;

    private Taskbook() {
        super();
        setLayout(new GridLayout(1, 2, 10, 0));
        add(trainView);
        add(testView);
    }

    /**
     * @return return unique instance of this class
     */
    public static final Taskbook getInstance() {
        return tb;
    }

    /**
     * @param newImSize is new width of square image
     */
    public final void setImSize(int newImSize) {
        if (imSize == newImSize)
            return;
        trainView.setImSize(newImSize);
    }

    /**
     * Open editing dialog to create new task.
     */
    public final void addTask() {
        Task task = Task.addTask();
        if (task == null)
            return;
        active.addTask(task);
    }

    /**
     * Open editing dialog to edit old task.
     */
    public final void editTask() {
        active.editTask();
    }

    public final void shiftTaskUp() {
        active.shiftTaskUp();
    }

    public final void shiftTaskDown() {
        active.shiftTaskDown();
    }

    public final void swapTask() {
        Task task = active.removeTask();
        if (task == null)
            return;
        if (active == trainView)
            testView.addTask(task);
        else
            trainView.addTask(task);
    }

    public final void removeTask() {
        active.removeTask();
    }

    public final void removeAllTasks() {
        active.removAllTasks();
    }

    /**
     * @return training task set
     */
    public TaskSet getTrain() {
        return train;
    }

    /**
     * @return test task set
     */
    public TaskSet getTest() {
        return test;
    }

    /**
     * @param fileName is file name to readk task book
     */
    public void openTaskbook(final String fileName) {
        //Arrays for reading
        ArrayList<boolean[]> nTrain = new ArrayList<boolean[]>(), nTest = new ArrayList<boolean[]>(), curr = nTrain;
        //ToDo
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line = br.readLine();
            if (line == null)
                throw new IOException("Empty file");
            //Read image size
            int newSize;
            try {
                newSize = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Wrong size of image: image size must be positive integer.");
                return;
            }
            if (newSize != imSize) {
                JOptionPane.showMessageDialog(null, "File contains different size of image. Import is impossible");
                return;
            }
            int n = imSize * imSize;
            int count = 0;
            for (line = br.readLine(); line != null; line = br.readLine()) {
                count++;
                if (line.equalsIgnoreCase("Train"))
                    curr = nTrain;
                else if (line.equalsIgnoreCase("Test"))
                    curr = nTest;
                else {
                    curr.add(Utils.imageDecode(n, line, count));
                }

            }
            br.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File '" + fileName + //
                    "' is not found or contains wrong/corrupted data. File system message is: " + e.getMessage());
            return;
        }
        //Clear Taskbook and add new images
        trainView.removAllTasks();
        testView.removAllTasks();
        for (boolean[] b : nTrain) {
            trainView.addTask(new Task(b));
        }
        for (boolean[] b : nTest) {
            testView.addTask(new Task(b));
        }
        trainView.activateFirst();
    }

    /**
     * @param fileName ia file name to save task book
     */
    public void saveTaskbook(final String fileName) {
        //ToDo
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
            //Write size
            bw.write("" + imSize);
            bw.newLine();
            //Train set
            bw.write("Train");
            bw.newLine();
            for (Task t : train.tasks) {
                bw.write(Utils.imageEncode(t.input.data));
                bw.newLine();
            }
            //Test set
            bw.write("Test");
            bw.newLine();
            for (Task t : test.tasks) {
                bw.write(Utils.imageEncode(t.input.data));
                bw.newLine();
            }
            bw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error during creation or writing of file '" + fileName + //
                    "'. File system message is: " + e.getMessage());
            return;
        }
    }

    /**
     * @param act is active component
     */
    @Override
    public void setActive(Component act) {
        active = (TaskSetViewer)act;
    }

    /**
     * @param task add task to non active task set.
     */
    @Override
    public void setTask(Task task) {
        if (active == trainView)
            testView.addTask(task);
        else
            trainView.addTask(task);
    }
}
