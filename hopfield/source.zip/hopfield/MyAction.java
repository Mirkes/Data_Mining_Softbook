package hopfield;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

public abstract class MyAction extends AbstractAction {
    @SuppressWarnings("compatibility:-1428149233744446203")
    private static final long serialVersionUID = -6055592746348979403L;

    /**
     * Universal Action for menu and toolbars.
     * @param descr is text for menu
     * @param IconName is text for tool tip text
     * @param keyStroke is accelerator
     */
    public MyAction(final String descr, final String IconName, KeyStroke keyStroke) {
        super(descr, new ImageIcon(MyAction.class.getResource(IconName)));
        putValue(SHORT_DESCRIPTION, descr);
        putValue(ACCELERATOR_KEY, keyStroke);
    }
}
