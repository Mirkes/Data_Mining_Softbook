package hopfield;

import java.util.ArrayList;

/**
 * This class is model for data.
 * There are two task sets: training set and test set.
 * Each task set contains collection of Tasks.
 * Taskset has three fields:
 * <code>
 *    size of image <code>imSize</code>. Image is assumed to have size imSize-by-imSize.
 *    current is number of current task.
 *    tasks is ArrayList of tasks.
 * </code>
 * Each task contains three fields:
 * <code>
 *   input is boolean array of task data;
 *   output is boolean array of answer (result of network processing)
 *   dist is hamming distanse between input and output.
 * </code>
 * All changes in TaskSet are possible by TaskSetViewer only, exclude save or load of TaskSet
 */
public class TaskSet {

    ArrayList<Task> tasks = new ArrayList<Task>();

    /**
     * @param task is Task to find is this task set owner of this task or not.
     * @return truw if this task set is owner of task <code>task</code>
     */
    protected boolean isOwner(Object task) {
        return tasks.indexOf(task) > -1;
    }
    
    

}
