package hopfield;

import java.io.File;

import java.util.HashMap;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;


/**
 * Service class to maintain file system.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class FileMaintain {
    private static FileMaintain fm = null;
    private static HashMap<String, MyFileFilters> exts = new HashMap<String, MyFileFilters>();
    private static JFileChooser fc = new JFileChooser();

    /*
    private static MyFileFilters text = new MyFileFilters(".txt", "Text file *.txt");
    private static MyFileFilters tst = new MyFileFilters(".tst", "Test set file *.tst");
     private static MyFileFilters png = new MyFileFilters(".png", "Portable network graphics *.png");
    */

    private FileMaintain() {
        super();
        exts.put("",new MyFileFilters("","Any files *.*"));
    }

    /**
     * @return instance of class FileMaintain object
     */
    public static FileMaintain getInstance() {
        if (fm == null)
            fm = new FileMaintain();
        return fm;
    }

    /**
     * @param ext is extension (exclude period symbol)
     * @param Description is description to display
     * @return true if filter added and false otherwise
     */
    public boolean addFilter(String ext, String Description) {
        if (ext.equals(""))
            return false;
        String key;
        if (ext.charAt(0) != '.') {
            key = ext;
            ext = "." + ext;
        } else
            key = ext.substring(1);
        MyFileFilters mf = new MyFileFilters(ext, Description);
        exts.put(key, mf);
        return true;
    }

    private static void prepareFC(String extensions) {
        // Get array of used file filters
        FileFilter mff[] = fc.getChoosableFileFilters();
        String[] s = extensions.split(" ");
        MyFileFilters mf;
        boolean b;
        for (int i = 0; i < s.length; i++) {
            mf = exts.get(s[i]);
            if (mf == null) {
                JOptionPane.showMessageDialog(null, "Unknown extension '" + s[i] + "' is asked");
            } else {
                // check to existence
                b = true;
                for (int j = 0; j < mff.length; j++)
                    if (mf.equals(mff[j])) {
                        mff[j] = null;
                        b = false;
                        break;
                    }
                if (b) {
                    fc.addChoosableFileFilter(mf);
                    fc.setFileFilter(mf);
                }
            }
        }
        // Check for filters to remove
        for (int j = 0; j < mff.length; j++)
            if (mff[j] != null)
                fc.removeChoosableFileFilter(mff[j]);
    }

    /**
     * @param extensions is the text string with set of possible extension, separated by space
     * @param read is true if file prepared to read and false otherwise
     * @return name of file or empty string if file does not selected
     */
    public static String getFileName(String extensions, boolean read) {
        prepareFC(extensions);
        int ret;
        if (read)
            ret = fc.showOpenDialog(null);
        else
            ret = fc.showSaveDialog(null);
        if (ret != JFileChooser.APPROVE_OPTION)
            return "";
        String fi = fc.getSelectedFile().getPath();
        if (fc.getFileFilter()!=null && fc.getFileFilter().getClass().getName().equals("hopfield.FileMaintain$MyFileFilters")) {
            String ext = ((MyFileFilters)fc.getFileFilter()).getExt();
            // extension
            if (!fi.endsWith(ext)) {
                fi += ext;
            }
        }
        File f = new File(fi);
        if (read) {
            if (!f.exists())
                return "";
        } else {
            if (f.exists()) {
                int res = JOptionPane.showConfirmDialog(null, "Specified file is exist. Are you want to replace it?");
                if (res>0)
                    return getFileName(extensions, read);
            }
        }
        return fi;
    }

    /**
     * @param extensions is the text string with set of possible extension, separated by space
     * @param read is true if file prepared to read and false otherwise
     * @param dialogTitle is the title of file chooser dialog
     * @return name of file or empty string if file does not selected
     */
    public static String getFileName(String extensions, boolean read, String dialogTitle) {
        String old = fc.getDialogTitle();
        fc.setDialogTitle(dialogTitle);
        String res = getFileName(extensions, read);
        fc.setDialogTitle(old);
        return res;
    }

    /**
     * Return array of zero elements if files are not selected.
     * @param extensions is the text string with set of possible extension, separated by space
     * @param read is true if file prepared to read and false otherwise
     * @param title is the title of dialog
     * @return one or more file name or the String array with zero elements if files do not selected
     */
    public static String[] getFileNames(String extensions, boolean read, String title) {
        String old = fc.getDialogTitle();
        fc.setDialogTitle(title);
        String[] res = getFileNames(extensions, read);
        fc.setDialogTitle(old);
        return res;
    }

    /**
     * Return array of zero elements if files are not selected.
     * @param extensions is the text string with set of possible extension, separated by space
     * @param read is true if file prepared to read and false otherwise
     * @return one or more file name or the String array with zero elements if files do not selected
     */
    public static String[] getFileNames(String extensions, boolean read) {
        prepareFC(extensions);
        fc.setMultiSelectionEnabled(true);
        int ret;
        if (read)
            ret = fc.showOpenDialog(null);
        else
            ret = fc.showSaveDialog(null);
        File[] fil = fc.getSelectedFiles();
        fc.setMultiSelectionEnabled(false);
        if (ret != JFileChooser.APPROVE_OPTION)
            return new String[0];
        String fi[] = new String[fil.length];
        if (fc.getFileFilter().getClass().getName().equals("hopfield.FileMaintain$MyFileFilters")) {
            String ext = ((MyFileFilters)fc.getFileFilter()).getExt();
            for (int i = 0; i < fi.length; i++) {
                fi[i] = fil[i].getPath();
                // extension
                if (!fi[i].endsWith(ext)) {
                    fi[i] += ext;
                }
            }
        } else {
            for (int i = 0; i < fi.length; i++) {
                fi[i] = fil[1].getPath();
            }
        }
        return fi;
    }

    /**
     * @return name of selected directory or empty string
     */
    public static String getDirName() {
        //        fc.resetChoosableFileFilters();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int ret = fc.showDialog(null, "Select");
        if (ret != JFileChooser.APPROVE_OPTION)
            return "";
        String res = fc.getSelectedFile().getPath();
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        return res;
    }

    /**
     * @param dialogTitle is the title of file chooser dialog
     * @return name of selected directory or empty string
     */
    public static String getDirName( String dialogTitle) {
        String old = fc.getDialogTitle();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fc.setDialogTitle(dialogTitle);
        int ret = fc.showDialog(null, "Select");
        if (ret != JFileChooser.APPROVE_OPTION)
            return "";
        String res = fc.getSelectedFile().getPath();
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fc.setDialogTitle(old);
        return res;
    }
    
    /**
     * Set newDirectory as current directory
     * @param newDirectory is directory to set
     */
    public static void setCurrentDirectory(final String newDirectory){
        fc.setCurrentDirectory(new File(newDirectory));
    }

    /**
     * Set newDirectory as current directory
     * @param newDirectory is directory to set
     */
    public static void setCurrentDirectory(File newDirectory){
        fc.setCurrentDirectory(newDirectory);
    }
    
    /**
     * Set current directory to directory from which this application is started
     */
    public static void setDefaultDirectory(){
        fc.setCurrentDirectory(new File(new File(".").getAbsolutePath()).getParentFile());
    }
    
    public static class MyFileFilters extends FileFilter {
        private String ext = ".";
        private String descr = "";

        /**
         * @param ext - file extention
         * @param descr - file description
         */
        public MyFileFilters(String ext, String descr) {
            super();
            this.ext=ext;
            this.descr=descr;
        }

        /**
         * @param f - check for file matching
         * @return true if file match and else false 
         */
        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            if (f.getPath().endsWith(ext)){
                return true;
            }
            return false;
        }

        /**
         * @return description
         */
        @Override
        public String getDescription() {
            return descr;
        }

        /**
         * @return extention
         */
        public String getExt(){
            return ext;
        }
    }
}
