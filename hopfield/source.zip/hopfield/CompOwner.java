package hopfield;

import java.awt.Component;

interface CompOwner {
    /**
     * @param act is component to save as active
     */
    void setActive(Component act);

    /**
     * @param task is task to save in different task set
     */
    void setTask(Task task);
}
