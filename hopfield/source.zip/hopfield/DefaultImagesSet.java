package hopfield;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;


public class DefaultImagesSet {
    // Singleton
    private static DefaultImagesSet me = null;
    private static boolean[][] images = null;
    private static int imSize = 0;
    private static boolean ready = false;
    private static FocusedTaskPane active = null;
    //    private static JDialog dial = null;

    private DefaultImagesSet() {
        super();
    }

    /**
     * @return return instance of this singleton class
     */
    protected static DefaultImagesSet getInstance() {
        if (me == null)
            me = new DefaultImagesSet();
        return me;
    }

    /**
     * Load default image set.
     * @param imSize is width of square image
     * @param fileName is file name to download default image set
     * @return true if loading is successful
     */
    protected boolean setDefaultImageSet(int imSize, final String fileName) {
        String fName;
        if (fileName == null || fileName.isEmpty())
            fName = "DefaultImages" + imSize + ".dis";
        else
            fName = fileName;
        try {
            BufferedReader br = new BufferedReader(new FileReader(fName));
            String line = br.readLine();
            if (line == null)
                throw new IOException("Empty file");
            int n = line.indexOf(' ');
            if (n == -1)
                n = line.length();
            if (n != imSize * imSize) {
                JOptionPane.showMessageDialog(null, "File '" + fName + "' corresponds to images with " + //
                        n + " pixels but requested image size is " + imSize + "x" + imSize + "=" + (imSize * imSize) +
                        " pixels. Reading of default image sets is impossible.");
                br.close();
                return false;
            }
            ArrayList<boolean[]> tmp = new ArrayList<boolean[]>();
            int count = 1;
            boolean[] b;
            do {
                if (!line.isEmpty()) {
                    b = Utils.imageDecode(n, line, count);
                    tmp.add(b);
                }
                line = br.readLine();
                count++;
            } while (line != null);
            br.close();
            images = tmp.toArray(new boolean[tmp.size()][]);
            this.imSize = imSize;
            ready = true;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File '" + fName + //
                    "' is not found or contains wrong/corrupted data. File system message is: " + e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * @return true if default image set was successfully loaded.
     */
    protected boolean isReady() {
        return ready;
    }

    /**
     * Open dialog to select one of the omages.
     * @return selected default image
     */
    protected final boolean[] getImage() {
        //Create dialog with many images
        JDialog d = null;
        final JDialog dial = new JDialog(d, "Select image from collection", true);
        dial.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        JPanel cont = (JPanel)dial.getContentPane();
        cont.setLayout(new BorderLayout());
        JPanel pan = new JPanel(new GridLayout(0, 8, 5, 5));
        //        pan.setFocusCycleRoot(true);
        active = null;
        for (boolean[] img : images) {
            final FocusedTaskPane f = new FocusedTaskPane(img);
            f.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    f.requestFocusInWindow();
                    if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() > 1)
                        dial.setVisible(false);
                }
            });
            pan.add(f);
            if (active == null)
                active = f;
        }
        pan.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put( //
                KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
        pan.getActionMap().put("Enter", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    dial.setVisible(false);
                }
            });
        pan.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put( //
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "Escape");
        pan.getActionMap().put("Escape", new AbstractAction() {
                public void actionPerformed(ActionEvent e) {
                    active = null;
                    dial.setVisible(false);
                }
            });
        cont.add(new JScrollPane(pan));
        Utils.adjustSize(dial);
        active.requestFocusInWindow();
        dial.setVisible(true);
        boolean b[] = null;
        if (active == null)
            return b;
        else
            return active.data;
    }

    protected static class FocusedTaskPane extends Task.TaskPane implements FocusListener {
        @SuppressWarnings("compatibility:493379489272271679")
        private static final long serialVersionUID = -2171312060848443235L;

        /**
         * @param data is array to draw
         */
        protected FocusedTaskPane(boolean[] data) {
            super(data);
            setFocusable(true);
            addFocusListener(this);
        }

        /**
         * @param e is event to handle
         */
        @Override
        public void focusGained(FocusEvent e) {
            setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLUE));
            active = this;
        }

        /**
         * @param e is event to handle
         */
        @Override
        public void focusLost(FocusEvent e) {
            setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
        }
    }
}
