package hopfield;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import java.util.ArrayList;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;


public class Network extends JPanel {
    @SuppressWarnings("compatibility:-595760186671684064")
    private static final long serialVersionUID = -6423122968802706566L;

    // Singleton!
    private static final Network net = new Network();

    // Data to work
    private int nNeurons = 10;
    private int imSize = 1; // Must be not equal to the default value to cause rebuild!
    private int cellSize = 10;
    private float[][] map = new float[nNeurons][nNeurons];
    private static final Random rnd = new Random();
    private static final int maxIter = 10;
    private static int radius = 10;
    private static float cutLevel = 0;

    // Constants to use
    public static final int USUSL_WITHOUT_ITSELF = 0;
    public static final int USUSL_COMPLETE = 1;
    public static final int ORTHOGONAL = 2;

    private Network() {
        super();
        ToolTipManager toolTipManager = ToolTipManager.sharedInstance();
        toolTipManager.unregisterComponent(this);
        toolTipManager.registerComponent(this);
    }

    /**
     * @return the unique instance of this class
     */
    public static final Network getInstance() {
        return net;
    }

    /**
     * @param newImSize new image size to use.
     */
    public final void setPatameters(int newImSize) {
        if (imSize == newImSize)
            return;
        imSize = newImSize;
        nNeurons = imSize * imSize;
        cellSize = 500 / nNeurons;
        if (cellSize < 5)
            cellSize = 5;
        map = new float[nNeurons][nNeurons];
        // To have some network
        for (int i = 0; i < nNeurons; i++) {
            map[i][i] = 1;
            for (int j = i + 1; j < nNeurons; j++) {
                map[i][j] = (rnd.nextFloat() - 0.5f) * 2f;
                map[j][i] = map[i][j];
            }
        }
        rebuild();
    }

    /**
     * @param newMap is newMap to use
     */
    public final void setMap(float[][] newMap) {
        if (newMap == null || newMap.length != nNeurons || newMap[0].length != nNeurons)
            return;
        map = newMap;
        rebuild();
    }

    protected final void rebuild() {
        // Calculate actual size
        int siz = nNeurons * cellSize;
        // Set all sizes
        Utils.settAllSizes(this, siz, siz);
        // call repaint
        repaint();
    }

    /**
     * Test of one task.
     * @param input is image to test
     * @param output ia image after testing
     * @return distance between input and output
     */
    protected int testTask(boolean[] input, boolean[] output) {
        float[] inp = new float[nNeurons], outp = new float[nNeurons];
        // Decode input array
        inp = convert(input, inp);
        //Loop of tests
        int count = 0, res;
        float f;
        do {
            res = 0;
            for (int i = 0; i < nNeurons; i++) {
                f = 0;
                for (int j = 0; j < nNeurons; j++)
                    f += map[i][j] * inp[j];
                if (f >= 0) {
                    outp[i] = 1f;
                    if (inp[i] < 0)
                        res++;
                } else {
                    outp[i] = -1f;
                    if (inp[i] > 0)
                        res++;
                }
            }
            System.arraycopy(outp, 0, inp, 0, nNeurons);
            count++;
        } while (count < maxIter && res > 0);
        // Transform outp to output and calculate distance
        res = 0;
        for (int i = 0; i < nNeurons; i++) {
            output[i] = outp[i] > 0;
            if (input[i] ^ output[i])
                res++;
        }
        return res;
    }

    /**
     * Convert boolean to float.
     * @param source is boolean image representation
     * @param dest is array of floats to calculate. If dest ia null or length of dest is not equal to length of
     *      source then new array is created.
     * @return dest.
     */
    protected float[] convert(boolean[] source, float[] dest) {
        int n = source.length;
        if (dest == null || dest.length != n)
            dest = new float[n];
        for (int i = 0; i < n; i++)
            if (source[i])
                dest[i] = 1f;
            else
                dest[i] = -1f;
        return dest;
    }

    /**
     * Train network.
     * @param train train set
     * @param test test set
     * @param netType is one of hte possible net types: USUSL_WITHOUT_ITSELF, USUSL_COMPLETE, or ORTHOGONAL
     */
    protected void trainNetwork(ArrayList<Task> train, ArrayList<Task> test, int netType) {
        // Clear map
        for (int i = 0; i < nNeurons; i++)
            for (int j = 0; j < nNeurons; j++)
                map[i][j] = 0;
        float[] data = null;
        int add = 0;
        // Training
        switch (netType) {
        case USUSL_WITHOUT_ITSELF:
            add = 1;
        case USUSL_COMPLETE:
            for (Task t : train) {
                // Get data
                data = convert(t.input.data, data);
                for (int i = 0; i < nNeurons; i++) {
                    for (int j = i + add; j < nNeurons; j++)
                        map[i][j] += data[i] * data[j];
                }
            }
            for (int i = 0; i < nNeurons; i++) {
                for (int j = i + add; j < nNeurons; j++)
                    map[j][i] = map[i][j];
            }
            break;
        case ORTHOGONAL:
            float[] z = new float[nNeurons];
            float len;
            for (Task t : train) {
                // Get data
                data = convert(t.input.data, data);
                // Subtract projection onto previously found vectors
                len = 0;
                for (int i = 0; i < nNeurons; i++) {
                    z[i] = data[i];
                    for (int j = 0; j < nNeurons; j++)
                        z[i] -= map[i][j] * data[j];
                    len += z[i] * z[i];
                }
                // Check for zero length vector
                len = (float)Math.sqrt(len);
                if (len < 0.000001f)
                    continue;
                // Renormalise
                for (int i = 0; i < nNeurons; i++)
                    z[i] /= len;
                // Update matrix
                for (int i = 0; i < nNeurons; i++) {
                    for (int j = 0; j < nNeurons; j++)
                        map[i][j] += z[i] * z[j];
                }
            }
            break;
        default:
            JOptionPane.showMessageDialog(null, "Wrong type of network");
            return;
        }
        // Search maximum
        float m = 0;
        for (int i = 0; i < nNeurons; i++)
            for (int j = 0; j < nNeurons; j++)
                if (m < Math.abs(map[i][j]))
                    m = Math.abs(map[i][j]);
        //Normalise
        for (int i = 0; i < nNeurons; i++)
            for (int j = 0; j < nNeurons; j++)
                map[i][j] /= m;
        // Test
        for (Task t : train)
            t.testTask();
        for (Task t : test)
            t.testTask();
        repaint();
        radius = 2 * imSize - 2;
        cutLevel = 0;
    }

    /**
     * Prune net: set all weights for neurons with Manhattan distance being greater than specified to zero.
     * @param train is train set
     * @param test is test set
     */
    protected void pruneNet(ArrayList<Task> train, ArrayList<Task> test) {
        // Ask size of minimal value to save
        String answer = JOptionPane.showInputDialog("Enter threshold to cut", String.format("%.2f", cutLevel));
        if (answer == null)
            return;
        float ans;
        try {
            ans = Float.parseFloat(answer);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Wrong format of number. Cut level must be number between 0 and 1.");
            return;
        }
        if (ans < 0f || ans > 1f) {
            JOptionPane.showMessageDialog(null, "Wrong number: cut level must be number between 0 and 1.");
            return;
        }
        cutLevel = ans;
        // Cut
        for (int i = 0; i < nNeurons; i++)
            for (int j = 0; j < nNeurons; j++)
                if (Math.abs(map[i][j]) < cutLevel)
                    map[i][j] = 0;
        // Test
        for (Task t : train)
            t.testTask();
        for (Task t : test)
            t.testTask();
        repaint();
    }

    /**
     * Prune net: set all weights with value which is ledss than specified to zero.
     * @param train is train set
     * @param test is test set
     */
    protected void pruneNetR(ArrayList<Task> train, ArrayList<Task> test) {
        // Ask radius of neighbourhood
        String answer = JOptionPane.showInputDialog("Enter radius of neighbourhood", "" + radius);
        if (answer == null)
            return;
        int ans;
        try {
            ans = Integer.parseInt(answer);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, //
                    "Wrong format of number. Radius must be integer between 1 and " + (2 * imSize - 2));
            return;
        }
        if (ans < 1 || ans > 2 * imSize - 2) {
            JOptionPane.showMessageDialog(null, //
                    "Wrong number: radius must be integer between 1 and " + (2 * imSize - 2));
            return;
        }
        radius = ans;
        for (int i = 0; i < imSize; i++)
            for (int j = 0; j < imSize; j++)
                for (int k = 0; k < imSize; k++)
                    for (int m = 0; m < imSize; m++)
                        if (Math.abs(i - k) + Math.abs(j - m) > radius)
                            map[i * imSize + j][k * imSize + m] = 0;
        // Test
        for (Task t : train)
            t.testTask();
        for (Task t : test)
            t.testTask();
        repaint();
    }

    /**
     * @param g is graphics to draw
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int i = 0; i < nNeurons; i++)
            for (int j = 0; j < nNeurons; j++) {
                if (map[i][j] > 0)
                    g.setColor(new Color(1 - map[i][j], 1, 1 - map[i][j]));
                else
                    g.setColor(new Color(1 + map[i][j], 1 + map[i][j], 1));
                g.fillRect(i * cellSize, j * cellSize, cellSize, cellSize);
            }
    }

    /**
     * This method is called automatically when the mouse is over the component.
     * Based on the location of the event, we detect if we are over one of
     * the synapse. If so, we display row and column of this synapse and synaptic weight.
     * @param event is event to handle
     * @return text to display
     */
    @Override
    public String getToolTipText(MouseEvent event) {
        // Calculate cell under the mouse
        int x = event.getX() / cellSize;
        int y = event.getY() / cellSize;
        if (x >= nNeurons || y >= nNeurons)
            return "";
        return ("From " + x + " to " + y + " with weight " + String.format("%.3f", map[x][y]));
    }

}
