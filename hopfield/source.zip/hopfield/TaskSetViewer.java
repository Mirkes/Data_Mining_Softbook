package hopfield;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;


/**
 * This class is viewer for TaskSet.
 * TaskSetViewer contains two panels:
 * <code>
 *    title panel shows names of columns: Input, Outcome, Dist
 *    body panel shows list of tasks
 * </code>
 */
public class TaskSetViewer extends JPanel implements FocusListener, CompOwner {
    @SuppressWarnings("compatibility:5432339244690632090")
    private static final long serialVersionUID = 1L;

    private final transient TaskSet taskSet;
    private final JPanel body;
    protected final String title;
    private final transient CompOwner owner;
    private final Component glue;
    private Task active = null;

    TaskSetViewer(TaskSet newTaskSet, int imSize, String newTitle, CompOwner newOwner) {
        taskSet = newTaskSet;
        title = newTitle;
        owner = newOwner;
        body = new JPanel();
        glue = Box.createVerticalGlue();
        setLayout(new BorderLayout());
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        add(new JScrollPane(body), BorderLayout.CENTER);
        //Create header
        setImSize(imSize);
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), title));
        setFocusable(true);
        requestFocusInWindow();
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                requestFocusInWindow();
            }
        });
        addFocusListener(this);
    }

    /**
     * @param imSize is width of square image
     */
    protected void setImSize(int imSize) {
        //Remove images with old size
        //From TaskSet
        taskSet.tasks.clear();
        active = null;
        //From body
        body.removeAll();
        // Calculate sizes by Task
        Task.setImageSize(imSize);
        //Get required values
        int wid = Task.cellSize * imSize + 10;
        //Recreate headers
        JPanel pan = new JPanel();
        pan.setLayout(new BoxLayout(pan, BoxLayout.X_AXIS));
        JLabel lab = new JLabel("Input");
        lab.doLayout();
        Dimension d = lab.getPreferredSize();
        d.width = wid;
        Utils.settAllSizes(lab, d);
        pan.add(lab);
        lab = new JLabel("Outcome");
        lab.doLayout();
        d = lab.getPreferredSize();
        d.width = wid;
        Utils.settAllSizes(lab, d);
        pan.add(lab);
        pan.add(new JLabel("Dist"));
        pan.doLayout();
        Utils.settAllSizes(pan, pan.getPreferredSize());
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(pan);
        this.add(p, BorderLayout.NORTH);
        revalidate();
    }

    /**
     * @param task is task to add.
     */
    public final void addTask(Task task) {
        //Get number of the current task
        int pos = taskSet.tasks.size();
        if (active != null)
            pos = taskSet.tasks.indexOf(active) + 1;
        taskSet.tasks.add(pos, task);
        body.add(task, pos);
        body.revalidate();
        task.setOwner(this);
        task.requestFocusInWindow();
    }

    public final void activateFirst(){
        if (taskSet.tasks.size()==0)
            return;
        taskSet.tasks.get(0).requestFocusInWindow();
    }

    public final void editTask() {
        //Check if we have a task:
        if (active == null)
            return;
        active.editTask();
    }

    public final void shiftTaskUp() {
        if (active == null)
            return;
        int pos = taskSet.tasks.indexOf(active) - 1;
        body.remove(active);
        taskSet.tasks.remove(active);
        if (pos < 0) {
            taskSet.tasks.add(active);
            body.add(active);
        } else {
            taskSet.tasks.add(pos, active);
            body.add(active, pos);
        }
        body.revalidate();
        active.requestFocusInWindow();
    }

    public final void shiftTaskDown() {
        if (active == null)
            return;
        int pos = taskSet.tasks.indexOf(active) + 1;
        body.remove(active);
        taskSet.tasks.remove(active);
        if (pos > taskSet.tasks.size()) {
            taskSet.tasks.add(0, active);
            body.add(active, 0);
        } else {
            taskSet.tasks.add(pos, active);
            body.add(active, pos);
        }
        body.revalidate();
        active.requestFocusInWindow();
    }

    /**
     * @return removed Task
     */
    public final Task removeTask() {
        if (active == null)
            return null;
        Task res = active;
        int pos = taskSet.tasks.indexOf(active);
        body.remove(active);
        taskSet.tasks.remove(active);
        if (pos == taskSet.tasks.size())
            pos--;
        if (pos == -1)
            active = null;
        else {
            active = taskSet.tasks.get(pos);
            active.requestFocusInWindow();
        }
        body.revalidate();
        body.repaint();
        return res;
    }

    public final void removAllTasks() {
        body.removeAll();
        taskSet.tasks.clear();
        active = null;
        body.revalidate();
        body.repaint();
    }

    /**
     * @param e is event to handle
     */
    @Override
    public void focusGained(FocusEvent e) {
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLUE), title));
        owner.setActive(this);
    }

    /**
     * @param e is event to handle
     */
    @Override
    public void focusLost(FocusEvent e) {
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK), title));
    }

    /**
     * @param act is Task to set as active
     */
    @Override
    public void setActive(Component act) {
        active = (Task)act;
        owner.setActive(this);
    }

    /**
     * @param task is Task to save in one of the task sets.
     */
    @Override
    public void setTask(Task task) {
        int res =
            JOptionPane.showConfirmDialog(null, "Press 'yes' to save in the same set and press 'No' to set in the opposite set",
                                          "Save as", JOptionPane.YES_NO_CANCEL_OPTION);
        if (res == 2) //Cancel
            return;
        if (res == 0) { //This set
            addTask(task);
        } else
            owner.setTask(task);
    }
}

