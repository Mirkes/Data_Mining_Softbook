package hopfield;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.WindowConstants;


public class Editor extends JPanel {
    @SuppressWarnings("compatibility:5574029519975491999")
    private static final long serialVersionUID = -181702360078954508L;

    private int imSize = 0;
    private boolean[] data, prototype;
    private int cellSize = 1;
    private static JMenuItem noiseLevel = null;
    private static float level = 0.1f;
    private static final DefaultImagesSet dis = DefaultImagesSet.getInstance();

    /**
     * @param siz is width of square image
     * @param data is data array to edit
     * @param minWidth is minimal width of dialog frame
     */
    public Editor(int siz, boolean[] data, int minWidth) {
        imSize = siz;
        this.data = new boolean[imSize * imSize];
        prototype = data;
        System.arraycopy(data, 0, this.data, 0, imSize * imSize);
        cellSize = 200 / siz;
        if (cellSize < 5)
            cellSize = 5;
        while (cellSize * imSize < minWidth)
            cellSize++;
        Dimension d = new Dimension(imSize * cellSize + 6, imSize * cellSize + 6);
        Utils.settAllSizes(this, d);
        setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLUE));
        addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                mouseClickedEvent(e);
            }
        });
    }

    /**
     * Show dialog to edit image.
     * @param siz is width of square image
     * @param data is image to edit
     * @return class Answer which contains editted image and reason to close (Save, Save as, Cancel)
     */
    public static final Answer showDialog(int siz, boolean[] data) {
        JDialog d = null;
        final JDialog dial = new JDialog(d, "Task editor", true);
        dial.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        JPanel cont = (JPanel)dial.getContentPane();
        cont.setLayout(new BorderLayout(10, 10));
        final String[] buttons = new String[] { "Save", "Save as", "Cancel" };
        final Answer ans = new Answer();
        //Action listener for buttons
        final ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Search the position of button
                String s = e.getActionCommand();
                for (int i = 0; i < buttons.length; i++)
                    if (s.equals(buttons[i])) {
                        ans.outcome = i;
                        dial.setVisible(false);
                    }
            }
        };
        //Create buttons panel
        JPanel pan = setButtonPanel(buttons, al, buttons[0], dial);
        pan.doLayout();
        Dimension dd = pan.getPreferredSize();
        cont.add(pan, BorderLayout.SOUTH);
        final Editor comp = new Editor(siz, data, dd.width + 10);
        cont.add(comp, BorderLayout.CENTER);
        ans.outcome = -1;
        ans.data = comp.data;

        // Create menu
        JMenuBar menuBar = new JMenuBar();
        dial.setJMenuBar(menuBar);
        JPanel toolBars = new JPanel();
        toolBars.setLayout(new BoxLayout(toolBars,BoxLayout.Y_AXIS));
        JToolBar toolBar = new JToolBar();
        toolBars.add(toolBar);
        cont.add(toolBars, BorderLayout.NORTH);

        JMenu menu = new JMenu("Edit");
        toolBar.add(new JLabel("Edit "));
        AbstractAction aa = new MyAction("Select image from collection", "Documents32.png", //
                KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK)) {
            public void actionPerformed(ActionEvent e) {
                comp.setImageFromDIS();
            }
        };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menu.addSeparator();
        toolBar.addSeparator();

        aa = new MyAction("Undo", "Undo32.png", KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.restoreOriginal();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Clear image", "Clear32.png", KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.clearImage();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Invert image", "Invert32.png", KeyStroke.getKeyStroke(KeyEvent.VK_I, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.inverseImage();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menu.addSeparator();
        JMenuItem mi = new JMenuItem("Cancel editing");
        mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0));
        mi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                dial.setVisible(false);
            }
        });
        menu.add(mi);

        menuBar.add(menu);
        menu = new JMenu("Random noise");
        toolBar = new JToolBar();
        toolBars.add(toolBar);
        toolBar.add(new JLabel("Random noise"));

        noiseLevel = new JMenuItem("Set noise level ("+String.format("%.2f", level)+")");
        noiseLevel.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, ActionEvent.ALT_MASK));
        noiseLevel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                changeNoiseLevel();
            }
        });
        menu.add(noiseLevel);
        menu.addSeparator();

        aa = new MyAction("Apply additive noise", "Plus32.png", KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.additiveNoise();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Apply removing noise", "Minus32.png", KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.removingNoise();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Apply inverting noise", "PlusMinus32.png", KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.invertingNoise();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menuBar.add(menu);

        menu = new JMenu("Image shift");
        toolBar = new JToolBar();
        toolBars.add(toolBar);
        toolBar.add(new JLabel("Shifts"));
        

        aa = new MyAction("Shift up", "Up32.png", KeyStroke.getKeyStroke(KeyEvent.VK_UP, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.shiftUp();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Shift down", "Down32.png", KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.shiftDown();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Shift left", "Left32.png", KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.shiftLeft();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Shift right", "Right32.png", KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    comp.shiftRight();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menuBar.add(menu);

        dial.setResizable(false);
        Utils.adjustSize(dial);
        dial.setVisible(true);
        // If there is no answer then set it to Cancel
        if (ans.outcome < 0) {
            ans.outcome = 2;
        }
        dial.dispose();
        return ans;
    }

    protected static void changeNoiseLevel() {
        String answer = JOptionPane.showInputDialog("Enter noise level", String.format("%.2f", level));
        if (answer == null)
            return;
        float ans;
        try {
            ans = Float.parseFloat(answer);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Wrong format of number. Noise level must be number between 0 and 1.");
            return;
        }
        if (ans < 0f || ans > 1f) {
            JOptionPane.showMessageDialog(null, "Wrong number: noise level must be number between 0 and 1.");
            return;
        }
        level = ans;
        noiseLevel.setText("Set noise level (" + String.format("%.2f", level) + ")");
    }

    protected void additiveNoise() {
        float f;
        for (int i = 0, n = data.length; i < n; i++) {
            f = Utils.rnd.nextFloat();
            if (f < level)
                data[i] = true;
        }
        repaint();
    }

    protected void removingNoise() {
        float f;
        for (int i = 0, n = data.length; i < n; i++) {
            f = Utils.rnd.nextFloat();
            if (f < level)
                data[i] = false;
        }
        repaint();
    }

    protected void invertingNoise() {
        float f;
        for (int i = 0, n = data.length; i < n; i++) {
            f = Utils.rnd.nextFloat();
            if (f < level)
                data[i] = !data[i];
        }
        repaint();
    }

    protected void restoreOriginal() {
        System.arraycopy(prototype, 0, data, 0, imSize * imSize);
        repaint();
    }

    protected void clearImage() {
        for (int i = 0; i < imSize * imSize; i++)
            data[i] = false;
        repaint();
    }

    protected void inverseImage() {
        for (int i = 0; i < imSize * imSize; i++)
            data[i] = !data[i];
        repaint();
    }

    protected void shiftUp() {
        int n = data.length;
        boolean[] copy = new boolean[n];
        // Create copy
        System.arraycopy(data, 0, copy, 0, n);
        // Copy back
        System.arraycopy(copy, imSize, data, 0, n - imSize);
        System.arraycopy(copy, 0, data, n - imSize, imSize);
        repaint();
    }

    protected void shiftDown() {
        int n = data.length;
        boolean[] copy = new boolean[n];
        // Create copy
        System.arraycopy(data, 0, copy, 0, n);
        // Copy back
        System.arraycopy(copy, 0, data, imSize, n - imSize);
        System.arraycopy(copy, n - imSize, data, 0, imSize);
        repaint();
    }

    protected void shiftLeft() {
        int n = data.length;
        boolean b1 = data[0];
        // Shift all
        System.arraycopy(data, 1, data, 0, n - 1);
        // Normalize result
        for (int i = imSize - 1; i > 0; i--)
            data[(i + 1) * imSize - 1] = data[i * imSize - 1];
        data[imSize - 1] = b1;
        repaint();
    }

    protected void shiftRight() {
        int n = data.length;
        boolean b1 = data[n - 1];
        // Shift all
        System.arraycopy(data, 0, data, 1, n - 1);
        // Normalize result
        for (int i = 0; i < imSize - 1; i++)
            data[i * imSize] = data[(i + 1) * imSize];
        data[n - imSize] = b1;
        repaint();
    }

    protected void setImageFromDIS() {
        if (!dis.isReady()) {
            if (!dis.setDefaultImageSet(imSize, "")) {
                JOptionPane.showMessageDialog(null, "Default fiile 'DefaultImages" + imSize + //
                        ".dis' is not found. Selection from set of default images is impossible");
                return;
            }
        }
        boolean[] tmp = dis.getImage();
        if (tmp == null)
            return;
        System.arraycopy(tmp, 0, data, 0, imSize * imSize);
        repaint();
    }

    private static final JPanel setButtonPanel(String[] buttons, ActionListener al, String defBut, JDialog dial) {
        JPanel butPan = new JPanel();
        for (String but : buttons) {
            JButton b = new JButton(but);
            b.setActionCommand(but);
            b.addActionListener(al);
            butPan.add(b);
            if (defBut.equals(but))
                dial.getRootPane().setDefaultButton(b);
        }
        return butPan;
    }

    /**
     * @param g is graphics to draw
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (int y = 0; y < imSize; y++)
            for (int x = 0; x < imSize; x++) {
                if (data[y * imSize + x])
                    g.setColor(Color.BLACK);
                else
                    g.setColor(Color.WHITE);
                g.fillRect(x * cellSize + 3, y * cellSize + 3, cellSize, cellSize);
            }
    }

    private void mouseClickedEvent(MouseEvent e) {
        if (e.getButton() != MouseEvent.BUTTON1)
            return;
        int x = (e.getX() - 3) / cellSize, y = (e.getY() - 3) / cellSize;
        data[y * imSize + x] = !data[y * imSize + x];
        repaint();
    }

    protected static class Answer {
        protected int outcome;
        protected boolean[] data;
    }
}
