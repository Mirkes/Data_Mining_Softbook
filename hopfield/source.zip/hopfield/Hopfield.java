package hopfield;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.io.IOException;

import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.AbstractAction;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.UIManager;


public class Hopfield extends JFrame {
    @SuppressWarnings("compatibility:-7899535839368468749")
    private static final long serialVersionUID = 8898806489577233252L;

    //Image size
    private static int imSize = 10;

    //Two main panels
    protected static final Taskbook taskbook = Taskbook.getInstance();
    protected static final Network network = Network.getInstance();

    public Hopfield() {
        super("Hopfield associative memory");
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();
        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }
        this.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

    }

    /**
     * @param args is unused array if command line parameters
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new Hopfield();
    }

    private void jbInit() throws Exception {
        Container cont = this.getContentPane();
        cont.setLayout(new BorderLayout());
        JTabbedPane tab = new JTabbedPane();
        tab.addTab("Task book", new JScrollPane(taskbook));
        taskbook.setImSize(imSize);
        Task.setNetwork(network);
        network.setPatameters(imSize);
        tab.addTab("Network", new JScrollPane(network));
        cont.add(tab, BorderLayout.CENTER);
        this.setSize(new Dimension(700, 600));

        // Create menu
        JMenuBar menuBar = new JMenuBar();
        this.setJMenuBar(menuBar);
        JToolBar toolBar = new JToolBar();
        cont.add(toolBar, BorderLayout.NORTH);

        JMenu menu = new JMenu("Task book");

        AbstractAction aa = new MyAction("Open task book", "Open32.png", //
                KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.ALT_MASK)) {
            public void actionPerformed(ActionEvent e) {
                String fileName = FileMaintain.getFileName("tbk", true, "Enter file name to load taskbook");
                if (fileName.isEmpty())
                    return;
                taskbook.openTaskbook(fileName);
            }
        };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Save task book", "Save32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    String fileName = FileMaintain.getFileName("tbk", false, "Enter file name to save taskbook");
                    if (fileName.isEmpty())
                        return;
                    taskbook.saveTaskbook(fileName);
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Add task", "Add32.png", KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.addTask();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Edit task", "Edit32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.editTask();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menu.addSeparator();
        toolBar.addSeparator();

        aa = new MyAction("Move current task up", "UpB32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_UP, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.shiftTaskUp();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Move current task down", "DownB32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.shiftTaskDown();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menu.addSeparator();
        toolBar.addSeparator();

        aa = new MyAction("Move current task to another set", "Swap32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.swapTask();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Remove current task", "Remove26.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.removeTask();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Remove all tasks", "Remove32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    taskbook.removeAllTasks();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menu.addSeparator();
        JMenuItem mi = new JMenuItem("Exit");
        mi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                System.exit(0);
            }
        });
        menu.add(mi);
        menuBar.add(menu);

        menu = new JMenu("Network");
        toolBar.addSeparator();

        final ButtonGroup bg = new ButtonGroup();
        mi = new JRadioButtonMenuItem("Usual network without self connection", true);
        mi.setActionCommand("0");
        bg.add(mi);
        mi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                network.trainNetwork(taskbook.getTrain().tasks, taskbook.getTest().tasks,Network.USUSL_WITHOUT_ITSELF);
            }
        });
        menu.add(mi);

        mi = new JRadioButtonMenuItem("Usual complete network",false);
        mi.setActionCommand("1");
        bg.add(mi);
        mi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                network.trainNetwork(taskbook.getTrain().tasks, taskbook.getTest().tasks,Network.USUSL_COMPLETE);
            }
        });
        menu.add(mi);

        mi = new JRadioButtonMenuItem("Orthogonal network",false);
        mi.setActionCommand("2");
        bg.add(mi);
        mi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                network.trainNetwork(taskbook.getTrain().tasks, taskbook.getTest().tasks,Network.USUSL_COMPLETE);
            }
        });
        menu.add(mi);

        menu.addSeparator();
        aa = new MyAction("Train net", "Training32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    int type = Integer.parseInt(bg.getSelection().getActionCommand());
                    network.trainNetwork(taskbook.getTrain().tasks, taskbook.getTest().tasks,type);
                    taskbook.repaint();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Prune net by value", "Prune32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    network.pruneNet(taskbook.getTrain().tasks, taskbook.getTest().tasks);
                    taskbook.repaint();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        aa = new MyAction("Prune net by radius", "Scalpel32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    network.pruneNetR(taskbook.getTrain().tasks, taskbook.getTest().tasks);
                    taskbook.repaint();
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.add(aa);

        menuBar.add(menu);

        menu = new JMenu("Help");
        aa = new MyAction("About", "About32.png", //
                    KeyStroke.getKeyStroke(KeyEvent.VK_F1, ActionEvent.ALT_MASK)) {
                public void actionPerformed(ActionEvent e) {
                    AboutBox ab = new AboutBox(null);
                    Utils.adjustSize(ab);
                    ab.setVisible(true);
                }
            };
        menu.add(new JMenuItem(aa));
        toolBar.addSeparator();
        toolBar.add(aa);
        menuBar.add(menu);

        // Prepare FileMaintain
        FileMaintain fm = FileMaintain.getInstance();
        fm.addFilter("tbk", "Task book file *.tbk");
        fm.addFilter("dis", "Default image set file *.dis");
    }

    void helpAbout_ActionPerformed(ActionEvent e) {
        AboutBox ab = new AboutBox(this);
        Utils.adjustSize(ab);
        ab.setVisible(true);
    }

    private static class AboutBox extends JDialog {
        @SuppressWarnings("compatibility:-517031816926846872")
        private static final long serialVersionUID = 1L;

        /**
         * @param parent is JFrame for relative locating
         */
        public AboutBox(JFrame parent) {
            super(parent, "About dialog", true);
            try {
                jbInit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void jbInit() throws Exception {
            this.setLayout(new GridBagLayout());
            int row = 0;
            AddGBL.addGBL(this, new UoLPane(), 0, row++, GridBagConstraints.CENTER);
            AddGBL.addGBL(this, new JLabel("Demonstration of Hopfield assosiative memory"), 0, row++,
                          GridBagConstraints.CENTER);
            AddGBL.addGBL(this, new JLabel("Author: Evgeny M Mirkes"), 0, row++, GridBagConstraints.CENTER);
            AddGBL.addGBL(this, new JLabel("University of leicester"), 0, row++, GridBagConstraints.CENTER);
            AddGBL.addGBL(this, new JLabel("Distributed under Creative Commons Attribution license"), 0, row++,
                          GridBagConstraints.CENTER);
            AddGBL.addGBL(this, new CopyLeftPane(), 0, row++, GridBagConstraints.CENTER);
            JButton b = new JButton("Ok");
            b.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    actionPerformedClose(ae);
                }
            });
            AddGBL.addGBL(this, b, 0, row, GridBagConstraints.CENTER);
            pack();
        }

        /**
         * @param e is event to handle
         */
        public void actionPerformedClose(ActionEvent e) {
            setVisible(false);
        }

    }

    public static class UoLPane extends JLabel {
        @SuppressWarnings("compatibility")
        private static final long serialVersionUID = 1L;

        public UoLPane() {
            super();
            this.setIcon(Icons.getUOLIcon());
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent ee) {
                    try {
                        Desktop desktop = Desktop.getDesktop();
                        desktop.browse(new URI("http://www2.le.ac.uk/"));
                    } catch (IOException e) {
                        return;
                    } catch (URISyntaxException e) {
                        return;
                    }
                }
            });
        }
    }

    public static class CopyLeftPane extends JLabel {
        @SuppressWarnings("compatibility")
        private static final long serialVersionUID = 1L;

        public CopyLeftPane() {
            super();
            this.setIcon(Icons.getCopyLeft());
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent ee) {
                    try {
                        Desktop desktop = Desktop.getDesktop();
                        desktop.browse(new URI("http://creativecommons.org/licenses/by/3.0/"));
                    } catch (IOException e) {
                        return;
                    } catch (URISyntaxException e) {
                        return;
                    }
                }
            });
        }

    }
}
