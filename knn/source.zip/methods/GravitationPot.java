package methods;

import common.AbstractDot;

import java.awt.Point;

/**
 * Class Quadrupole classifier.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class GravitationPot extends Classifier {
    private int[] klass;
    private Point[] pp;
    private double[][] klassMeans;
    private int[] klassCount;
    private double[][][] klassMatrix;

    /**
     * @param string is the name of classifier
     */
    public GravitationPot(String string) {
        super(string);
        param = 2;
        paramMin = 1;
        paramMax = 10;
        paramStep = 1;
    }

    /**
     * @param p is array of points
     * @param klass is array of classes' of points
     */
    @Override
    public void train(Point[] p, int[] klass) {
        this.pp = p;
        this.klass = klass;
        if (useQuadrupole) {
            //Prepare data for quadrupole
            //Create arrays for data
            klassMeans = new double[maxKlass][2];
            klassCount = new int[maxKlass];
            klassMatrix = new double[maxKlass][2][2];
            //Calculate number of cases  and mean point for each class
            int nDots = p.length, k;
            for (int i = 0; i < nDots; i++) {
                k = klass[i];
                klassCount[k]++;
                klassMeans[k][0] += p[i].x;
                klassMeans[k][1] += p[i].y;
                klassMatrix[k][0][0] += p[i].x * p[i].x;
                klassMatrix[k][0][1] += p[i].x * p[i].y;
                klassMatrix[k][1][1] += p[i].y * p[i].y;
            }
            //Complite matrix calculation
            double d;
            for (int i = 0; i < maxKlass; i++)
                if (klassCount[i] > 0) {
                    //Normalize means
                    klassMeans[i][0] /= klassCount[i];
                    klassMeans[i][1] /= klassCount[i];
                    //Complete calculation of the first matrix
                    klassMatrix[i][0][0] -= klassCount[i] * klassMeans[i][0] * klassMeans[i][0];
                    klassMatrix[i][0][1] -= klassCount[i] * klassMeans[i][0] * klassMeans[i][1];
                    klassMatrix[i][1][1] -= klassCount[i] * klassMeans[i][1] * klassMeans[i][1];
                    //Calculate squared length of vector of sum of deviation from means
                    d = klassMatrix[i][0][0] + klassMatrix[i][1][1];
                    //Final correction of matrix
                    klassMatrix[i][0][0] = param * ((param + 2) * klassMatrix[i][0][0] - d);
                    klassMatrix[i][0][1] = param * (param + 2) * klassMatrix[i][0][1];
                    klassMatrix[i][1][0] = klassMatrix[i][0][1];
                    klassMatrix[i][1][1] = param * ((param + 2) * klassMatrix[i][1][1] - d);
                }
        }
        ready = true;
    }

    /**
     * @param p is point to test
     * @param cv is true for exclusion of points with the same position and false otherwise
     * @return array of possible clases. If class of point p can be exactly identified
     * (the most frequent case) then length of output array is one.
     */
    @Override
    public int[] predict(Point p, boolean cv) {
        //Predict for usual case and for quadrupole
        //Array for membershop function
        double[] klas = new double[maxKlass];
        if (useQuadrupole) {
            //Prediction by quadrupole approximation
            double[] vec = new double[2];
            double len, tmp;
            //Calculate membership functions
            for (int k = 0; k < maxKlass; k++) {
                if (klassCount[k] == 0)
                    continue;
                //Calculate vector of deviation from mean
                vec[0] = p.x - klassMeans[k][0];
                vec[1] = p.y - klassMeans[k][1];
                //Calculate squared lenght of this vector
                len = vec[0] * vec[0] + vec[1] * vec[1] + 0.001;
                //Calculate value of quadratic form
                tmp = 0;
                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < 2; j++)
                        tmp += vec[i] * klassMatrix[k][i][j] * vec[j];
                //Finalise calculation
                klas[k] = Math.pow(len, -param * 0.5) * (klassCount[k] + tmp / (2 * len * len));
            }
        } else {
            //Usual work.
            //Get number of points
            int nDots = pp.length;
            if (nDots == 0)
                //There is no point
                return new int[0];

            // Calculate potentials
            double d, pow = param / 2.0;
            // Go over all dots
            for (int i = 0; i < nDots; i++) {
                // Calculate distance between target and current dot
                d = Math.pow(AbstractDot.calcDist(p, pp[i]), pow);
                if (cv && d == 0)
                    continue;
                // Calculate potential and add sum of its class
                klas[klass[i]] += 1 / (d + 0.001);
            }
        }
        // find max position
        double d = 0;
        int n = -1;
        for (int i = 0; i < maxKlass; i++)
            if (klas[i] > d) {
                d = klas[i];
                n = i;
            }
        int[] res = new int[] { n };
        return res;
    }

    /**
     * @return empty array because all points are voters
     */
    @Override
    public int[] getVoters() {
        return new int[0];
    }

    /**
     * @return name of parameter
     */
    @Override
    public String getParameterName() {
        return "Degree of potential";
    }
}
