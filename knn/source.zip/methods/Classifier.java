package methods;

import common.MainFrame;

import java.awt.Point;


/**
 * Absract class for all classifiers, such that kNN, Yukawa potential, 
 * Gaussian potential, Quadrupole etc.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public abstract class Classifier {
    private final String name;
    protected int param, paramMin, paramMax, paramStep;
    protected boolean ready = false, useQuadrupole = false;
    protected int maxKlass = 0;

    /**
     * @param names is name of method
     */
    public Classifier(String names) {
        name = names;
        //Get maximal possible number of classes
        maxKlass = MainFrame.getColorCount();
    }

    /**
     * @return name of classifier
     */
    public final String toString() {
        return name;
    }

    /**
     * @return name of parameter.
     */
    public abstract String getParameterName();

    /**
     * @return the minimal value of parameter
     */
    public int gerParamMin(){
        return paramMin;
    }

    /**
     * @return the maximal value of parameter
     */
    public int gerParamMax(){
        return paramMax;
    }

    /**
     * @return the step of parameter changing
     */
    public int gerParamStep(){
        return paramStep;
    }

    /**
     * @return value of parameter
     */
    public int getParameter() {
        return param;
    }

    /**
     * Set value of parameter.
     * @param parameter is parameter of classifier. Meaning of this parameter is defined for 
     * each classifier separately
     */
    public void setParameter(int parameter) {
        param = parameter;
        ready = false;
    }

    /**
     * @return trigger for quadrupole approximation usage.
     */
    public final boolean getUseQuadrupole(){
        return useQuadrupole;
    }

    /**
     * @param use is boolean paremeter to use/non use of quadrupole approximation.
     */
    public final void setUseQuadrupole(boolean use){
        useQuadrupole = use;
        ready = false;
    }

    /**
     * @return status of classifier
     */
    public final boolean isReady() {
        return ready;
    }

    /**
     * Set classifier to not trained state.
     */
    public final void untrain() {
        ready = false;
    }

    /**
     * @param p is array of points
     * @param klass is array of classes' of points
     */
    public abstract void train(Point[] p, int[] klass);

    /**
     * @param p is point to test
     * @param cv is true for exclusion of points with the same position and false otherwise
     * @return array of possible clases. If class of point p can be exactly identified
     * (the most frequent case) then length of output array is one.
     */
    public abstract int[] predict(Point p, boolean cv);
    
    /**
     * @return array of number of voters in the list of all usable points 
     * (neither all data points or prototypes if the data reduction is implemented)
     */
    public abstract int[] getVoters();

}
