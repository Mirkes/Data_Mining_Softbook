package methods;

import common.AbstractDot;

import java.awt.Point;

/**
 * Class for kNN classifier.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class KNN extends Classifier {
    private int[] klass;
    private Point[] p;
    private int[] voters;

    /**
     * @param string is the name of classifier
     */
    public KNN(String string) {
        super(string);
        param = 5;
        paramMin = 1;
        paramMax = 50;
        paramStep = 1;
    }

    /**
     * @param p is array of points
     * @param klass is array of classes' of points
     */
    @Override
    public void train(Point[] p, int[] klass) {
        this.p = p;
        this.klass = klass;
        ready = true;
    }

    /**
     * @param pp is point to test
     * @param cv is true for exclusion of points with the same position and false otherwise
     * @return array of possible clases. If class of point p can be exactly identified
     * (the most frequent case) then length of output array is one.
     */
    @Override
    public int[] predict(Point pp, boolean cv) {
        //Get number of points
        int n = p.length;
        if (n == 0)
            return new int[0];
        if (n <= param) {
            //There is no enough points
            int klas[] = new int[maxKlass];
            for (int i = 0; i < n; i++)
                klas[klass[i]]++;
            // find max and count of max
            int d = klas[0];
            n = 1;
            for (int i = 1; i < maxKlass; i++)
                if (klas[i] > d) {
                    d = klas[i];
                    n = 1;
                } else if (klas[i] == d)
                    n++;
            //Create array of outputs
            int[] res = new int[n];
            n = 0;
            for (int i = 1; i < maxKlass; i++)
                if (klas[i] == d) {
                    res[n++] = i;
                }
            //Create arrays of positions and colours of used points.
            voters = new int[n];
            for (int i = 1; i < n; i++)
                voters[i] = i;
            return res;
        }

        //Create arrays to find KNN
        int[] dist = new int[param], who = new int[param];
        int d, k;
        //Put infinit distances into dist
        for (int i = 0; i < param; i++)
            dist[i] = 1000000000;
        //Calculate distances and search nearest neighbours
        for (int i = 0; i < n; i++) {
            d = AbstractDot.calcDist(pp, p[i]);
            if (cv && d==0)
                continue;
            if (d >= dist[param - 1])
                continue;
            k = param - 1;
            while ((k > 0) && (d < dist[k - 1])) {
                dist[k] = dist[k - 1];
                who[k] = who[k - 1];
                k--;
            }
            dist[k] = d;
            who[k] = i;
        }
        // calculate count of dot of one class
        int klas[] = new int[maxKlass];
        for (int i = 0; i < maxKlass; i++)
            klas[i] = 0;
        for (int i = 0; i < param; i++)
            klas[klass[who[i]]]++;
        // find max and count of max
        d = klas[0];
        n = 1;
        for (int i = 1; i < maxKlass; i++)
            if (klas[i] > d) {
                d = klas[i];
                n = 1;
            } else if (klas[i] == d)
                n++;
        //Create array of outputs
        int[] res = new int[n];
        n = 0;
        for (int i = 1; i < maxKlass; i++)
            if (klas[i] == d) {
                res[n++] = i;
            }
        //Create arrays of positions and colours of used points.
        voters = who;
        return res;
    }

    /**
     * @return array of number of voters in the list of all usable points
     * (neither all data points or prototypes if the data reduction is implemented)
     */
    @Override
    public int[] getVoters() {
        return voters;
    }

    /**
     * @return name of parameter.
     */
    @Override
    public String getParameterName() {
        return "Number of nearesr neighbours";
    }
}
