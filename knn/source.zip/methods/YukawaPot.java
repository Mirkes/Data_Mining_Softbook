package methods;

import common.AbstractDot;

import java.awt.Point;

/**
 * Class for Yukawa potential classifier.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class YukawaPot extends Classifier {
    private int[] klass;
    private Point[] pp;
    private double[][] klassMeans;
    private int[] klassCount;
    private double[][][] klassMatrix;
    private double[] klassConst;

    /**
     * @param string is the name of classifier
     */
    public YukawaPot(String string) {
        super(string);
        param = 30;
        paramMin = 5;
        paramMax = 900;
        paramStep = 5;
    }

    /**
     * @param p is array of points
     * @param klass is array of classes' of points
     */
    @Override
    public void train(Point[] p, int[] klass) {
        this.pp = p;
        this.klass = klass;
        if (useQuadrupole) {
            //Prepare data for quadrupole
            //Create arrays for data
            klassMeans = new double[maxKlass][2];
            klassCount = new int[maxKlass];
            klassMatrix = new double[maxKlass][2][2];
            klassConst = new double[maxKlass];
            //Calculate number of cases  and mean point for each class
            int nDots = p.length, k;
            for (int i = 0; i < nDots; i++) {
                k = klass[i];
                klassCount[k]++;
                klassMeans[k][0] += p[i].x;
                klassMeans[k][1] += p[i].y;
                klassMatrix[k][0][0] += p[i].x * p[i].x;
                klassMatrix[k][0][1] += p[i].x * p[i].y;
                klassMatrix[k][1][1] += p[i].y * p[i].y;
            }
            //Complite matrix calculation
            for (int i = 0; i < maxKlass; i++)
                if (klassCount[i] > 0) {
                    //Normalize means
                    klassMeans[i][0] /= klassCount[i];
                    klassMeans[i][1] /= klassCount[i];
                    //Complete calculation of the first matrix
                    klassMatrix[i][0][0] -= klassCount[i] * klassMeans[i][0] * klassMeans[i][0];
                    klassMatrix[i][0][1] -= klassCount[i] * klassMeans[i][0] * klassMeans[i][1];
                    klassMatrix[i][1][0] = klassMatrix[i][0][1];
                    klassMatrix[i][1][1] -= klassCount[i] * klassMeans[i][1] * klassMeans[i][1];
                    //Calculate squared length of vector of sum of deviation from means as constant
                    klassConst[i] = klassMatrix[i][0][0] + klassMatrix[i][1][1];
                }
        }
        ready = true;
    }

    /**
     * @param p is point to test
     * @param cv is true for exclusion of points with the same position and false otherwise
     * @return array of possible clases. If class of point pp can be exactly identified
     * (the most frequent case) then length of output array is one.
     */
    @Override
    public int[] predict(Point p, boolean cv) {
        //Get number of points
        int nDots = pp.length;
        if (nDots == 0)
            //There is no point
            return new int[0];
        // Prepare array to calculate potential
        double klas[] = new double[maxKlass];
        double d;
        int n;
        if (useQuadrupole) {
            //Prediction by quadrupole approximation
            double[] vec = new double[2];
            double lenS, len, tmp;
            //Calculate membership functions
            for (int k = 0; k < maxKlass; k++) {
                if (klassCount[k] == 0)
                    continue;
                //Calculate vector of deviation from mean
                vec[0] = p.x - klassMeans[k][0];
                vec[1] = p.y - klassMeans[k][1];
                //Calculate squared lenght of this vector
                lenS = vec[0] * vec[0] + vec[1] * vec[1];
                len = Math.sqrt(lenS);
                //Calculate value of quadratic form
                tmp = 0;
                for (int i = 0; i < 2; i++)
                    for (int j = 0; j < 2; j++)
                        tmp += vec[i] * klassMatrix[k][i][j] * vec[j];
                //Finalise calculation
                d = len / param;
                klas[k] = Math.exp(-d) / (len + 0.001) * (klassCount[k] + 0.5 / (lenS * lenS + 0.001) * //
                        (tmp * ((d + 1) * (d + 2) + 1) - lenS * (d + 1) * klassConst[k]));
                if (klas[k] < 0) {
                    System.out.print("!");
                }
            }
        } else {
            //Usual work.
            // Go over all dots
            for (int i = 0; i < nDots; i++) {
                // Calculate distance between target and current dot
                d = Math.sqrt(AbstractDot.calcDist(p, pp[i]));
                if (cv && d == 0)
                    continue;
                // Calculate potential and add sum of its class
                klas[klass[i]] += Math.exp(-d / param) / (d + 0.001);
            }
        }
        // find max position
        d = Double.NEGATIVE_INFINITY;
        ;
        n = -1;
        for (int i = 0; i < maxKlass; i++)
            if (klas[i] > d) {
                d = klas[i];
                n = i;
            }
        int[] res = new int[] { n };
        return res;
    }

    /**
     * @return empty array because all points are voters
     */
    @Override
    public int[] getVoters() {
        return new int[0];
    }

    /**
     * @return name of parameter
     */
    @Override
    public String getParameterName() {
        return "Effective radius of interaction";
    }
}
