package common;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.ArrayList;

import javax.imageio.ImageIO;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.OverlayLayout;


/**
 * It is main class for application displaying.
 * This class provide common decoration and event handling.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class MainFrame extends JFrame implements AppListener {
    @SuppressWarnings("compatibility:2274805585916438282")
    private static final long serialVersionUID = 5339092456288708198L;

    public static final Color bkGd = new Color(198, 198, 198);
    private static final JTabbedPane tabs = new JTabbedPane();
    private static final JPanel body = new JPanel();
    private static final JPanel solution = new JPanel();
    private static final JPanel data = new JPanel();
    private static Image mapImage = null;
    private static final mapPanel map = new mapPanel();
    private static final Color[] palett =
    { Color.gray, Color.BLUE, new Color(0, 128, 0), Color.red, new Color(165, 82, 0), new Color(163, 0, 163) };
    private static final int sizeX = 600;
    private static final int sizeY = 400;
    private static MainFrame me = null;

    private MainFrame(boolean useColors) {
        super();
        Container cont = this.getContentPane();
        cont.setLayout(new BorderLayout());
        //Top line
        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(bkGd);
        AddGBL.addGBLExp(pan, new UoLPane(), 1, 0, GridBagConstraints.VERTICAL);
        //Add Tabulators
        tabs.setFocusCycleRoot(true);
        addTabPanel("Data set", DataPane.getInstance(useColors));
        AddGBL.addGBLExps(pan, tabs, 0, 0, 1, 0, GridBagConstraints.BOTH);

        cont.add(pan, BorderLayout.NORTH);
        //Bottom line
        pan = new JPanel(new GridBagLayout());
        AddGBL.addGBL(pan, new CopyLeftPane(), 0, 0);
        AddGBL.addGBLExps(pan, new Label("E.Mirkes & University of Leicester, 2016"), 1, 0, 1, 0,
                          GridBagConstraints.HORIZONTAL);
        JButton b = new JButton("Save figures");
        b.setMargin(new Insets(0, 5, 0, 5));
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Todo Add fugure writing;
                String fName = FileMaintain.getFileName("eps png gif jpg", false, "File to save figure");
                if (fName.isEmpty())
                    return;
                //Get body dimension
                Dimension d = body.getSize();
                int fh = d.height;
                int fw = d.width;
                //Create graphics
                Graphics2D g;
                BufferedWriter bw;
                BufferedImage bi = null;
                if (fName.toUpperCase().endsWith(".EPS")) {
                    try {
                        bw = new BufferedWriter(new FileWriter(fName));
                        g = new MyEPSGraphics(fw, fh, "EPS figures", "E.Mirkes & University of Leicester", bw);
                    } catch (IOException ee) {
                        ee.printStackTrace();
                        return;
                    }
                } else {
                    bi = new BufferedImage(fw, fh, BufferedImage.TYPE_INT_ARGB);
                    g = bi.createGraphics();
                }
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, fw, fh);
                body.paint(g);
                if (fName.toUpperCase().endsWith(".EPS")) {
                    try {
                        ((MyEPSGraphics)g).close();
                    } catch (IOException ee) {
                        ee.printStackTrace();
                    }
                } else {
                    try {
                        ImageIO.write(bi, "png", new File(fName));
                    } catch (IOException ee) {
                        ee.printStackTrace();
                    }
                }


            }
        });
        AddGBL.addGBL(pan, b, 3, 0, GridBagConstraints.EAST);
        pan.setBackground(bkGd);
        cont.add(pan, BorderLayout.SOUTH);
        //Body
        map.setOpaque(false);
        data.setOpaque(false);
        solution.setOpaque(false);
        map.setLayout(null);
        data.setLayout(null);
        solution.setLayout(null);
        body.setLayout(new OverlayLayout(body));
        body.setBackground(Color.WHITE);
        body.add(solution);
        body.add(data);
        body.add(map);
        cont.add(body, BorderLayout.CENTER);

        //Listeners
        addAppListener(this);
        body.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                mouseClickedEvent(e);
            }
        });

        this.setSize(600, 300);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();
        this.setLocation((d.width - frameSize.width) / 2, (d.height - frameSize.height) / 2);
        this.setResizable(false);

        //Initialize required extension
        FileMaintain fm = FileMaintain.getInstance();
        fm.addFilter("txt", "Data text files *.txt");
        fm.addFilter("jpg", "Joint Photographic Experts Group *.jpg");
        fm.addFilter("png", "Portable Network Graphics *.png");
        fm.addFilter("gif", "Graphics Interchange Format *.gif");
        fm.addFilter("eps", "Encapsulated PostScript *.eps");
    }

    public final void finalResize() {
        int dx = sizeX - body.getWidth();
        int dy = sizeY - body.getHeight();
        Dimension d = this.getSize();
        this.setSize(d.width + dx, d.height + dy);
        Dimension dd = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation((dd.width - d.width - dx) / 2, (dd.height - d.height - dy) / 2);
    }

    /**
     * Method to access for unique MainForm instance.
     * @param useColors is trigger to use colours in (@link common.DataPane)
     * @return unique instance of MainForm
     */
    public static final MainFrame getInstance(boolean useColors) {
        if (me == null)
            me = new MainFrame(useColors);
        return me;
    }

    /**
     * Method to access for unique MainForm instance.
     * @return unique instance of MainForm
     */
    public static final MainFrame getInstance() {
        if (me == null)
            me = new MainFrame(false);
        return me;
    }

    /**
     * Method to access for unique body panel.
     * @return unique instance of body panel
     */
    public static final JPanel getBody() {
        return body;
    }

    /**
     * Method to access for unique data panel.
     * @return unique instance of data panel
     */
    public static final JPanel getData() {
        return data;
    }

    /**
     * @return coordinates of all data points as 2D array of doubles. Each row contains coordinates of one point.
     */
    public static final double[][] getDataPoints() {
        //Get number of components
        int n = data.getComponentCount();
        //create array for result
        double[][] res = new double[n][2];
        Point p = new Point();
        for (int i = 0; i < n; i++) {
            p = ((DataDot)data.getComponent(i)).getPos(p);
            res[i][0] = p.x;
            res[i][1] = p.y;
        }
        return res;
    }

    /**
     * @return all data points as array of DataDot.
     */
    public static final DataDot[] getDataDots() {
        //Get number of components
        int n = data.getComponentCount();
        //create array for result
        DataDot[] res = new DataDot[n];
        for (int i = 0; i < n; i++) {
            res[i] = ((DataDot)data.getComponent(i));
        }
        return res;
    }

    /**
     * Method to access for unique solution panel.
     * @return unique instance of solution panel
     */
    public static final JPanel getNodePanel() {
        return solution;
    }

    /**
     * @return size of map panel
     */
    public static final Dimension getMapSize() {
        return map.getSize();
    }

    /**
     * @param im is image to draw it onto map
     */
    public static final void putMapImage(Image im) {
        mapImage = im;
        body.repaint();
    }

    /**
     * @param i - number of palett entry
     * @return color from specified entry
     */
    public static Color getColor(int i) {
        if (i < 0)
            return palett[0];
        else
            return palett[i % palett.length];
    }

    /**
     * @return number of colors in palett
     */
    public static int getColorCount() {
        return palett.length;
    }

    /**
     * @param col is colour to identify index.
     * @return number of color in palett. If color is not in palette then return -1.
     */
    public static int getColorNumber(Color col) {
        for (int i = 0; i < palett.length; i++)
            if (palett[i].equals(col))
                return i;
        return -1;
    }

    /**
     * @return the horizontal size of work area
     */
    public static int getSizeX() {
        return sizeX;
    }

    /**
     * @return the vertical size of work area
     */
    public static int getSizeY() {
        return sizeY;
    }

    /**
     * Add new tab into tabbed pane.
     * @param name is name of added tab to display.
     * @param pan is a tab to add.
     */
    public final void addTabPanel(String name, MyMenuPane pan) {
        tabs.addTab(name, pan);
        addAppListener(pan);
    }

    /**
     * Add new information panel into body panel.
     * @param pan is a information panel to add.
     * @param place is a position to new panel put:
     * 0 left-top
     * 1 right-top
     * 2 left-bottom
     * 3 right-bottom
     * @return the new JPanel which includes input JPanel pan
     */
    public static final JPanel addInfoPanel(JPanel pan, int place) {
        //Get sizes of body
        int sizeBX = body.getWidth();
        int sizeBY = body.getHeight();
        //Get sizes of added panel
        int sizeAX = pan.getWidth();
        int sizeAY = pan.getHeight();
        //Calculate position of new panel
        int posX = 0, posY = 0;
        if (place > 1)
            posY = sizeBY - sizeAY;
        if (place % 2 == 1)
            posX = sizeBX - sizeAX;
        pan.setLocation(posX, posY);
        JPanel pp = new JPanel(null);
        pp.setOpaque(false);
        pp.add(pan);
        body.add(pp, 0);
        return pp;
    }

    /**
     * Remove information panel from body panel.
     * @param pan is a panel to remove.
     */
    public static final void removeInfoPanel(JPanel pan) {
        body.remove(pan);
    }

    private void mouseClickedEvent(MouseEvent e) {
        if (e.getButton() != MouseEvent.BUTTON1)
            return;
        ((MyMenuPane)(tabs.getSelectedComponent())).mouseEventHandler(e);
    }


    /**
     * dispatch massages
     * Listeners - list of listeners.
     */
    private transient ArrayList<AppListener> listeners = new ArrayList<AppListener>();

    /**
     * @param listener to add to the list
     */
    public void addAppListener(AppListener listener) {
        listeners.add(listener);
    }

    /**
     * @return return list of all listeners
     */
    public AppListener[] getAppListener() {
        return listeners.toArray(new AppListener[listeners.size()]);
    }

    /**
     * @param listener - listener
     */
    public void removeAppListener(AppListener listener) {
        listeners.remove(listener);
    }

    /**
     * @param iD s event identifier
     * @param param is event parameter
     * @param oParam is additional event parameter
     */
    public void fireAppHappend(int iD, int param, Object oParam) {
        AppEvent ev = new AppEvent(this, iD, param, oParam);
        for (AppListener listener : listeners)
            listener.appHappend(ev);
    }

    /**
     * @param iD - event identifier
     * @param param - event parameter
     */
    public void fireAppHappend(int iD, int param) {
        fireAppHappend(iD, param, null);
    }

    /**
     * @param iD - event identifier
     */
    public void fireAppHappend(int iD) {
        fireAppHappend(iD, 0, null);
    }

    /**
     * @param e is AppEvent to handle
     */
    @Override
    public void appHappend(AppEvent e) {
        switch (e.getID()) {
        case AppEvent.SELECT_TAB:
            {
                //Go over tabs and enable/disable as requested
                int n = e.getParam(), mask = 1;
                for (int i = 0; i < tabs.getTabCount(); i++) {
                    if ((n & mask) == mask) {
                        tabs.setEnabledAt(i, true);
                    } else {
                        tabs.setEnabledAt(i, false);
                    }
                    mask = mask << 1;
                }
                return;
            }
        case AppEvent.ENABLE_TAB: //Select tab by number/ param is the number of tab
            {
                tabs.setSelectedIndex(e.getParam());
            }
        }

    }

    public static class UoLPane extends JLabel {
        @SuppressWarnings("compatibility")
        private static final long serialVersionUID = 1L;

        public UoLPane() {
            super();
            this.setIcon(Icons.getUOLIcon());
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent ee) {
                    try {
                        Desktop desktop = Desktop.getDesktop();
                        desktop.browse(new URI("http://www2.le.ac.uk/"));
                    } catch (IOException e) {
                        return;
                    } catch (URISyntaxException e) {
                        return;
                    }
                }
            });
        }
    }

    public static class CopyLeftPane extends JLabel {
        @SuppressWarnings("compatibility")
        private static final long serialVersionUID = 1L;

        public CopyLeftPane() {
            super();
            this.setIcon(Icons.getCopyLeft());
            addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent ee) {
                    try {
                        Desktop desktop = Desktop.getDesktop();
                        desktop.browse(new URI("http://creativecommons.org/licenses/by/3.0/"));
                    } catch (IOException e) {
                        return;
                    } catch (URISyntaxException e) {
                        return;
                    }
                }
            });
        }

    }

    public static class mapPanel extends JPanel {
        @SuppressWarnings("compatibility")
        private static final long serialVersionUID = 1L;

        /**
         * @param g is Graphics to draw
         */
        public void paint(Graphics g) {
            if (mapImage == null)
                return;
            g.drawImage(mapImage, 0, 0, null);
        }
    }
}

