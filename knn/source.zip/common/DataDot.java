package common;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;

/**
 * It is descander of AbstractDot mostly used for data dots.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class DataDot extends AbstractDot {
    @SuppressWarnings("compatibility:-508646865423180081")
    private static final long serialVersionUID = 394336155014877206L;

    private static final int radius = 4;

    /**
     *
     * @param kind is kind of dot to write (see below)
     * @param pos is the position of data point
     * @param col is the color of data point
     *
     * kinds
     * 0 - nomal circle with background
     * 1 - cross
     * 2 - doubled wide circle without background
     * 3 - black border square with background
     * 4 - small four rays asteric
     * 5 - small nine rays asteric
     */

    private static final int[] bpx1 = { 12, 8, 20, 2, 24, 0, 22, 4, 16, 12 };
    private static final int[] bpy1 = { 0, 23, 3, 18, 10, 10, 18, 3, 23, 0 };
    private static final int[] spx1 = { 12, 10, 16, 7, 19, 5, 17, 8, 14, 12 };
    private static final int[] spy1 = { 5, 18, 8, 15, 11, 11, 15, 8, 18, 5 };
    private static final int[] ipx1 = { 8, 10, 14, 16, 16, 15, 12, 9, 8 };
    private static final int[] ipy1 = { 10, 8, 8, 10, 13, 15, 16, 15, 10 };

    private static final int[] bpx4 = { 12, 16, 12, 8, 12 };
    private static final int[] bpy4 = { 4, 12, 20, 12, 4 };
    private static final int[] spx4 = { 12, 15, 12, 9, 12 };
    private static final int[] spy4 = { 6, 12, 18, 12, 6 };

    /**
     * Constructor to create new data dot with coordinates of centre x and y and colour col.
     * @param x is x coordinate of centre
     * @param y is y coordinate of centre
     * @param col is colour of dot
     */
    public DataDot(int x, int y, Color col) {
        super(0, new Point(x, y), col, radius);
    }

    /**
     * Constructor to create new data dot with coordinates of centre p.x and p.y and colour col.
     * @param pos is point to specify centre
     * @param col is colour of dot
     */
    public DataDot(Point pos, Color col) {
        super(0, pos, col, radius);
    }

    /**
     * Create copy of current object.
     * @return copy of object
     */
    public AbstractDot copy() {
        DataDot dd = new DataDot(getPos(), Color.WHITE);
        dd.col = col;
        dd.kind = kind;
        dd.shift = shift;
        return dd;
    }

    /**
     * This method override the setKind for AbstractDot and change radius for some kinds.
     * @param kind is new kind of dot.
     */
    public void setKind(int kind) {
        int k = this.kind;
        super.setKind(kind);
        if (k < 4 && kind > 3) {
            setShift(11);
        } else if (k > 3 && kind < 4) {
            setShift(radius);
        }
    }

    /**
     * @param g draw point
     */
    public void paint(Graphics g) {
        g.setColor(col);
        switch (kind) {
        case 0: //nomal circle with background
            {
                g.drawOval(0, 0, 8, 8);
                g.setColor(colInside);
                g.fillOval(0, 0, 8, 8);
                break;
            }
        case 1: //cross
            {
                Graphics2D g2 = (Graphics2D)g;
                g2.setStroke(new BasicStroke(2));
                g2.drawLine(0, 0, 8, 8);
                g2.drawLine(0, 8, 8, 0);
                break;
            }
        case 2: // doubled wide circle without background
            {
                Graphics2D g2 = (Graphics2D)g;
                g2.setStroke(new BasicStroke(2));
                g2.drawOval(0, 0, 8, 8);
                break;
            }
        case 3: //black border square with background
            {
                g.fillRect(0, 0, 8, 8);
                g.setColor(Color.black);
                g.drawRect(0, 0, 8, 8);
                break;
            }
        case 4: //small four rays asteric
            {
                g.setColor(Color.black);
                g.fillPolygon(bpx4, bpy4, bpx4.length);
                g.fillPolygon(bpy4, bpx4, bpx4.length);
                g.setColor(col);
                g.fillPolygon(spx4, spy4, spx4.length);
                g.fillPolygon(spy4, spx4, spx4.length);
                break;
            }
        case 5: //small nine rays asteric
            {
                g.setColor(Color.black);
                g.fillPolygon(bpx1, bpy1, bpx1.length);
                g.setColor(col);
                g.fillPolygon(spx1, spy1, spx1.length);
                g.fillPolygon(ipx1, ipy1, ipx1.length);
                break;
            }
        }
        super.paint(g);
    }

}
