package common;

import java.awt.Container;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.WindowConstants;


/**
 * Service class to display dialogs for options request.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */

public class ParamDialog extends JDialog implements ActionListener {
    @SuppressWarnings("compatibility:1978487660382531444")
    private static final long serialVersionUID = -2240501368575563064L;
    
    private JButton bOk = new JButton("Ok");
    private JButton bCancel = new JButton("Cancel");
    private boolean isOk = false;

    /**
     * @param parent
     */
    public ParamDialog(Frame parent) {
        super(parent, "Metod options", true);
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
        getRootPane().setDefaultButton(bOk);
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(new GridBagLayout());
        this.getRootPane().setDefaultButton(bOk);
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        bOk.addActionListener(this);
        bOk.setActionCommand("Ok");
        bOk.setPreferredSize(bCancel.getPreferredSize());
        bOk.setMinimumSize(bOk.getPreferredSize());
        bCancel.addActionListener(this);
        bCancel.setActionCommand("Cancel");
    }

    /**
     * Add buttons and specify size.
     */
    public void finishCreation(){
        Container cont = this.getContentPane();
        GridBagLayout gb = (GridBagLayout)cont.getLayout();
        this.pack();
        int last = gb.getLayoutDimensions()[1].length;
        AddGBL.addGBL(cont, bOk, 0, last, GridBagConstraints.CENTER);
        AddGBL.addGBL(cont, bCancel, 1, last, GridBagConstraints.CENTER);
        this.pack();
        setLocationRelativeTo(MainFrame.getInstance());
    }


    /**
     * @return value of isOk
     */
    public boolean isOk(){
        return isOk;
    }

    /**
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if ("Ok".equals(e.getActionCommand())) {
            isOk = true;
            setVisible(false);
        } else if ("Cancel".equals(e.getActionCommand())) {
            isOk = false;
            setVisible(false);
        }
    }
}
