package common;

/**
 * Interface to control internal package events {@link AppEvent}.
 * Dispatcher - {@link common.MainFrame}.
 * 
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public interface AppListener {
    /**
     * @param e - graph event
     */
    public void appHappend(AppEvent e);
}

