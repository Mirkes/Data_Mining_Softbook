package common;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.TextAttribute;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ColorModel;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.awt.image.RenderedImage;
import java.awt.image.WritableRaster;
import java.awt.image.renderable.RenderableImage;

import java.io.BufferedWriter;
import java.io.IOException;

import java.text.AttributedCharacterIterator;
import java.text.AttributedString;
import java.text.CharacterIterator;

import java.util.Hashtable;
import java.util.Map;

/**
 * This class servrs to save image in Encapsulated Post Script format.
 * Using of this class is simple and usual:
 *
 *  Component comp is the component image on which have to be saved.
 *  MyEPSGraphics mg = new MyEPSGraphics(comp.width, comp.height,
 *                "My application name", "Copyright text",
 *                new BufferedWriter(new FileWriter("file name.eps")));
 *  comp.paint(mg);
 *  mg.close();
 *
 *  Methods of creation and closing of MyEPSGraphics create, write and
 *  close file (or other writer). These methods can throw IOExeption.
 *
 *  To use debug information is nesessary to switch on boolean field inDebug
 *  in EPSStorage. To do this method setDebug(boolean debug) is added.
 *
 *  Using of short spelling PS comands now is not optional. The usage of
 *  such trick help to obtain more short files. Since list of shortage command
 *  includes in file I decide use abbreviated and redefined commands permanently.
 *  The real list of short command is described in EPSStorage.
 *  To correct using of short command each added to storage string analised by
 *  following rule:
 *     1. the last part of string which is separated by space is found.
 *     2. if the string does not contain space then part is equal to whole string
 *     3. The found part is cheched in map of abbreviation.
 *  If you use the comman which located not in the end of string you must
 *  call setCommand method of storage to check this command. If you do not call
 *  setCommand this command can be not included in the result file.
 *
 *  There are two mode to work with fonts in this class:
 *    1. Standard mode is using Java defined Postscript names of fonts. The real
 *       existanse of fonts on computer where file will be used in this case is the
 *       problem of user. This mode can be set by using <code>encapsulateFonts(false)</code>.
 *    2. Encapsulate font to EPS file. This mode can be set by using
 *       <code>encapsulateFonts(true)</code>. In this mode all used fonts
 *       are inserted to EPS file and this file can be used without any
 *       problem but size of file in this case will be greater.
 *
 *  Since the PS does not work with transparency I exclude composite. But
 *  I like to use Alpha to change colours. For this pupose I proseed alpha
 *  composition of new colour with background colour in setColor method.
 *  To realize full transparency algorithm we must create the png (bmp, gif
 *  etc.) image and then comvert it to EPS. The result of such work will
 *  not be a pure EPS file and convertors of png, jpeg and bmp to EPS exist.
 *
 *  Sinnce the PS does not work with gradient painting I not support Paint.
 *  It is possible to implement this property latter when I understand the
 *  easy and clear way to do it.
 *
 *  Now not ready and not tested
 *  drawImage - usage of more compact binary data record
 *  Work with fonts - using of non standard fonts for PS.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class MyEPSGraphics extends Graphics2D {


    public static final int BLACK_AND_WHITE = 0;
    public static final int GRAYSCALE = 1;
    public static final int RGB = 2;

    private Color col;
    private Color bgCol;
    private Paint paint;
    private BasicStroke stroke;
    private Font font;
    private Shape clip;
    private AffineTransform transform;
    private int colorDepth;

    private EPSStorage storage;
    private MyEPSGraphics parent = null;

    private static FontRenderContext fontRenderContext = new FontRenderContext(null, false, true);

    //Debug

    /**
     * These two field is serves to debug this graphics class.
     */
    private static int newNum = 0;
    private int myNum;

    /**
     * Create a new copy of graphics.
     * For part of fields <code>(clip, transform)</code> new clones are created
     * @param meg is parent MyEPSGraphics oblect
     */
    public MyEPSGraphics(MyEPSGraphics meg) {
        super();
        myNum = newNum++;
        parent = meg;
        col = meg.col;
        bgCol = meg.bgCol;
        paint = meg.paint;
        stroke = meg.stroke;
        font = meg.font;
        clip = new Area(meg.clip);
        transform = new AffineTransform(meg.transform);
        colorDepth = meg.colorDepth;
        storage = meg.storage;
        storage.debug("Creation of " + myNum + " by copying of " + meg.getNum());
        //This call is necessary to register this object in storage
        storage.append(this, null);
    }


    /**
     * Create the first (main) <code>MyEPSGraphics</code> object.
     * All other examplar of this class are created automatically by <code>Component</code>.
     * @param width is the width of canvas
     * @param height is the height of canvas
     * @param title is the title of EPS file
     * @param copyright is the content of Copyright comment of EPS file
     * @param bw is <code>BufferedWriter</code> to write EPS file
     * @throws IOException - if an I/O error occures
     */
    public MyEPSGraphics(float width, float height, String title, String copyright,
                         BufferedWriter bw) throws IOException {
        super();

        myNum = newNum++;

        storage = new EPSStorage(width, height, title, copyright, bw);
        bgCol = Color.WHITE;
        clip = new Rectangle2D.Float(0, 0, width, height);
        transform = new AffineTransform();
        colorDepth = RGB;
        col = Color.BLACK;
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.createGraphics();
        font = null;
        setFont(g.getFont());
        setStroke(new BasicStroke());

        storage.debug("Creation " + myNum);
    }

    //debug methods

    /**
     * Set the specified debbuger state.
     * @param debug is the state to set
     */
    public void setDebug(boolean debug) {
        storage.setDebug(debug);
    }

    /**
     * Debug method.
     * @return internal number of this copy of <code>MyEPSGraphics</code>.
     */
    public int getNum() {
        return myNum;
    }

    //My own methods

    /**
     * The parent field is used by <code>EPSStorage</code> class to check the
     * order in graph stack.
     * @return the parent <code>MyEPSGraphics</code> object.
     */
    protected MyEPSGraphics getParent() {
        return parent;
    }

    /**
     * Finalise the work of <code>MyEPSGraphics</code> and linked <code>EPSStorage</code>.
     * The <code>MyEPSGraphics</code> and all it's parents and descendants will be unworkable
     * after calling of this method!
     * @throws IOException - if an I/O error occures
     */
    public void close() throws IOException {
        storage.debug(this.getNum() + " Close");
        storage.close(this);
    }

    /**
     * Convert integer to two symbols hexadecimal representation.
     * @param n is the number to convert to hexadecimal represintation
     * @return the two digital hexadecimal represintation
     */
    private String toHexString(int n) {
        String result = Integer.toHexString(n);
        while (result.length() < 2) {
            result = "0" + result;
        }
        return result;
    }

    /**
     * Service method to draw or fill shape.
     * @param s is shape to draw or fill
     * @param action is the name of command. Name must be one of the following
     * <code>st</code> (stroke) or <code>fl</code> (fill).
     */
    private void draw(Shape s, String action) {
        storage.debug(this.getNum() + " Draw shape");
        //Not work with empty shape
        if (s == null)
            return;
        storage.append(this, "np");
        int type = 0;
        float[] coords = new float[6];
        PathIterator it = s.getPathIterator(null);
        //To remember start point of next segment. It is necessary to change quadric to cube segment.
        float x0 = 0;
        float y0 = 0;
        while (!it.isDone()) {
            type = it.currentSegment(coords);

            if (type == PathIterator.SEG_CLOSE) {
                // Close path by PS command
                storage.append(this, "cp");
            } else if (type == PathIterator.SEG_CUBICTO) {
                //Cubic line
                storage.append(this, coords[0] + " " + coords[1] + " " + coords[2] + //
                        " " + coords[3] + " " + coords[4] + " " + coords[5] + " c");
                x0 = coords[4];
                y0 = coords[5];
            } else if (type == PathIterator.SEG_LINETO) {
                //Linear segment
                storage.append(this, coords[0] + " " + coords[1] + " l");
                x0 = coords[0];
                y0 = coords[1];
            } else if (type == PathIterator.SEG_MOVETO) {
                //Linear segment without line
                storage.append(this, coords[0] + " " + coords[1] + " m");
                x0 = coords[0];
                y0 = coords[1];
            } else if (type == PathIterator.SEG_QUADTO) {
                //Quadric segment. There is no quadric comand in PS
                // Transform one calibrate point to two calibrate points for the cubic
                // Bezier polinom which draw exactly the same curve
                float q1x = (x0 + 2 * coords[0]) / 3;
                float q1y = (y0 + 2 * coords[1]) / 3;
                float q2x = (2 * coords[0] + coords[2]) / 3;
                float q2y = (2 * coords[1] + coords[3]) / 3;
                storage.append(this,
                               q1x + " " + q1y + " " + q2x + " " + q2y + " " + coords[2] + " " + coords[3] + " c");
                x0 = coords[2];
                y0 = coords[3];
            }
            it.next();
        }
        storage.append(this, action);
    }

    /**
     * Set the one of the possible font work mode:
     *    1. Standard mode is using Java defined Postscript names of fonts. The real
     *       existanse of fonts on computer where file will be used in this case is the
     *       problem of user. This mode can be set by using <code>encapsulateFonts(false)</code>.
     *    2. Encapsulate font to EPS file. This mode can be set by using
     *       <code>encapsulateFonts(true)</code>. In this mode all used fonts
     *       are inserted to EPS file and this file can be used without any
     *       problem but size of file in this case will be greater.
     *
     * @param ef is true for encapsulated fonts and fale otherwise
     */
    public void encapsulateFonts(boolean ef) {
        storage.encapsulateFonts(ef);
    }

    //Graphics2D methods

    /**
     * Strokes the outline of a <code>Shape</code> using the settings of the
     * current <code>Graphics2D</code> context.  The rendering attributes
     * applied include the <code>Clip</code>, <code>Transform</code>,
     * <code>Paint</code>, <code>Composite</code> and
     * <code>Stroke</code> attributes.
     * @param s the <code>Shape</code> to be rendered
     * @see #setStroke
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see #transform
     * @see #setTransform
     * @see #clip
     * @see #setComposite
     */
    @Override
    public void draw(Shape s) {
        storage.debug(this.getNum() + " Draw shape base");
        draw(s, "st");
    }

    /**
     * Renders an image, applying a transform from image space into user space
     * before drawing.
     * The transformation from user space into device space is done with
     * the current <code>Transform</code> in the <code>Graphics2D</code>.
     * The specified transformation is applied to the image before the
     * transform attribute in the <code>Graphics2D</code> context is applied.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, and <code>Composite</code> attributes.
     * Note that no rendering is done if the specified transform is
     * noninvertible.
     * @param img the specified image to be rendered.
     *            This method does nothing if <code>img</code> is null.
     * @param xform the transformation from image space into user space
     * @param obs the {@link ImageObserver}
     * to be notified as more of the <code>Image</code>
     * is converted
     * @return <code>true</code> if the <code>Image</code> is
     * fully loaded and completely rendered, or if it's null;
     * <code>false</code> if the <code>Image</code> is still being loaded.
     * @see #transform
     * @see #setTransform
     * @see #setComposite
     * @see #clip
     */
    @Override
    public boolean drawImage(Image img, AffineTransform xform, ImageObserver obs) {
        storage.debug(this.getNum() + " Draw Image 1");
        if (xform != null && !xform.isIdentity()) {
            storage.append(this, "gs");
            double[] matr = new double[6];
            xform.getMatrix(matr);
            storage.append(this, "[" + matr[0] + " " + matr[1] + " " + matr[2] + " " + matr[3] + " " + matr[4] + //
                    " " + matr[5] + "] cc");
        }
        boolean st = drawImage(img, 0, 0, obs);
        if (xform != null && !xform.isIdentity()) {
            storage.append(this, "gr");
        }
        return st;
    }

    /**
     * Renders a <code>BufferedImage</code> that is
     * filtered with a
     * {@link BufferedImageOp}.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>
     * and <code>Composite</code> attributes.  This is equivalent to:
     * <pre>
     * img1 = op.filter(img, null);
     * drawImage(img1, new AffineTransform(1f,0f,0f,1f,x,y), null);
     * </pre>
     * @param img the specified <code>BufferedImage</code> to be rendered.
     * This method does nothing if <code>img</code> is null.
     * @param op the filter to be applied to the image before rendering
     * @param x the x coordinate of the location in user space where
     * the upper left corner of the image is rendered
     * @param y the y coordinate of the location in user space where
     * the upper left corner of the image is rendered
     *
     * @see #transform
     * @see #setTransform
     * @see #setComposite
     * @see #clip
     */
    @Override
    public void drawImage(BufferedImage img, BufferedImageOp op, int x, int y) {
        storage.debug(this.getNum() + " Draw Image 2");
        BufferedImage img1 = op.filter(img, null);
        drawImage(img1, AffineTransform.getTranslateInstance(x, y), null);
    }

    /**
     * Renders a {@link RenderedImage},
     * applying a transform from image
     * space into user space before drawing.
     * The transformation from user space into device space is done with
     * the current <code>Transform</code> in the <code>Graphics2D</code>.
     * The specified transformation is applied to the image before the
     * transform attribute in the <code>Graphics2D</code> context is applied.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, and <code>Composite</code> attributes. Note
     * that no rendering is done if the specified transform is
     * noninvertible.
     * @param img the image to be rendered. This method does
     *            nothing if <code>img</code> is null.
     * @param xform the transformation from image space into user space
     * @see #transform
     * @see #setTransform
     * @see #setComposite
     * @see #clip
     */
    @Override
    public void drawRenderedImage(RenderedImage img, AffineTransform xform) {
        storage.debug(this.getNum() + " Draw drawRenderedImage");
        Hashtable properties = new Hashtable();
        String[] names = img.getPropertyNames();
        for (int i = 0; i < names.length; i++) {
            properties.put(names[i], img.getProperty(names[i]));
        }
        ColorModel cm = img.getColorModel();
        WritableRaster wr = img.copyData(null);
        BufferedImage img1 = new BufferedImage(cm, wr, cm.isAlphaPremultiplied(), properties);
        AffineTransform at = AffineTransform.getTranslateInstance(img.getMinX(), img.getMinY());
        at.preConcatenate(xform);
        drawImage(img1, at, null);
    }

    /**
     * Renders a
     * {@link RenderableImage},
     * applying a transform from image space into user space before drawing.
     * The transformation from user space into device space is done with
     * the current <code>Transform</code> in the <code>Graphics2D</code>.
     * The specified transformation is applied to the image before the
     * transform attribute in the <code>Graphics2D</code> context is applied.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, and <code>Composite</code> attributes. Note
     * that no rendering is done if the specified transform is
     * noninvertible.
     *<p>
     * Rendering hints set on the <code>Graphics2D</code> object might
     * be used in rendering the <code>RenderableImage</code>.
     * If explicit control is required over specific hints recognized by a
     * specific <code>RenderableImage</code>, or if knowledge of which hints
     * are used is required, then a <code>RenderedImage</code> should be
     * obtained directly from the <code>RenderableImage</code>
     * and rendered using
     *{@link #drawRenderedImage(RenderedImage, AffineTransform) drawRenderedImage}.
     * @param img the image to be rendered. This method does
     *            nothing if <code>img</code> is null.
     * @param xform the transformation from image space into user space
     * @see #transform
     * @see #setTransform
     * @see #setComposite
     * @see #clip
     * @see #drawRenderedImage
     */
    @Override
    public void drawRenderableImage(RenderableImage img, AffineTransform xform) {
        storage.debug(this.getNum() + " Draw drawRenderableImage");
        drawRenderedImage(img.createDefaultRendering(), xform);
    }

    /**
     * Renders the text of the specified <code>String</code>, using the
     * current text attribute state in the <code>Graphics2D</code> context.
     * The baseline of the
     * first character is at position (<i>x</i>,&nbsp;<i>y</i>) in
     * the User Space.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, <code>Paint</code>, <code>Font</code> and
     * <code>Composite</code> attributes.  For characters in script
     * systems such as Hebrew and Arabic, the glyphs can be rendered from
     * right to left, in which case the coordinate supplied is the
     * location of the leftmost character on the baseline.
     * @param str the string to be rendered
     * @param x the x coordinate of the location where the
     * <code>String</code> should be rendered
     * @param y the y coordinate of the location where the
     * <code>String</code> should be rendered
     * @throws NullPointerException if <code>str</code> is
     *         <code>null</code>
     * @see         java.awt.Graphics#drawBytes
     * @see         java.awt.Graphics#drawChars
     * @since       JDK1.0
     */
    @Override
    public void drawString(String str, int x, int y) {
        storage.debug(this.getNum() + " Draw drawString int");
        float x1 = x, y1 = y;
        drawString(str, x1, y1);
    }

    /**
     * Renders the text specified by the specified <code>String</code>,
     * using the current text attribute state in the <code>Graphics2D</code> context.
     * The baseline of the first character is at position
     * (<i>x</i>,&nbsp;<i>y</i>) in the User Space.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, <code>Paint</code>, <code>Font</code> and
     * <code>Composite</code> attributes. For characters in script systems
     * such as Hebrew and Arabic, the glyphs can be rendered from right to
     * left, in which case the coordinate supplied is the location of the
     * leftmost character on the baseline.
     * @param s the <code>String</code> to be rendered
     * @param x the x coordinate of the location where the
     * <code>String</code> should be rendered
     * @param y the y coordinate of the location where the
     * <code>String</code> should be rendered
     * @throws NullPointerException if <code>s</code> is
     *         <code>null</code>
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see java.awt.Graphics#setFont
     * @see #setTransform
     * @see #setComposite
     */
    @Override
    public void drawString(String s, float x, float y) {
        storage.debug(this.getNum() + " Draw drawString float");
        if (s != null && !s.isEmpty()) {
            AttributedString as = new AttributedString(s);
            as.addAttribute(TextAttribute.FONT, font);
            drawString(as.getIterator(), x, y);
        }
    }

    /**
     * Renders the text of the specified iterator applying its attributes
     * in accordance with the specification of the {@link TextAttribute} class.
     * <p>
     * The baseline of the first character is at position
     * (<i>x</i>,&nbsp;<i>y</i>) in User Space.
     * For characters in script systems such as Hebrew and Arabic,
     * the glyphs can be rendered from right to left, in which case the
     * coordinate supplied is the location of the leftmost character
     * on the baseline.
     * @param iterator the iterator whose text is to be rendered
     * @param x the x coordinate where the iterator's text is to be
     * rendered
     * @param y the y coordinate where the iterator's text is to be
     * rendered
     * @throws NullPointerException if <code>iterator</code> is
     *         <code>null</code>
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see #setTransform
     * @see #setComposite
     */
    @Override
    public void drawString(AttributedCharacterIterator iterator, int x, int y) {
        storage.debug(this.getNum() + " Draw drawString attr iter 1");
        float x1 = x, y1 = y;
        drawString(iterator, x1, y1);
    }

    /**
     * Renders the text of the specified iterator applying its attributes
     * in accordance with the specification of the {@link TextAttribute} class.
     * <p>
     * The baseline of the first character is at position
     * (<i>x</i>,&nbsp;<i>y</i>) in User Space.
     * For characters in script systems such as Hebrew and Arabic,
     * the glyphs can be rendered from right to left, in which case the
     * coordinate supplied is the location of the leftmost character
     * on the baseline.
     * @param iterator the iterator whose text is to be rendered
     * @param x the x coordinate where the iterator's text is to be
     * rendered
     * @param y the y coordinate where the iterator's text is to be
     * rendered
     * @throws NullPointerException if <code>iterator</code> is
     *         <code>null</code>
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see #setTransform
     * @see #setComposite
     */
    @Override
    public void drawString(AttributedCharacterIterator iterator, float x, float y) {
        storage.debug(this.getNum() + " Draw drawString attr iter 2");
        //Set fonts using
        EPSStorage.FontInf fi = storage.getFontInf(font);
        //Move to target point save position and turn over the graphics (y axis) because we turn over it initialy
        StringBuffer buf = new StringBuffer(100);
        buf.append("(");
        for (char ch = iterator.first(); ch != CharacterIterator.DONE; ch = iterator.next()) {
            //For the PS symbols "(" and ")" are special and must be preceded by "\"
            if (ch == '(' || ch == ')') {
                buf.append('\\');
            }
            buf.append(ch);
            fi.addSymbols(ch);
        }
        buf.append(") " + x + " " + y + " s");

        storage.append(this, buf.toString());
        //draw the string and restore graphics to remove the turning over the y axis!
    }

    /**
     * Renders the text of the specified
     * {@link GlyphVector} using
     * the <code>Graphics2D</code> context's rendering attributes.
     * The rendering attributes applied include the <code>Clip</code>,
     * <code>Transform</code>, <code>Paint</code>, and
     * <code>Composite</code> attributes.  The <code>GlyphVector</code>
     * specifies individual glyphs from a {@link Font}.
     * The <code>GlyphVector</code> can also contain the glyph positions.
     * This is the fastest way to render a set of characters to the
     * screen.
     * @param g the <code>GlyphVector</code> to be rendered
     * @param x the x position in User Space where the glyphs should
     * be rendered
     * @param y the y position in User Space where the glyphs should
     * be rendered
     * @throws NullPointerException if <code>g</code> is <code>null</code>.
     *
     * @see java.awt.font.GlyphVector
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see #setTransform
     * @see #setComposite
     */
    @Override
    public void drawGlyphVector(GlyphVector g, float x, float y) {
        storage.debug(this.getNum() + " Draw drawGlyphVector");
        Shape shape = g.getOutline(x, y);
        draw(shape, "fl");
    }

    /**
     * Fills the interior of a <code>Shape</code> using the settings of the
     * <code>Graphics2D</code> context. The rendering attributes applied
     * include the <code>Clip</code>, <code>Transform</code>,
     * <code>Paint</code>, and <code>Composite</code>.
     * @param s the <code>Shape</code> to be filled
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     * @see #transform
     * @see #setTransform
     * @see #setComposite
     * @see #clip
     */
    @Override
    public void fill(Shape s) {
        storage.debug(this.getNum() + " Draw fill");
        draw(s, "fl");
    }

    /**
     * Checks whether or not the specified <code>Shape</code> intersects
     * the specified {@link Rectangle}, which is in device
     * space. If <code>onStroke</code> is false, this method checks
     * whether or not the interior of the specified <code>Shape</code>
     * intersects the specified <code>Rectangle</code>.  If
     * <code>onStroke</code> is <code>true</code>, this method checks
     * whether or not the <code>Stroke</code> of the specified
     * <code>Shape</code> outline intersects the specified
     * <code>Rectangle</code>.
     * The rendering attributes taken into account include the
     * <code>Clip</code>, <code>Transform</code>, and <code>Stroke</code>
     * attributes.
     * @param rect the area in device space to check for a hit
     * @param s the <code>Shape</code> to check for a hit
     * @param onStroke flag used to choose between testing the
     * stroked or the filled shape.  If the flag is <code>true</code>, the
     * <code>Stroke</code> oultine is tested.  If the flag is
     * <code>false</code>, the filled <code>Shape</code> is tested.
     * @return <code>true</code> if there is a hit; <code>false</code>
     * otherwise.
     * @see #setStroke
     * @see #fill
     * @see #transform
     * @see #setTransform
     * @see #clip
     */
    @Override
    public boolean hit(Rectangle rect, Shape s, boolean onStroke) {
        storage.debug(this.getNum() + " Draw hit");
        return s.intersects(rect);
    }

    /**
     * Returns the device configuration associated with this
     * <code>Graphics2D</code>.
     * @return the device configuration of this <code>Graphics2D</code>.
     */
    @Override
    public GraphicsConfiguration getDeviceConfiguration() {
        storage.debug(this.getNum() + " Draw GraphicsConfiguration");
        GraphicsConfiguration gc = null;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice[] gds = ge.getScreenDevices();
        for (int i = 0; i < gds.length; i++) {
            GraphicsDevice gd = gds[i];
            GraphicsConfiguration[] gcs = gd.getConfigurations();
            if (gcs.length > 0) {
                return gcs[0];
            }
        }
        return gc;
    }

    /**
     * Sets the <code>Composite</code> for the <code>Graphics2D</code> context.
     * The <code>Composite</code> is used in all drawing methods such as
     * <code>drawImage</code>, <code>drawString</code>, <code>draw</code>,
     * and <code>fill</code>.  It specifies how new pixels are to be combined
     * with the existing pixels on the graphics device during the rendering
     * process.
     * <p>If this <code>Graphics2D</code> context is drawing to a
     * <code>Component</code> on the display screen and the
     * <code>Composite</code> is a custom object rather than an
     * instance of the <code>AlphaComposite</code> class, and if
     * there is a security manager, its <code>checkPermission</code>
     * method is called with an <code>AWTPermission("readDisplayPixels")</code>
     * permission.
     * @param comp the <code>Composite</code> object to be used for rendering
     * @throws SecurityException
     * if a custom <code>Composite</code> object is being
     * used to render to the screen and a security manager
     * is set and its <code>checkPermission</code> method
     * does not allow the operation.
     * @see java.awt.Graphics#setXORMode
     * @see java.awt.Graphics#setPaintMode
     * @see #getComposite
     * @see java.awt.AWTPermission
     */
    @Override
    public void setComposite(Composite comp) {
        storage.debug(this.getNum() + " Draw setComposite");
    }

    /**
     * Now we work with Color only!
     *
     * Sets the <code>Paint</code> attribute for the
     * <code>Graphics2D</code> context.  Calling this method
     * with a <code>null</code> <code>Paint</code> object does
     * not have any effect on the current <code>Paint</code> attribute
     * of this <code>Graphics2D</code>.
     * @param paint the <code>Paint</code> object to be used to generate
     * color during the rendering process, or <code>null</code>
     * @see java.awt.Graphics#setColor
     * @see #getPaint
     */
    @Override
    public void setPaint(Paint paint) {
        storage.debug(this.getNum() + " Draw setPaint");
        this.paint = paint;
        if (paint instanceof Color) {
            setColor((Color)paint);
        }
    }

    /**
     * Sets the <code>Stroke</code> for the <code>Graphics2D</code> context.
     * @param s the <code>Stroke</code> object to be used to stroke a
     * <code>Shape</code> during the rendering process
     * @see BasicStroke
     * @see #getStroke
     */
    @Override
    public void setStroke(Stroke s) {
        storage.debug(this.getNum() + " Draw setStroke");
        if (s instanceof BasicStroke) {
            if (stroke != null && stroke.equals(s))
                return;
            stroke = (BasicStroke)s;
            StringBuffer buf = new StringBuffer(100);
            float miterLimit = stroke.getMiterLimit();
            if (miterLimit < 1.0f) {
                miterLimit = 1;
            }

            buf.append("[ ");
            float[] dashArray = stroke.getDashArray();
            if (dashArray != null) {
                for (int i = 0; i < dashArray.length; i++) {
                    buf.append((dashArray[i]) + " ");
                }
            }
            buf.append("] 0 ");
            buf.append(stroke.getEndCap() + " ");
            buf.append(stroke.getLineJoin() + " ");
            buf.append(miterLimit + " ");
            buf.append(stroke.getLineWidth() + " ss");
            storage.append(this, buf.toString());
        }
    }

    /**
     * Sets the value of a single preference for the rendering algorithms.
     * Hint categories include controls for rendering quality and overall
     * time/quality trade-off in the rendering process.  Refer to the
     * <code>RenderingHints</code> class for definitions of some common
     * keys and values.
     * @param hintKey the key of the hint to be set.
     * @param hintValue the value indicating preferences for the specified
     * hint category.
     * @see #getRenderingHint(RenderingHints.Key)
     * @see RenderingHints
     */
    @Override
    public void setRenderingHint(RenderingHints.Key hintKey, Object hintValue) {
        storage.debug(this.getNum() + " Draw setRenderingHint");
    }

    /**
     * Returns the value of a single preference for the rendering algorithms.
     * Hint categories include controls for rendering quality and overall
     * time/quality trade-off in the rendering process.  Refer to the
     * <code>RenderingHints</code> class for definitions of some common
     * keys and values.
     * @param hintKey the key corresponding to the hint to get.
     * @return an object representing the value for the specified hint key.
     * Some of the keys and their associated values are defined in the
     * <code>RenderingHints</code> class.
     * @see RenderingHints
     * @see #setRenderingHint(RenderingHints.Key, Object)
     */
    @Override
    public Object getRenderingHint(RenderingHints.Key hintKey) {
        storage.debug(this.getNum() + " Draw getRenderingHint");
        return null;
    }

    /**
     * Replaces the values of all preferences for the rendering
     * algorithms with the specified <code>hints</code>.
     * The existing values for all rendering hints are discarded and
     * the new set of known hints and values are initialized from the
     * specified {@link Map} object.
     * Hint categories include controls for rendering quality and
     * overall time/quality trade-off in the rendering process.
     * Refer to the <code>RenderingHints</code> class for definitions of
     * some common keys and values.
     * @param hints the rendering hints to be set
     * @see #getRenderingHints
     * @see RenderingHints
     */
    @Override
    public void setRenderingHints(Map<?, ?> hints) {
        storage.debug(this.getNum() + " Draw setRenderingHints");
    }

    /**
     * Sets the values of an arbitrary number of preferences for the
     * rendering algorithms.
     * Only values for the rendering hints that are present in the
     * specified <code>Map</code> object are modified.
     * All other preferences not present in the specified
     * object are left unmodified.
     * Hint categories include controls for rendering quality and
     * overall time/quality trade-off in the rendering process.
     * Refer to the <code>RenderingHints</code> class for definitions of
     * some common keys and values.
     * @param hints the rendering hints to be set
     * @see RenderingHints
     */
    @Override
    public void addRenderingHints(Map<?, ?> hints) {
        storage.debug(this.getNum() + " Draw addRenderingHints");
    }

    /**
     * Gets the preferences for the rendering algorithms.  Hint categories
     * include controls for rendering quality and overall time/quality
     * trade-off in the rendering process.
     * Returns all of the hint key/value pairs that were ever specified in
     * one operation.  Refer to the
     * <code>RenderingHints</code> class for definitions of some common
     * keys and values.
     * @return a reference to an instance of <code>RenderingHints</code>
     * that contains the current preferences.
     * @see RenderingHints
     * @see #setRenderingHints(Map)
     */
    @Override
    public RenderingHints getRenderingHints() {
        storage.debug(this.getNum() + " Draw getRenderingHints");
        RenderingHints rh = null;
        return rh;
    }

    /**
     * Translates the origin of the <code>Graphics2D</code> context to the
     * point (<i>x</i>,&nbsp;<i>y</i>) in the current coordinate system.
     * Modifies the <code>Graphics2D</code> context so that its new origin
     * corresponds to the point (<i>x</i>,&nbsp;<i>y</i>) in the
     * <code>Graphics2D</code> context's former coordinate system.  All
     * coordinates used in subsequent rendering operations on this graphics
     * context are relative to this new origin.
     * @param  x the specified x coordinate
     * @param  y the specified y coordinate
     * @since   JDK1.0
     */
    @Override
    public void translate(int x, int y) {
        storage.debug(this.getNum() + " Draw translate int " + x + " " + y);
        if (x == 0 && y == 0) {
            storage.debug("% ignored");
            return;
        }
        double x1 = x, y1 = y;
        translate(x1, y1);
    }

    /**
     * Concatenates the current
     * <code>Graphics2D</code> <code>Transform</code>
     * with a translation transform.
     * Subsequent rendering is translated by the specified
     * distance relative to the previous position.
     * This is equivalent to calling transform(T), where T is an
     * <code>AffineTransform</code> represented by the following matrix:
     * <pre>
     *          [   1    0    tx  ]
     *          [   0    1    ty  ]
     *          [   0    0    1   ]
     * </pre>
     * @param tx the distance to translate along the x-axis
     * @param ty the distance to translate along the y-axis
     */
    @Override
    public void translate(double tx, double ty) {
        storage.debug(this.getNum() + " Draw translate double");
        if (tx == 0 && ty == 0) {
            storage.debug("% ignored");
            return;
        }
        storage.append(this, tx + " " + ty + " tr");
        AffineTransform at = AffineTransform.getTranslateInstance(tx, ty);
        transform.concatenate(at);
        try {
            clip = at.createInverse().createTransformedShape(clip);
        } catch (NoninvertibleTransformException e) {
            ;
        }
    }

    /**
     * Concatenates the current <code>Graphics2D</code>
     * <code>Transform</code> with a rotation transform.
     * Subsequent rendering is rotated by the specified radians relative
     * to the previous origin.
     * This is equivalent to calling <code>transform(R)</code>, where R is an
     * <code>AffineTransform</code> represented by the following matrix:
     * <pre>
     *          [   cos(theta)    -sin(theta)    0   ]
     *          [   sin(theta)     cos(theta)    0   ]
     *          [       0              0         1   ]
     * </pre>
     * Rotating with a positive angle theta rotates points on the positive
     * x axis toward the positive y axis.
     * @param theta the angle of rotation in radians
     */
    @Override
    public void rotate(double theta) {
        storage.debug(this.getNum() + " Draw rotate theta");
        rotate(theta, 0, 0);
    }

    /**
     * Concatenates the current <code>Graphics2D</code>
     * <code>Transform</code> with a translated rotation
     * transform.  Subsequent rendering is transformed by a transform
     * which is constructed by translating to the specified location,
     * rotating by the specified radians, and translating back by the same
     * amount as the original translation.  This is equivalent to the
     * following sequence of calls:
     * <pre>
     *          translate(x, y);
     *          rotate(theta);
     *          translate(-x, -y);
     * </pre>
     * Rotating with a positive angle theta rotates points on the positive
     * x axis toward the positive y axis.
     * @param theta the angle of rotation in radians
     * @param x the x coordinate of the origin of the rotation
     * @param y the y coordinate of the origin of the rotation
     */
    @Override
    public void rotate(double theta, double x, double y) {
        storage.debug(this.getNum() + " Draw rotate Theta x y");
        //In accordance with documentations
        if (x != 0 || y != 0)
            storage.append(this, x + " " + y + " tr");
        storage.append(this, (theta * 180 / Math.PI) + " r");
        if (x != 0 || y != 0)
            storage.append(this, (-x) + " " + (-y) + " tr");
        AffineTransform at = AffineTransform.getRotateInstance(theta, x, y);
        transform.concatenate(at);
        try {
            clip = at.createInverse().createTransformedShape(clip);
        } catch (NoninvertibleTransformException e) {
            throw new MyEPSException("Added transform is not invertable:" + e.getMessage());
        }
    }

    /**
     * Concatenates the current <code>Graphics2D</code>
     * <code>Transform</code> with a scaling transformation
     * Subsequent rendering is resized according to the specified scaling
     * factors relative to the previous scaling.
     * This is equivalent to calling <code>transform(S)</code>, where S is an
     * <code>AffineTransform</code> represented by the following matrix:
     * <pre>
     *          [   sx   0    0   ]
     *          [   0    sy   0   ]
     *          [   0    0    1   ]
     * </pre>
     * @param sx the amount by which X coordinates in subsequent
     * rendering operations are multiplied relative to previous
     * rendering operations.
     * @param sy the amount by which Y coordinates in subsequent
     * rendering operations are multiplied relative to previous
     * rendering operations.
     */
    @Override
    public void scale(double sx, double sy) {
        storage.debug(this.getNum() + " Draw scale");
        storage.append(this, sx + " " + sy + " sc");
        AffineTransform at = AffineTransform.getScaleInstance(sx, sy);
        transform.concatenate(at);
        try {
            clip = at.createInverse().createTransformedShape(clip);
        } catch (NoninvertibleTransformException e) {
            throw new MyEPSException("Added transform is not invertable:" + e.getMessage());
        }
    }

    /**
     * Concatenates the current <code>Graphics2D</code>
     * <code>Transform</code> with a shearing transform.
     * Subsequent renderings are sheared by the specified
     * multiplier relative to the previous position.
     * This is equivalent to calling <code>transform(SH)</code>, where SH
     * is an <code>AffineTransform</code> represented by the following
     * matrix:
     * <pre>
     *          [   1   shx   0   ]
     *          [  shy   1    0   ]
     *          [   0    0    1   ]
     * </pre>
     * @param shx the multiplier by which coordinates are shifted in
     * the positive X axis direction as a function of their Y coordinate
     * @param shy the multiplier by which coordinates are shifted in
     * the positive Y axis direction as a function of their X coordinate
     */
    @Override
    public void shear(double shx, double shy) {
        storage.debug(this.getNum() + " Draw shear");
        //In accordance with documentations
        storage.append(this, "[1 " + shx + " " + shy + " 1 0 0] cc");
        AffineTransform at = AffineTransform.getShearInstance(shx, shy);
        transform.concatenate(at);
        try {
            clip = at.createInverse().createTransformedShape(clip);
        } catch (NoninvertibleTransformException e) {
            throw new MyEPSException("Added transform is not invertable:" + e.getMessage());
        }
    }

    /**
     * Composes an <code>AffineTransform</code> object with the
     * <code>Transform</code> in this <code>Graphics2D</code> according
     * to the rule last-specified-first-applied.  If the current
     * <code>Transform</code> is Cx, the result of composition
     * with Tx is a new <code>Transform</code> Cx'.  Cx' becomes the
     * current <code>Transform</code> for this <code>Graphics2D</code>.
     * Transforming a point p by the updated <code>Transform</code> Cx' is
     * equivalent to first transforming p by Tx and then transforming
     * the result by the original <code>Transform</code> Cx.  In other
     * words, Cx'(p) = Cx(Tx(p)).  A copy of the Tx is made, if necessary,
     * so further modifications to Tx do not affect rendering.
     * @param Tx the <code>AffineTransform</code> object to be composed with
     * the current <code>Transform</code>
     * @see #setTransform
     * @see AffineTransform
     */
    @Override
    public void transform(AffineTransform Tx) {
        storage.debug(this.getNum() + " Draw transform");
        double[] matr = new double[6];
        Tx.getMatrix(matr);
        storage.append(this, "[" + matr[0] + " " + matr[1] + " " + matr[2] + " " + matr[3] + " " + matr[4] + //
                " " + matr[5] + "] cc");
        transform.concatenate(Tx);
        try {
            clip = Tx.createInverse().createTransformedShape(clip);
        } catch (NoninvertibleTransformException e) {
            throw new MyEPSException("Added transform is not invertable:" + e.getMessage());
        }
    }


    /**
     * For this realization we use following ruler:
     * setTransform can be used for the saved transform only!
     * In other words: the using of setTransform is dangerous parctice.
     ********************************
     * Overwrites the Transform in the <code>Graphics2D</code> context.
     * WARNING: This method should <b>never</b> be used to apply a new
     * coordinate transform on top of an existing transform because the
     * <code>Graphics2D</code> might already have a transform that is
     * needed for other purposes, such as rendering Swing
     * components or applying a scaling transformation to adjust for the
     * resolution of a printer.
     * <p>To add a coordinate transform, use the
     * <code>transform</code>, <code>rotate</code>, <code>scale</code>,
     * or <code>shear</code> methods.  The <code>setTransform</code>
     * method is intended only for restoring the original
     * <code>Graphics2D</code> transform after rendering, as shown in this
     * example:
     * <pre><blockquote>
     * // Get the current transform
     * AffineTransform saveAT = g2.getTransform();
     * // Perform transformation
     * g2d.transform(...);
     * // Render
     * g2d.draw(...);
     * // Restore original transform
     * g2d.setTransform(saveAT);
     * </blockquote></pre>
     *
     * @param Tx the <code>AffineTransform</code> that was retrieved
     *           from the <code>getTransform</code> method
     * @see #transform
     * @see #getTransform
     * @see AffineTransform
     */
    @Override
    public void setTransform(AffineTransform Tx) {
        storage.debug(this.getNum() + " Draw setTransform DANGEROUS!");
        //The first step is to remove old transform
        //Get inverse of current transform
        AffineTransform old;
        try {
            old = transform.createInverse();
        } catch (NoninvertibleTransformException e) {
            throw new MyEPSException("Current transform is not invertable:" + e.getMessage());
        }
        double[] matr = new double[6];
        old.getMatrix(matr);
        //Apply inverse transform
        storage.append(this, "[" + matr[0] + " " + matr[1] + " " + matr[2] + " " + matr[3] + " " + matr[4] + //
                " " + matr[5] + "] cc");
        clip = transform.createTransformedShape(clip);
        //The second step is to set new transform
        if (Tx == null) {
            transform = new AffineTransform();
        } else {
            transform = new AffineTransform(Tx);
            try {
                clip = Tx.createInverse().createTransformedShape(clip);
            } catch (NoninvertibleTransformException e) {
                throw new MyEPSException("Setted transform is not invertable:" + e.getMessage());
            }
            Tx.getMatrix(matr);
            storage.append(this, "[" + matr[0] + " " + matr[1] + " " + matr[2] + " " + matr[3] + " " + matr[4] + //
                    " " + matr[5] + "] cc");
        }
    }

    /**
     * Returns a copy of the current <code>Transform</code> in the
     * <code>Graphics2D</code> context.
     * @return the current <code>AffineTransform</code> in the
     *             <code>Graphics2D</code> context.
     * @see #transform
     * @see #setTransform
     */
    @Override
    public AffineTransform getTransform() {
        storage.debug(this.getNum() + " Draw getTransform");
        return new AffineTransform(transform);
    }

    /**
     * Returns the current <code>Paint</code> of the
     * <code>Graphics2D</code> context.
     * @return the current <code>Graphics2D</code> <code>Paint</code>,
     * which defines a color or pattern.
     * @see #setPaint
     * @see java.awt.Graphics#setColor
     */
    @Override
    public Paint getPaint() {
        storage.debug(this.getNum() + " Draw getPaint");
        return paint;
    }

    /**
     * Returns the current <code>Composite</code> in the
     * <code>Graphics2D</code> context.
     * @return the current <code>Graphics2D</code> <code>Composite</code>,
     *              which defines a compositing style.
     * @see #setComposite
     */
    @Override
    public Composite getComposite() {
        storage.debug(this.getNum() + " Draw getComposite");
        return null;
    }

    /**
     * Sets the background color for the <code>Graphics2D</code> context.
     * The background color is used for clearing a region.
     * When a <code>Graphics2D</code> is constructed for a
     * <code>Component</code>, the background color is
     * inherited from the <code>Component</code>. Setting the background color
     * in the <code>Graphics2D</code> context only affects the subsequent
     * <code>clearRect</code> calls and not the background color of the
     * <code>Component</code>.  To change the background
     * of the <code>Component</code>, use appropriate methods of
     * the <code>Component</code>.
     * @param color the background color that isused in
     * subsequent calls to <code>clearRect</code>
     * @see #getBackground
     * @see java.awt.Graphics#clearRect
     */
    @Override
    public void setBackground(Color color) {
        storage.debug(this.getNum() + " Draw setBackground");
        if (color == null) {
            storage.debug("   color ignored since it is null");
            return;
        }
        bgCol = color;
    }

    /**
     * Returns the background color used for clearing a region.
     * @return the current <code>Graphics2D</code> <code>Color</code>,
     * which defines the background color.
     * @see #setBackground
     */
    @Override
    public Color getBackground() {
        storage.debug(this.getNum() + " Draw getBackground");
        return bgCol;
    }

    /**
     * Returns the current <code>Stroke</code> in the
     * <code>Graphics2D</code> context.
     * @return the current <code>Graphics2D</code> <code>Stroke</code>,
     *                 which defines the line style.
     * @see #setStroke
     */
    @Override
    public Stroke getStroke() {
        storage.debug(this.getNum() + " Draw getStroke");
        return stroke;
    }

    /**
     * Intersects the current <code>Clip</code> with the interior of the
     * specified <code>Shape</code> and sets the <code>Clip</code> to the
     * resulting intersection.  The specified <code>Shape</code> is
     * transformed with the current <code>Graphics2D</code>
     * <code>Transform</code> before being intersected with the current
     * <code>Clip</code>.  This method is used to make the current
     * <code>Clip</code> smaller.
     * To make the <code>Clip</code> larger, use <code>setClip</code>.
     * The <i>user clip</i> modified by this method is independent of the
     * clipping associated with device bounds and visibility.  If no clip has
     * previously been set, or if the clip has been cleared using
     * {@link Graphics#setClip(Shape) setClip} with a <code>null</code>
     * argument, the specified <code>Shape</code> becomes the new
     * user clip.
     * @param s the <code>Shape</code> to be intersected with the current
     *          <code>Clip</code>.  If <code>s</code> is <code>null</code>,
     *          this method clears the current <code>Clip</code>.
     */
    @Override
    public void clip(Shape s) {
        storage.debug(this.getNum() + " Draw clip");
        Area area = new Area(clip);
        Area newA = new Area(s);
        newA.intersect(area);
        if (area.equals(newA))
            return;
        clip = newA;
        if (clip instanceof Rectangle2D) {
            Rectangle r = clip.getBounds();
            storage.append(this, r.x + " " + r.y + " " + r.width + " " + r.height + " rc");
        } else
            draw(clip, "cl");
    }

    /**
     * Get the rendering context of the <code>Font</code> within this
     * <code>Graphics2D</code> context.
     * The {@link FontRenderContext}
     * encapsulates application hints such as anti-aliasing and
     * fractional metrics, as well as target device specific information
     * such as dots-per-inch.  This information should be provided by the
     * application when using objects that perform typographical
     * formatting, such as <code>Font</code> and
     * <code>TextLayout</code>.  This information should also be provided
     * by applications that perform their own layout and need accurate
     * measurements of various characteristics of glyphs such as advance
     * and line height when various rendering hints have been applied to
     * the text rendering.
     *
     * @return a reference to an instance of FontRenderContext.
     * @see java.awt.font.FontRenderContext
     * @see java.awt.font.TextLayout
     * @since     1.2
     */
    @Override
    public FontRenderContext getFontRenderContext() {
        storage.debug(this.getNum() + " Draw getFontRenderContext");
        return fontRenderContext;
    }


    //Graphics methods

    /**
     * Draws as much of the specified image as is currently available.
     * The image is drawn with its top-left corner at
     * (<i>x</i>,&nbsp;<i>y</i>) in this graphics context's coordinate
     * space. Transparent pixels in the image do not affect whatever
     * pixels are already there.
     * <p>
     * This method returns immediately in all cases, even if the
     * complete image has not yet been loaded, and it has not been dithered
     * and converted for the current output device.
     * <p>
     * If the image has completely loaded and its pixels are
     * no longer being changed, then
     * <code>drawImage</code> returns <code>true</code>.
     * Otherwise, <code>drawImage</code> returns <code>false</code>
     * and as more of
     * the image becomes available
     * or it is time to draw another frame of animation,
     * the process that loads the image notifies
     * the specified image observer.
     * @param    img the specified image to be drawn. This method does
     *               nothing if <code>img</code> is null.
     * @param    x   the <i>x</i> coordinate.
     * @param    y   the <i>y</i> coordinate.
     * @param    observer    object to be notified as more of
     *                          the image is converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see      java.awt.Image
     * @see      java.awt.image.ImageObserver
     * @see      java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     */
    @Override
    public boolean drawImage(Image img, int x, int y, ImageObserver observer) {
        storage.debug(this.getNum() + " Draw drawImage 3");
        return drawImage(img, x, y, Color.white, observer);
    }


    /**
     * Draws as much of the specified image as has already been scaled
     * to fit inside the specified rectangle.
     * <p>
     * The image is drawn inside the specified rectangle of this
     * graphics context's coordinate space, and is scaled if
     * necessary. Transparent pixels do not affect whatever pixels
     * are already there.
     * <p>
     * This method returns immediately in all cases, even if the
     * entire image has not yet been scaled, dithered, and converted
     * for the current output device.
     * If the current output representation is not yet complete, then
     * <code>drawImage</code> returns <code>false</code>. As more of
     * the image becomes available, the process that loads the image notifies
     * the image observer by calling its <code>imageUpdate</code> method.
     * <p>
     * A scaled version of an image will not necessarily be
     * available immediately just because an unscaled version of the
     * image has been constructed for this output device.  Each size of
     * the image may be cached separately and generated from the original
     * data in a separate image production sequence.
     * @param    img    the specified image to be drawn. This method does
     *                  nothing if <code>img</code> is null.
     * @param    x      the <i>x</i> coordinate.
     * @param    y      the <i>y</i> coordinate.
     * @param    width  the width of the rectangle.
     * @param    height the height of the rectangle.
     * @param    observer    object to be notified as more of
     *                          the image is converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see      java.awt.Image
     * @see      java.awt.image.ImageObserver
     * @see      java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     */
    @Override
    public boolean drawImage(Image img, int x, int y, int width, int height, ImageObserver observer) {
        storage.debug(this.getNum() + " Draw drawImage 4");
        return drawImage(img, x, y, width, height, Color.white, observer);
    }


    /**
     * Draws as much of the specified image as is currently available.
     * The image is drawn with its top-left corner at
     * (<i>x</i>,&nbsp;<i>y</i>) in this graphics context's coordinate
     * space.  Transparent pixels are drawn in the specified
     * background color.
     * <p>
     * This operation is equivalent to filling a rectangle of the
     * width and height of the specified image with the given color and then
     * drawing the image on top of it, but possibly more efficient.
     * <p>
     * This method returns immediately in all cases, even if the
     * complete image has not yet been loaded, and it has not been dithered
     * and converted for the current output device.
     * <p>
     * If the image has completely loaded and its pixels are
     * no longer being changed, then
     * <code>drawImage</code> returns <code>true</code>.
     * Otherwise, <code>drawImage</code> returns <code>false</code>
     * and as more of
     * the image becomes available
     * or it is time to draw another frame of animation,
     * the process that loads the image notifies
     * the specified image observer.
     * @param    img the specified image to be drawn. This method does
     *               nothing if <code>img</code> is null.
     * @param    x      the <i>x</i> coordinate.
     * @param    y      the <i>y</i> coordinate.
     * @param    bgcolor the background color to paint under the
     *                         non-opaque portions of the image.
     * @param    observer    object to be notified as more of
     *                          the image is converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see      java.awt.Image
     * @see      java.awt.image.ImageObserver
     * @see      java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     */
    @Override
    public boolean drawImage(Image img, int x, int y, Color bgcolor, ImageObserver observer) {
        storage.debug(this.getNum() + " Draw drawImage 5");
        if (img == null)
            return true;
        return drawImage(img, x, y, img.getWidth(null), img.getHeight(null), bgcolor, observer);
    }


    /**
     * Draws as much of the specified image as has already been scaled
     * to fit inside the specified rectangle.
     * <p>
     * The image is drawn inside the specified rectangle of this
     * graphics context's coordinate space, and is scaled if
     * necessary. Transparent pixels are drawn in the specified
     * background color.
     * This operation is equivalent to filling a rectangle of the
     * width and height of the specified image with the given color and then
     * drawing the image on top of it, but possibly more efficient.
     * <p>
     * This method returns immediately in all cases, even if the
     * entire image has not yet been scaled, dithered, and converted
     * for the current output device.
     * If the current output representation is not yet complete then
     * <code>drawImage</code> returns <code>false</code>. As more of
     * the image becomes available, the process that loads the image notifies
     * the specified image observer.
     * <p>
     * A scaled version of an image will not necessarily be
     * available immediately just because an unscaled version of the
     * image has been constructed for this output device.  Each size of
     * the image may be cached separately and generated from the original
     * data in a separate image production sequence.
     * @param    img       the specified image to be drawn. This method does
     *                     nothing if <code>img</code> is null.
     * @param    x         the <i>x</i> coordinate.
     * @param    y         the <i>y</i> coordinate.
     * @param    width     the width of the rectangle.
     * @param    height    the height of the rectangle.
     * @param    bgcolor   the background color to paint under the
     *                         non-opaque portions of the image.
     * @param    observer    object to be notified as more of
     *                          the image is converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see      java.awt.Image
     * @see      java.awt.image.ImageObserver
     * @see      java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     */
    @Override
    public boolean drawImage(Image img, int x, int y, int width, int height, Color bgcolor, ImageObserver observer) {
        storage.debug(this.getNum() + " Draw drawImage 6");
        return drawImage(img, x, y, x + width, y + height, 0, 0, width, height, bgcolor, observer);
    }


    /**
     * Draws as much of the specified area of the specified image as is
     * currently available, scaling it on the fly to fit inside the
     * specified area of the destination drawable surface. Transparent pixels
     * do not affect whatever pixels are already there.
     * <p>
     * This method returns immediately in all cases, even if the
     * image area to be drawn has not yet been scaled, dithered, and converted
     * for the current output device.
     * If the current output representation is not yet complete then
     * <code>drawImage</code> returns <code>false</code>. As more of
     * the image becomes available, the process that loads the image notifies
     * the specified image observer.
     * <p>
     * This method always uses the unscaled version of the image
     * to render the scaled rectangle and performs the required
     * scaling on the fly. It does not use a cached, scaled version
     * of the image for this operation. Scaling of the image from source
     * to destination is performed such that the first coordinate
     * of the source rectangle is mapped to the first coordinate of
     * the destination rectangle, and the second source coordinate is
     * mapped to the second destination coordinate. The subimage is
     * scaled and flipped as needed to preserve those mappings.
     * @param       img the specified image to be drawn. This method does
     *                  nothing if <code>img</code> is null.
     * @param       dx1 the <i>x</i> coordinate of the first corner of the
     *                    destination rectangle.
     * @param       dy1 the <i>y</i> coordinate of the first corner of the
     *                    destination rectangle.
     * @param       dx2 the <i>x</i> coordinate of the second corner of the
     *                    destination rectangle.
     * @param       dy2 the <i>y</i> coordinate of the second corner of the
     *                    destination rectangle.
     * @param       sx1 the <i>x</i> coordinate of the first corner of the
     *                    source rectangle.
     * @param       sy1 the <i>y</i> coordinate of the first corner of the
     *                    source rectangle.
     * @param       sx2 the <i>x</i> coordinate of the second corner of the
     *                    source rectangle.
     * @param       sy2 the <i>y</i> coordinate of the second corner of the
     *                    source rectangle.
     * @param       observer object to be notified as more of the image is
     *                    scaled and converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see         java.awt.Image
     * @see         java.awt.image.ImageObserver
     * @see         java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     * @since       JDK1.1
     */
    @Override
    public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
                             ImageObserver observer) {
        storage.debug(this.getNum() + " Draw drawImage 7");
        return drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, Color.white, observer);
    }

    /**
     * @return true if img is null and if specified rectangles have incorrect sizes:
     *   if (dx1 >= dx2)
     *   if (sx1 >= sx2)
     *   if (dy1 >= dy2)
     *   if (sy1 >= sy2)
     */

    /**
     * Draws as much of the specified area of the specified image as is
     * currently available, scaling it on the fly to fit inside the
     * specified area of the destination drawable surface.
     * <p>
     * Transparent pixels are drawn in the specified background color.
     * This operation is equivalent to filling a rectangle of the
     * width and height of the specified image with the given color and then
     * drawing the image on top of it, but possibly more efficient.
     * <p>
     * This method returns immediately in all cases, even if the
     * image area to be drawn has not yet been scaled, dithered, and converted
     * for the current output device.
     * If the current output representation is not yet complete then
     * <code>drawImage</code> returns <code>false</code>. As more of
     * the image becomes available, the process that loads the image notifies
     * the specified image observer.
     * <p>
     * This method always uses the unscaled version of the image
     * to render the scaled rectangle and performs the required
     * scaling on the fly. It does not use a cached, scaled version
     * of the image for this operation. Scaling of the image from source
     * to destination is performed such that the first coordinate
     * of the source rectangle is mapped to the first coordinate of
     * the destination rectangle, and the second source coordinate is
     * mapped to the second destination coordinate. The subimage is
     * scaled and flipped as needed to preserve those mappings.
     * @param       img the specified image to be drawn. This method does
     *                  nothing if <code>img</code> is null.
     * @param       dx1 the <i>x</i> coordinate of the first corner of the
     *                    destination rectangle.
     * @param       dy1 the <i>y</i> coordinate of the first corner of the
     *                    destination rectangle.
     * @param       dx2 the <i>x</i> coordinate of the second corner of the
     *                    destination rectangle.
     * @param       dy2 the <i>y</i> coordinate of the second corner of the
     *                    destination rectangle.
     * @param       sx1 the <i>x</i> coordinate of the first corner of the
     *                    source rectangle.
     * @param       sy1 the <i>y</i> coordinate of the first corner of the
     *                    source rectangle.
     * @param       sx2 the <i>x</i> coordinate of the second corner of the
     *                    source rectangle.
     * @param       sy2 the <i>y</i> coordinate of the second corner of the
     *                    source rectangle.
     * @param       bgcolor the background color to paint under the
     *                    non-opaque portions of the image.
     * @param       observer object to be notified as more of the image is
     *                    scaled and converted.
     * @return   <code>false</code> if the image pixels are still changing;
     *           <code>true</code> otherwise.
     * @see         java.awt.Image
     * @see         java.awt.image.ImageObserver
     * @see         java.awt.image.ImageObserver#imageUpdate(java.awt.Image, int, int, int, int, int)
     * @since       JDK1.1
     */
    @Override
    public boolean drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2,
                             Color bgcolor, ImageObserver observer) {
        //@param       img the specified image to be drawn. This method does
        //             nothing if <code>img</code> is null.
        storage.debug(this.getNum() + " Draw drawImage 8");
        if (img == null)
            return true;
        if (dx1 >= dx2)
            return true;
        if (sx1 >= sx2)
            return true;
        if (dy1 >= dy2)
            return true;
        if (sy1 >= sy2)
            return true;

        //Calculate the auxiliary variables
        int sWidth = sx2 - sx1;
        int sHeight = sy2 - sy1;
        int dWidth = dx2 - dx1;
        int dHeight = dy2 - dy1;

        //Get pixel information
        int[] pix = new int[sWidth * sHeight];
        PixelGrabber pg = new PixelGrabber(img, sx1, sy1, sx2 - sx1, sy2 - sy1, pix, 0, sWidth);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
            return false;
        }

        //Create transformation for the image
        AffineTransform at = new AffineTransform();
        at.scale(sWidth / (double)dWidth, sHeight / (double)dHeight);
        at.translate(-dx1, -dy1);

        //Save current state of graphics write procedure
        storage.append(this, "gs");
        //store currant debuger state and swithch debugger of
        boolean inDebug = storage.isDebugged();
        storage.setDebug(false);
        double[] matr = new double[6];
        at.getMatrix(matr);
        storage.append(this,
                       sWidth + " " + sHeight + " 8 [" + matr[0] + " " + matr[1] + " " + matr[2] + " " + matr[3] +
                       " " + matr[4] + " " + matr[5] + "]");
        if (colorDepth == BLACK_AND_WHITE) {
            // Should really use imagemask.
            storage.append(this, "{currentfile " + sWidth + " string readhexstring pop} bind");
            storage.append(this, "image");
        } else if (colorDepth == GRAYSCALE) {
            storage.append(this, "{currentfile " + sWidth + " string readhexstring pop} bind");
            storage.append(this, "image");
        } else {
            storage.append(this, "{currentfile 3 " + sWidth + " mul string readhexstring pop} bind");
            storage.append(this, "false 3 colorimage");
        }
        //Write data
        StringBuffer buf = new StringBuffer(90);
        for (int y = 0; y < sHeight; y++) {
            for (int x = 0; x < sWidth; x++) {
                Color color = new Color(pix[x + sWidth * y]);
                //Change the transparent color
                if (color.equals(bgcolor))
                    color = bgCol;

                if (colorDepth == BLACK_AND_WHITE) {
                    if ((color.getRed() + color.getGreen() + color.getBlue()) / 3d > 127) {
                        buf.append("ff");
                    } else {
                        buf.append("00");
                    }
                } else if (colorDepth == GRAYSCALE) {
                    buf.append(toHexString((color.getRed() + color.getGreen() + color.getBlue()) / 3));
                } else {
                    buf.append(toHexString(color.getRed()) + toHexString(color.getGreen()) +
                               toHexString(color.getBlue()));
                }

                if (buf.length() > 80) {
                    storage.append(this, buf.toString());
                    buf.setLength(0);
                }
            }
        }
        if (buf.length() > 0) {
            storage.append(this, buf.toString());
        }

        //Restore debugger state
        if (inDebug)
            storage.setDebug(inDebug);

        //Restore the graphics
        storage.append(this, "gr");

        return true;
    }

    /**
     * Creates a new <code>Graphics</code> object that is
     * a copy of this <code>Graphics</code> object.
     * @return     a new graphics context that is a copy of
     *                       this graphics context.
     */
    @Override
    public Graphics create() {
        return new MyEPSGraphics(this);
    }

    /**
     * Gets this graphics context's current color.
     * @return    this graphics context's current color.
     * @see       java.awt.Color
     * @see       java.awt.Graphics#setColor(Color)
     */
    @Override
    public Color getColor() {
        storage.debug(this.getNum() + " Draw getColor");
        return col;
    }

    /**
     * Sets this graphics context's current color to the specified
     * color. All subsequent graphics operations using this graphics
     * context use this specified color.
     * @param     color   the new rendering color.
     * @see       java.awt.Color
     * @see       java.awt.Graphics#getColor
     */
    @Override
    public void setColor(Color color) {
        storage.debug(this.getNum() + " Draw setColor final");
        if (color == null) {
            storage.debug("   color ignored since it is null");
            return;
        }
        if (col.equals(color))
            return;
        col = color;
        //Get float values of new colour
        float[] newCol = color.getRGBComponents(null);

        if (colorDepth == BLACK_AND_WHITE) {
            float value = 0;
            if (newCol[0] + newCol[1] + newCol[2] > 0.5) {
                value = 1;
            }
            storage.append(this, value + " sg");
        } else if (colorDepth == GRAYSCALE) {
            float value = (newCol[0] + newCol[1] + newCol[2]) / 3;
            storage.append(this, value + " sg");
        } else {
            //If alpha is less than 1 then proseed alpha composition of new colour with bgColor
            if (newCol[3] < 1) {
                //Get float values of old colour
                float[] oldCol = bgCol.getRGBComponents(null);
                for (int i = 0; i < 3; i++)
                    newCol[i] = newCol[i] * newCol[3] + oldCol[i] * (1 - newCol[3]);
            }
            storage.append(this, newCol[0] + " " + newCol[1] + " " + newCol[2] + " srgb");
        }
    }

    /**
     * Sets the paint mode of this graphics context to overwrite the
     * destination with this graphics context's current color.
     * This sets the logical pixel operation function to the paint or
     * overwrite mode.  All subsequent rendering operations will
     * overwrite the destination with the current color.
     */
    @Override
    public void setPaintMode() {
        storage.debug(this.getNum() + " Draw setPaintMode");
    }

    /**
     * Sets the paint mode of this graphics context to alternate between
     * this graphics context's current color and the new specified color.
     * This specifies that logical pixel operations are performed in the
     * XOR mode, which alternates pixels between the current color and
     * a specified XOR color.
     * <p>
     * When drawing operations are performed, pixels which are the
     * current color are changed to the specified color, and vice versa.
     * <p>
     * Pixels that are of colors other than those two colors are changed
     * in an unpredictable but reversible manner; if the same figure is
     * drawn twice, then all pixels are restored to their original values.
     * @param     c1 the XOR alternation color
     */
    @Override
    public void setXORMode(Color c1) {
        storage.debug(this.getNum() + " Draw setXORMode");
    }

    /**
     * Gets the current font.
     * @return    this graphics context's current font.
     * @see       java.awt.Font
     * @see       java.awt.Graphics#setFont(Font)
     */
    @Override
    public Font getFont() {
        storage.debug(this.getNum() + " Draw getFont");
        return font;
    }

    /**
     * Sets this graphics context's font to the specified font.
     * All subsequent text operations using this graphics context
     * use this font. A null argument is silently ignored.
     * @param  newFont   the font.
     * @see     java.awt.Graphics#getFont
     * @see     java.awt.Graphics#drawString(java.lang.String, int, int)
     * @see     java.awt.Graphics#drawBytes(byte[], int, int, int, int)
     * @see     java.awt.Graphics#drawChars(char[], int, int, int, int)
     */
    @Override
    public void setFont(Font newFont) {
        storage.debug(this.getNum() + " Draw setFont");
        if (newFont == null) {
            newFont = Font.decode(null);
        }
        //Check for the differences between Fonts
        if (newFont.equals(font))
            return;
        font = newFont;
        EPSStorage.FontInf fi = storage.getFontInf(font);
        storage.append(this, "f" + fi.fontNum);
    }

    /**
     * Gets the font metrics for the specified font.
     * @param f the specified font
     * @return the font metrics for the specified font.
     * @see java.awt.Graphics#getFont
     * @see java.awt.FontMetrics
     * @see java.awt.Graphics#getFontMetrics()
     */
    @Override
    public FontMetrics getFontMetrics(Font f) {
        storage.debug(this.getNum() + " Draw getFontMetrics");
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
        Graphics g = image.getGraphics();
        return g.getFontMetrics(f);
    }

    /**
     * Returns the bounding rectangle of the current clipping area.
     * This method refers to the user clip, which is independent of the
     * clipping associated with device bounds and window visibility.
     * If no clip has previously been set, or if the clip has been
     * cleared using <code>setClip(null)</code>, this method returns
     * <code>null</code>.
     * The coordinates in the rectangle are relative to the coordinate
     * system origin of this graphics context.
     * @return      the bounding rectangle of the current clipping area,
     *              or <code>null</code> if no clip is set.
     * @see         java.awt.Graphics#getClip
     * @see         java.awt.Graphics#clipRect
     * @see         java.awt.Graphics#setClip(int, int, int, int)
     * @see         java.awt.Graphics#setClip(Shape)
     * @since       JDK1.1
     */
    @Override
    public Rectangle getClipBounds() {
        storage.debug(this.getNum() + " Draw getClipBounds " + clip.getBounds());
        if (clip == null) {
            return null;
        }
        return clip.getBounds();
    }

    /**
     * Intersects the current clip with the specified rectangle.
     * The resulting clipping area is the intersection of the current
     * clipping area and the specified rectangle.  If there is no
     * current clipping area, either because the clip has never been
     * set, or the clip has been cleared using <code>setClip(null)</code>,
     * the specified rectangle becomes the new clip.
     * This method sets the user clip, which is independent of the
     * clipping associated with device bounds and window visibility.
     * This method can only be used to make the current clip smaller.
     * To set the current clip larger, use any of the setClip methods.
     * Rendering operations have no effect outside of the clipping area.
     * @param x the x coordinate of the rectangle to intersect the clip with
     * @param y the y coordinate of the rectangle to intersect the clip with
     * @param width the width of the rectangle to intersect the clip with
     * @param height the height of the rectangle to intersect the clip with
     * @see #setClip(int, int, int, int)
     * @see #setClip(Shape)
     */
    @Override
    public void clipRect(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw clipRect");
        Area area = new Area(clip);
        Area newA = new Area(new Rectangle(x, y, width, height));
        newA.intersect(area);
        if (area.equals(newA))
            return;
        clip = newA;
        storage.append(this, x + " " + y + " " + width + " " + height + " rc");
    }

    /**
     * Sets the current clip to the rectangle specified by the given
     * coordinates.  This method sets the user clip, which is
     * independent of the clipping associated with device bounds
     * and window visibility.
     * Rendering operations have no effect outside of the clipping area.
     * @param       x the <i>x</i> coordinate of the new clip rectangle.
     * @param       y the <i>y</i> coordinate of the new clip rectangle.
     * @param       width the width of the new clip rectangle.
     * @param       height the height of the new clip rectangle.
     * @see         java.awt.Graphics#clipRect
     * @see         java.awt.Graphics#setClip(Shape)
     * @see         java.awt.Graphics#getClip
     * @since       JDK1.1
     */
    @Override
    public void setClip(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw setClip");
        storage.append(this, "ic " + x + " " + y + " " + width + " " + height + " rc");
        storage.setCommand("ic");
        clip = new Rectangle(x, y, width, height);
    }

    /**
     * Sets the current clipping area to an arbitrary clip shape.
     * Not all objects that implement the <code>Shape</code>
     * interface can be used to set the clip.  The only
     * <code>Shape</code> objects that are guaranteed to be
     * supported are <code>Shape</code> objects that are
     * obtained via the <code>getClip</code> method and via
     * <code>Rectangle</code> objects.  This method sets the
     * user clip, which is independent of the clipping associated
     * with device bounds and window visibility.
     * @param clip the <code>Shape</code> to use to set the clip
     * @see         java.awt.Graphics#getClip()
     * @see         java.awt.Graphics#clipRect
     * @see         java.awt.Graphics#setClip(int, int, int, int)
     * @since       JDK1.1
     */
    @Override
    public void setClip(Shape clip) {
        if (clip == null)
            throw new MyEPSException("Try to set null clip!");
        storage.debug(this.getNum() + " Draw setClip");
        storage.append(this, "ic");
        //Check to rectangle
        if (clip instanceof Rectangle2D) {
            Rectangle r = clip.getBounds();
            storage.append(this, r.x + " " + r.y + " " + r.width + " " + r.height + " rc");
        } else
            draw(clip, "cl");
        this.clip = clip;
    }

    /**
     * Gets the current clipping area.
     * This method returns the user clip, which is independent of the
     * clipping associated with device bounds and window visibility.
     * If no clip has previously been set, or if the clip has been
     * cleared using <code>setClip(null)</code>, this method returns
     * <code>null</code>.
     * @return      a <code>Shape</code> object representing the
     *              current clipping area, or <code>null</code> if
     *              no clip is set.
     * @see         java.awt.Graphics#getClipBounds
     * @see         java.awt.Graphics#clipRect
     * @see         java.awt.Graphics#setClip(int, int, int, int)
     * @see         java.awt.Graphics#setClip(Shape)
     * @since       JDK1.1
     */
    @Override
    public Shape getClip() {
        storage.debug(this.getNum() + " Draw getClip");
        return clip;
    }

    /**
     * Cannot be implemented for EPS files.
     **************
     * Copies an area of the component by a distance specified by
     * <code>dx</code> and <code>dy</code>. From the point specified
     * by <code>x</code> and <code>y</code>, this method
     * copies downwards and to the right.  To copy an area of the
     * component to the left or upwards, specify a negative value for
     * <code>dx</code> or <code>dy</code>.
     * If a portion of the source rectangle lies outside the bounds
     * of the component, or is obscured by another window or component,
     * <code>copyArea</code> will be unable to copy the associated
     * pixels. The area that is omitted can be refreshed by calling
     * the component's <code>paint</code> method.
     * @param       x the <i>x</i> coordinate of the source rectangle.
     * @param       y the <i>y</i> coordinate of the source rectangle.
     * @param       width the width of the source rectangle.
     * @param       height the height of the source rectangle.
     * @param       dx the horizontal distance to copy the pixels.
     * @param       dy the vertical distance to copy the pixels.
     */
    @Override
    public void copyArea(int x, int y, int width, int height, int dx, int dy) {
        storage.debug(this.getNum() + " Draw copyArea");
    }

    /**
     * Draws a line, using the current color, between the points
     * <code>(x1,&nbsp;y1)</code> and <code>(x2,&nbsp;y2)</code>
     * in this graphics context's coordinate system.
     * @param   x1  the first point's <i>x</i> coordinate.
     * @param   y1  the first point's <i>y</i> coordinate.
     * @param   x2  the second point's <i>x</i> coordinate.
     * @param   y2  the second point's <i>y</i> coordinate.
     */
    @Override
    public void drawLine(int x1, int y1, int x2, int y2) {
        storage.debug(this.getNum() + " Draw drawLine");
        storage.append(this, x1 + " " + y1 + " " + x2 + " " + y2 + " LI");
    }

    /**
     * Fills the specified rectangle.
     * The left and right edges of the rectangle are at
     * <code>x</code> and <code>x&nbsp;+&nbsp;width&nbsp;-&nbsp;1</code>.
     * The top and bottom edges are at
     * <code>y</code> and <code>y&nbsp;+&nbsp;height&nbsp;-&nbsp;1</code>.
     * The resulting rectangle covers an area
     * <code>width</code> pixels wide by
     * <code>height</code> pixels tall.
     * The rectangle is filled using the graphics context's current color.
     * @param         x   the <i>x</i> coordinate
     *                         of the rectangle to be filled.
     * @param         y   the <i>y</i> coordinate
     *                         of the rectangle to be filled.
     * @param         width   the width of the rectangle to be filled.
     * @param         height   the height of the rectangle to be filled.
     * @see           java.awt.Graphics#clearRect
     * @see           java.awt.Graphics#drawRect
     */
    @Override
    public void fillRect(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw fillRect");
        storage.append(this, x + " " + y + " " + (width + 0.5) + " " + (height + 0.5) + " rf");
    }

    /**
     * Draws the outline of the specified rectangle.
     * The left and right edges of the rectangle are at
     * <code>x</code> and <code>x&nbsp;+&nbsp;width</code>.
     * The top and bottom edges are at
     * <code>y</code> and <code>y&nbsp;+&nbsp;height</code>.
     * The rectangle is drawn using the graphics context's current color.
     * @param         x   the <i>x</i> coordinate
     *                         of the rectangle to be drawn.
     * @param         y   the <i>y</i> coordinate
     *                         of the rectangle to be drawn.
     * @param         width   the width of the rectangle to be drawn.
     * @param         height   the height of the rectangle to be drawn.
     * @see          java.awt.Graphics#fillRect
     * @see          java.awt.Graphics#clearRect
     */
    @Override
    public void drawRect(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw drawRect");
        storage.append(this, x + " " + y + " " + width + " " + height + " rs");
    }

    /**
     * Clears the specified rectangle by filling it with the background
     * color of the current drawing surface. This operation does not
     * use the current paint mode.
     * <p>
     * Beginning with Java&nbsp;1.1, the background color
     * of offscreen images may be system dependent. Applications should
     * use <code>setColor</code> followed by <code>fillRect</code> to
     * ensure that an offscreen image is cleared to a specific color.
     * @param       x the <i>x</i> coordinate of the rectangle to clear.
     * @param       y the <i>y</i> coordinate of the rectangle to clear.
     * @param       width the width of the rectangle to clear.
     * @param       height the height of the rectangle to clear.
     * @see         java.awt.Graphics#fillRect(int, int, int, int)
     * @see         java.awt.Graphics#drawRect
     * @see         java.awt.Graphics#setColor(java.awt.Color)
     * @see         java.awt.Graphics#setPaintMode
     * @see         java.awt.Graphics#setXORMode(java.awt.Color)
     */
    @Override
    public void clearRect(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw clearRect");
        Color old = getColor();
        setColor(bgCol);
        storage.append(this, x + " " + y + " " + width + " " + height + " rf");
        setColor(old);
    }

    /**
     * Draws an outlined round-cornered rectangle using this graphics
     * context's current color. The left and right edges of the rectangle
     * are at <code>x</code> and <code>x&nbsp;+&nbsp;width</code>,
     * respectively. The top and bottom edges of the rectangle are at
     * <code>y</code> and <code>y&nbsp;+&nbsp;height</code>.
     * @param      x the <i>x</i> coordinate of the rectangle to be drawn.
     * @param      y the <i>y</i> coordinate of the rectangle to be drawn.
     * @param      width the width of the rectangle to be drawn.
     * @param      height the height of the rectangle to be drawn.
     * @param      arcWidth the horizontal diameter of the arc
     *                    at the four corners.
     * @param      arcHeight the vertical diameter of the arc
     *                    at the four corners.
     * @see        java.awt.Graphics#fillRoundRect
     */
    @Override
    public void drawRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        storage.debug(this.getNum() + " Draw drawRoundRect");
        Shape shape = new RoundRectangle2D.Float(x, y, width, height, arcWidth, arcHeight);
        draw(shape, "st");
    }

    /**
     * Fills the specified rounded corner rectangle with the current color.
     * The left and right edges of the rectangle
     * are at <code>x</code> and <code>x&nbsp;+&nbsp;width&nbsp;-&nbsp;1</code>,
     * respectively. The top and bottom edges of the rectangle are at
     * <code>y</code> and <code>y&nbsp;+&nbsp;height&nbsp;-&nbsp;1</code>.
     * @param       x the <i>x</i> coordinate of the rectangle to be filled.
     * @param       y the <i>y</i> coordinate of the rectangle to be filled.
     * @param       width the width of the rectangle to be filled.
     * @param       height the height of the rectangle to be filled.
     * @param       arcWidth the horizontal diameter
     *                     of the arc at the four corners.
     * @param       arcHeight the vertical diameter
     *                     of the arc at the four corners.
     * @see         java.awt.Graphics#drawRoundRect
     */
    @Override
    public void fillRoundRect(int x, int y, int width, int height, int arcWidth, int arcHeight) {
        storage.debug(this.getNum() + " Draw fillRoundRect");
        Shape shape = new RoundRectangle2D.Float(x, y, width, height, arcWidth, arcHeight);
        draw(shape, "fl");
    }

    /**
     * Draws the outline of an oval.
     * The result is a circle or ellipse that fits within the
     * rectangle specified by the <code>x</code>, <code>y</code>,
     * <code>width</code>, and <code>height</code> arguments.
     * <p>
     * The oval covers an area that is
     * <code>width&nbsp;+&nbsp;1</code> pixels wide
     * and <code>height&nbsp;+&nbsp;1</code> pixels tall.
     * @param       x the <i>x</i> coordinate of the upper left
     *                     corner of the oval to be drawn.
     * @param       y the <i>y</i> coordinate of the upper left
     *                     corner of the oval to be drawn.
     * @param       width the width of the oval to be drawn.
     * @param       height the height of the oval to be drawn.
     * @see         java.awt.Graphics#fillOval
     */
    @Override
    public void drawOval(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw drawOval");
        //Calculate the transformation of circle
        double trans = 1;
        trans = width / (double)height;
        double radX = width / 2d;
        double radY = height / 2d;
        storage.append(this, radY + " " + trans + " " + (x + radX) + " " + (y + radY) + " " + " do");
    }

    /**
     * Fills an oval bounded by the specified rectangle with the
     * current color.
     * @param       x the <i>x</i> coordinate of the upper left corner
     *                     of the oval to be filled.
     * @param       y the <i>y</i> coordinate of the upper left corner
     *                     of the oval to be filled.
     * @param       width the width of the oval to be filled.
     * @param       height the height of the oval to be filled.
     * @see         java.awt.Graphics#drawOval
     */
    @Override
    public void fillOval(int x, int y, int width, int height) {
        storage.debug(this.getNum() + " Draw fillOval");
        //Calculate the transformation of circle
        double trans = 1;
        trans = width / (double)height;
        double radX = width / 2d;
        double radY = height / 2d;
        storage.append(this, radY + " " + trans + " " + (x + radX) + " " + (y + radY) + " " + " fo");
    }

    /**
     * Draws the outline of a circular or elliptical arc
     * covering the specified rectangle.
     * <p>
     * The resulting arc begins at <code>startAngle</code> and extends
     * for <code>arcAngle</code> degrees, using the current color.
     * Angles are interpreted such that 0&nbsp;degrees
     * is at the 3&nbsp;o'clock position.
     * A positive value indicates a counter-clockwise rotation
     * while a negative value indicates a clockwise rotation.
     * <p>
     * The center of the arc is the center of the rectangle whose origin
     * is (<i>x</i>,&nbsp;<i>y</i>) and whose size is specified by the
     * <code>width</code> and <code>height</code> arguments.
     * <p>
     * The resulting arc covers an area
     * <code>width&nbsp;+&nbsp;1</code> pixels wide
     * by <code>height&nbsp;+&nbsp;1</code> pixels tall.
     * <p>
     * The angles are specified relative to the non-square extents of
     * the bounding rectangle such that 45 degrees always falls on the
     * line from the center of the ellipse to the upper right corner of
     * the bounding rectangle. As a result, if the bounding rectangle is
     * noticeably longer in one axis than the other, the angles to the
     * start and end of the arc segment will be skewed farther along the
     * longer axis of the bounds.
     * @param        x the <i>x</i> coordinate of the
     *                    upper-left corner of the arc to be drawn.
     * @param        y the <i>y</i>  coordinate of the
     *                    upper-left corner of the arc to be drawn.
     * @param        width the width of the arc to be drawn.
     * @param        height the height of the arc to be drawn.
     * @param        startAngle the beginning angle.
     * @param        arcAngle the angular extent of the arc,
     *                    relative to the start angle.
     * @see         java.awt.Graphics#fillArc
     */
    @Override
    public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        storage.debug(this.getNum() + " Draw drawArc");
        StringBuffer buf = new StringBuffer(100);
        //Calculate the transformation of circle
        double trans = 1;
        trans = width / (double)height;
        double radX = width / 2d;
        double radY = height / 2d;
        buf.append(radY + " " + (-startAngle) + " " + (-startAngle - arcAngle) + " " + trans + " " + (x + radX) + " " +
                   (y + radY));
        if (arcAngle < 0)
            buf.append(" da");
        else
            buf.append(" dan");
        storage.append(this, buf.toString());
    }

    /**
     * Fills a circular or elliptical arc covering the specified rectangle.
     * <p>
     * The resulting arc begins at <code>startAngle</code> and extends
     * for <code>arcAngle</code> degrees.
     * Angles are interpreted such that 0&nbsp;degrees
     * is at the 3&nbsp;o'clock position.
     * A positive value indicates a counter-clockwise rotation
     * while a negative value indicates a clockwise rotation.
     * <p>
     * The center of the arc is the center of the rectangle whose origin
     * is (<i>x</i>,&nbsp;<i>y</i>) and whose size is specified by the
     * <code>width</code> and <code>height</code> arguments.
     * <p>
     * The resulting arc covers an area
     * <code>width&nbsp;+&nbsp;1</code> pixels wide
     * by <code>height&nbsp;+&nbsp;1</code> pixels tall.
     * <p>
     * The angles are specified relative to the non-square extents of
     * the bounding rectangle such that 45 degrees always falls on the
     * line from the center of the ellipse to the upper right corner of
     * the bounding rectangle. As a result, if the bounding rectangle is
     * noticeably longer in one axis than the other, the angles to the
     * start and end of the arc segment will be skewed farther along the
     * longer axis of the bounds.
     * @param        x the <i>x</i> coordinate of the
     *                    upper-left corner of the arc to be filled.
     * @param        y the <i>y</i>  coordinate of the
     *                    upper-left corner of the arc to be filled.
     * @param        width the width of the arc to be filled.
     * @param        height the height of the arc to be filled.
     * @param        startAngle the beginning angle.
     * @param        arcAngle the angular extent of the arc,
     *                    relative to the start angle.
     * @see         java.awt.Graphics#drawArc
     */
    @Override
    public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle) {
        storage.debug(this.getNum() + " Draw fillArc");
        StringBuffer buf = new StringBuffer(100);
        //Calculate the transformation of circle
        double trans = 1;
        trans = width / (double)height;
        double radX = width / 2d;
        double radY = height / 2d;
        buf.append(radY + " " + (-startAngle) + " " + (-startAngle - arcAngle) + " " + trans + " " + (x + radX) + " " +
                   (y + radY));
        if (arcAngle < 0)
            buf.append(" fa");
        else
            buf.append(" fan");
        storage.append(this, buf.toString());
    }

    /**
     * Draws a sequence of connected lines defined by
     * arrays of <i>x</i> and <i>y</i> coordinates.
     * Each pair of (<i>x</i>,&nbsp;<i>y</i>) coordinates defines a point.
     * The figure is not closed if the first point
     * differs from the last point.
     * @param       xPoints an array of <i>x</i> points
     * @param       yPoints an array of <i>y</i> points
     * @param       nPoints the total number of points
     * @see         java.awt.Graphics#drawPolygon(int[], int[], int)
     * @since       JDK1.1
     */
    @Override
    public void drawPolyline(int[] xPoints, int[] yPoints, int nPoints) {
        storage.debug(this.getNum() + " Draw drawPolyline");
        if (nPoints > 0) {
            storage.append(this, "np " + xPoints[0] + " " + yPoints[0] + " m");
            for (int i = 1; i < nPoints; i++) {
                storage.append(this, xPoints[i] + " " + yPoints[i] + " l");
            }
            storage.append(this, "st");
            storage.setCommand("np");
        }
    }

    /**
     * Draws a closed polygon defined by
     * arrays of <i>x</i> and <i>y</i> coordinates.
     * Each pair of (<i>x</i>,&nbsp;<i>y</i>) coordinates defines a point.
     * <p>
     * This method draws the polygon defined by <code>nPoint</code> line
     * segments, where the first <code>nPoint&nbsp;-&nbsp;1</code>
     * line segments are line segments from
     * <code>(xPoints[i&nbsp;-&nbsp;1],&nbsp;yPoints[i&nbsp;-&nbsp;1])</code>
     * to <code>(xPoints[i],&nbsp;yPoints[i])</code>, for
     * 1&nbsp;&le;&nbsp;<i>i</i>&nbsp;&le;&nbsp;<code>nPoints</code>.
     * The figure is automatically closed by drawing a line connecting
     * the final point to the first point, if those points are different.
     * @param        xPoints   a an array of <code>x</code> coordinates.
     * @param        yPoints   a an array of <code>y</code> coordinates.
     * @param        nPoints   a the total number of points.
     * @see          java.awt.Graphics#fillPolygon
     * @see          java.awt.Graphics#drawPolyline
     */
    @Override
    public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints) {
        storage.debug(this.getNum() + " Draw drawPolygon");
        if (nPoints > 0) {
            storage.append(this, "np " + xPoints[0] + " " + yPoints[0] + " m");
            for (int i = 1; i < nPoints; i++) {
                storage.append(this, xPoints[i] + " " + yPoints[i] + " l");
            }
            storage.append(this, "cp st");
            storage.setCommand("np");
        }
    }

    /** 
     * Fills a closed polygon defined by 
     * arrays of <i>x</i> and <i>y</i> coordinates. 
     * <p>
     * This method draws the polygon defined by <code>nPoint</code> line 
     * segments, where the first <code>nPoint&nbsp;-&nbsp;1</code> 
     * line segments are line segments from 
     * <code>(xPoints[i&nbsp;-&nbsp;1],&nbsp;yPoints[i&nbsp;-&nbsp;1])</code> 
     * to <code>(xPoints[i],&nbsp;yPoints[i])</code>, for 
     * 1&nbsp;&le;&nbsp;<i>i</i>&nbsp;&le;&nbsp;<code>nPoints</code>.  
     * The figure is automatically closed by drawing a line connecting
     * the final point to the first point, if those points are different.
     * <p>
     * The area inside the polygon is defined using an 
     * even-odd fill rule, also known as the alternating rule.
     * @param        xPoints   a an array of <code>x</code> coordinates.
     * @param        yPoints   a an array of <code>y</code> coordinates.
     * @param        nPoints   a the total number of points.
     * @see          java.awt.Graphics#drawPolygon(int[], int[], int)
     */
    @Override
    public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints) {
        storage.debug(this.getNum() + " Draw fillPolygon");
        if (nPoints > 0) {
            storage.append(this, "np " + xPoints[0] + " " + yPoints[0] + " m");
            for (int i = 1; i < nPoints; i++) {
                storage.append(this, xPoints[i] + " " + yPoints[i] + " l");
            }
            storage.append(this, "cp fl");
            storage.setCommand("np");
        }
    }


    @Override
    public void dispose() {
        storage.debug(this.getNum() + " Dispose ");
        storage = null;
        col = null;
        bgCol = null;
        paint = null;
        stroke = null;
        font = null;
        clip = null;
        transform = null;
    }
}
