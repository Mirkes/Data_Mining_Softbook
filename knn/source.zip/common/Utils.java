package common;

/**
 * Service class.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class Utils {

    /**
     * Perform the deep copy of arbitrary dimensional arrays of double and int.
     * @param array to copy
     * @return copy of array
     */
    public static final Object[] deepCopy(Object[] array) {
        Object[] newArray = array.clone();

        for (int i = 0, e = newArray.length; i < e; i++) {
            Object element = newArray[i];

            if (element instanceof Object[])
                newArray[i] = deepCopy((Object[])element);
            else if (element instanceof double[])
                newArray[i] = ((double[])element).clone();
            else if (element instanceof int[])
                newArray[i] = ((int[])element).clone();
        }
        return newArray;
    }
}
