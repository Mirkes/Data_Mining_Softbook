package common;

/**
 * Interface to color chooser {@link ColorChooser}.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public interface ColorChooserListener {
    /**
     * @param col - number of color in palett
     */
    public void colorChanged(int col);
}
