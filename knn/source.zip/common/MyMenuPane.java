package common;


import java.awt.Color;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;

import java.util.Random;

import javax.swing.JPanel;

/**
 * It is prototype for all classes which can be used as tabs in @link common.MainFrame.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class MyMenuPane extends JPanel implements ComponentListener, AppListener, ColorChooserListener {
    @SuppressWarnings("compatibility:-1613088563240461208")
    private static final long serialVersionUID = -635281058206525331L;

    private int cursorState = -1;
    protected JPanel drPan = null;
    protected Color col;
    protected boolean dataChanged = false;
    protected static Random rnd = new Random();


    public MyMenuPane() {
        super();
//        if (deskTop == null)
//            deskTop = DeskTop.getInstance();
        setBackground(new Color(198, 198, 198));
        setLayout(null);
        col = MainFrame.getColor(0);
        addComponentListener(this);
    }

    /**
     * Set new cursore state.
     * @param newState is new state of cursore
     */
    protected void setCursorState(int newState) {
        cursorState = newState;
        CursorHandler.getInstance().setFullState(cursorState);
    }

    /**
     * Change cursore state with preserving colour.
     * @param newState is new state of cursore
     */
    protected void changeCursorState(int newState) {
        cursorState = newState + (cursorState & 0xFF);
        CursorHandler.getInstance().setFullState(cursorState);
    }

    /**
     * @return the current cursor state
     */
    protected int getCursorState() {
        return cursorState;
    }

    /**
     * @param e event to handle
     */
    public void mouseEventHandler(MouseEvent e) {
        if (e == null)
            ;
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentResized(ComponentEvent e) {
        if (e == null)
            ;
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentMoved(ComponentEvent e) {
        if (e == null)
            ;
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentShown(ComponentEvent e) {
        CursorHandler.getInstance().setFullState(cursorState);
        onShowPanel();
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentHidden(ComponentEvent e) {
        if (cursorState == -1)
            cursorState = 0;
        else
            cursorState = CursorHandler.getInstance().getFullState();
        onHidePanel();
    }

    /**
     * @param e event to handle
     */
    @Override
    public void appHappend(AppEvent e) {
        if (e == null)
            ;
    }

    public void onShowPanel() {
        //        System.out.println("Show " + getClass().getName() + "     " + cursorState);
    }

    public void onHidePanel() {
        //        System.out.println("Hide " + getClass().getName() + "     " + cursorState);
    }

    /**
     * @param col number of color in palett
     */
    @Override
    public void colorChanged(int col) {
        CursorHandler.getInstance().changeCol(col);
        cursorState = (cursorState & 0xFF00) + col;
        this.col = MainFrame.getColor(col);
    }
}
