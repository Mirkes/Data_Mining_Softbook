package common;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * Special pane to save and load data.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
*/
public class DataSaveLoad extends MyMenuPane {
    @SuppressWarnings("compatibility:4083175404309021523")
    private static final long serialVersionUID = 2571190700094479295L;

    public DataSaveLoad() {
        super();
        setLayout(new GridBagLayout());

        JButton b = new JButton("Save data");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String fName = FileMaintain.getFileName("txt", false, "Save data as");
                if (fName.isEmpty())
                    return;
                JPanel data = MainFrame.getData();
                DataDot dd;
                Point p = new Point();
                Color col;
                try {
                    BufferedWriter bw = new BufferedWriter(new FileWriter(fName));
                    for (int i = 0, n = data.getComponentCount(); i < n; i++) {
                        dd = (DataDot)data.getComponent(i);
                        p = dd.getPos(p);
                        col = dd.getColor();
                        bw.write("" + p.x + "\t" + p.y + "\t" + MainFrame.getColorNumber(col));
                        bw.newLine();
                    }
                    bw.close();
                } catch (IOException f) {
                    f.printStackTrace();
                }
            }
        });
        AddGBL.addGBLExp(this, b, 0, 0, GridBagConstraints.BOTH);

        b = new JButton("Load data");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String fName = FileMaintain.getFileName("txt", true, "Load data from");
                if (fName.isEmpty())
                    return;
                //Try to read data
                int n;
                int[] cols;
                Point p[];
                String line;
                BufferedReader br = null;
                try {
                    //The first loop to calculate number of points
                    br = new BufferedReader(new FileReader(fName));
                    n = 0;
                    for (line = br.readLine(); line != null; line = br.readLine())
                        n++;
                    //Allocate arrays
                    p = new Point[n];
                    cols = new int[n];
                    String[] s;
                    n = 0;
                    //The second loop to read data
                    br = new BufferedReader(new FileReader(fName));
                    for (line = br.readLine(); line != null; line = br.readLine()) {
                        s = line.split("\t");
                        if (s.length < 3)
                            throw new IOException("Incorrect file format");
                        try {
                            p[n] = new Point((int)Math.round(Double.parseDouble(s[0])), //
                                        (int)Math.round(Double.parseDouble(s[1])));
                            cols[n++] = Integer.parseInt(s[2]);
                        } catch (NumberFormatException nf) {
                            throw new IOException("Incorrect file format");
                        }
                    }
                    br.close();
                } catch (IOException f) {
                    try {
                        if (br != null)
                            br.close();
                    } catch (IOException g) {
                        g.printStackTrace();
                    }
                    return;
                }
                //Add new points
                JPanel data = MainFrame.getData();
                for (int i = 0; i < n; i++) {
                    data.add(new DataDot(p[i], MainFrame.getColor(cols[i])));
                }
                //Repaint panel.
                data.repaint();
                //Send message
                MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
            }
        });
        AddGBL.addGBLExp(this, b, 1, 0, GridBagConstraints.BOTH);

        b = new JButton("Clear all");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainFrame.getInstance().fireAppHappend(AppEvent.CLEAR_ALL);
            }
        });
        AddGBL.addGBLExp(this, b, 2, 0, GridBagConstraints.BOTH);

    }
}
