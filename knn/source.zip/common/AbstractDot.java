package common;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

/**
 * This class is the prototype for all dots (points) which are used to draw data, nodes, centroids and so on.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public abstract class AbstractDot extends JPanel {
    @SuppressWarnings("compatibility:-4079318769993540046")
    private static final long serialVersionUID = 7812082121439835646L;

    protected Color col, colInside; //Color to draw (child specific)
    protected int kind;  //Kind of objet(child specific)
    protected int shift =0;
    private final float alpha = 0.75f;


    /**
     * Constructor of the dot with specified arguments.
     * @param kind is the kind on new dot.
     * @param pos is the position of the centre of dot
     * @param col is the colour of new dot
     * @param radius is radius of dot or vertical and horizontal shifts of left top corner with respect to specified 
     *          centre.
     */
    public AbstractDot(int kind, Point2D.Double pos, Color col, int radius) {
        this(kind,toPoint(pos),col,radius);
    }

    /**
     * Constructor of the dot with specified arguments.
     * @param kind is the kind on new dot.
     * @param pos is the position of the centre of dot
     * @param col is the colour of new dot
     * @param radius is radius of dot or vertical and horizontal shifts of left top corner with respect to specified 
     *          centre.
     */
    public AbstractDot(int kind, Point pos, Color col, int radius) {
        super();
        setOpaque(false);
        this.kind = kind;
        setColor(col);
        shift=radius;
        Point p=pos.getLocation();
        p.translate(-shift, -shift);
        setLocation(p);
        Dimension d = new Dimension(2*radius+1, 2*radius+1);
        setSize(d);
        setMinimumSize(d);
        setMaximumSize(d);
        setPreferredSize(d);
    }
    
    /**
     * Convert Point2D.Double into Point.
     * @param pos is Point2D.Double to convert
     * @return result of conversion
     */
    private static Point toPoint(Point2D.Double pos){
        return new Point((int)Math.round(pos.x), (int)Math.round(pos.y));
    }

    /**
     * Return the position of dot center in Point p.
     * @param p is Point to use
     * @return the position of dot center in Point p
     */
    public Point getPos(Point p){
        p=getLocation(p);
        p.translate(shift, shift);
        return p;
    }

    /**
     * Return the position of dot center.
     * @return the position of dot center.
     */
    public Point getPos() {
        Point p = new Point();
        return getPos(p);
    }

    /**
     * Set new position of dot. Centre of dot is placed to point p
     * @param p is point to place the center of point
     */
    public void setPos(Point p){
        Point pp = (Point)p.clone();
        pp.translate(-shift, -shift);
        setLocation(pp);
    }
    
    /**
     * Set new position of dot. Centre of dot is placed to point p
     * @param p is point to place the center of point
     */
    public void setPos(Point2D.Double p){
        setPos(toPoint(p));
    }

    /**
     * Set new colour for dot.
     * @param col is new colour
     */
    public void setColor(Color col){
        this.col = col;
        float[] rgb = new float[3];
        rgb = col.getRGBColorComponents(rgb);
            for (int j=0;j<3;j++)
                rgb[j]=rgb[j]*alpha+1-alpha;
        colInside = new Color(rgb[0],rgb[1],rgb[2]);
    }

    /**
     * Return the colour of dot.
     * @return the colour of dot
     */
    public Color getColor(){
        return col;
    }

    /**
     * Set new kind for dot.
     * @param kind is new kind (shape)
     */
    public void setKind(int kind){
        this.kind=kind;
    }

    /**
     * @return kind for dot.
     */
    public int getKind(){
        return kind;
    }

    /**
     * Set new shift for dot centre.
     * @param shift is new shift for dot centre.
     */
    public void setShift(int shift){
        Point p = getPos();
        this.shift = shift;
        setPos(p);
        Dimension d = new Dimension(2*shift+1, 2*shift+1);
        setSize(d);
        setMinimumSize(d);
        setMaximumSize(d);
        setPreferredSize(d);
    }

    /**
     * Create copy of current object.
     * @return copy of object
     */
    public AbstractDot copy(){
        return null;
    }
        
    /**
     * @param p first point
     * @param pp second point
     * @return square of Euclidian distance
     */
    public static int calcDist(Point p, Point pp) {
        int x, y;
        x = p.x - pp.x;
        y = p.y - pp.y;
        return x * x + y * y;
    }
    
}
