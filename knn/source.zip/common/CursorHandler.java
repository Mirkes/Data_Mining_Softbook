package common;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.MemoryImageSource;

/**
 * Class to handle the shape and color of cursor. It is mostly requared for data panel.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class CursorHandler {
    private static CursorHandler ch = null;
//    private static DeskTop deskTop = DeskTop.getInstance();
    
    private int state = 0, col = 0;
    private int eraseCursorRadius;
    private Cursor[][] curs = new Cursor[4][];

    /**
     * @return the singleton instance of CursorHandler.
     */
    public static CursorHandler getInstance(){
        if (ch==null)
            ch = new CursorHandler();
        return ch;
    }

    private CursorHandler() {
        super();
        // Prepare cursors
        // common calculations
        Toolkit tk = Toolkit.getDefaultToolkit();
        Dimension dd = tk.getBestCursorSize(50, 50);
        int w = dd.width, h = dd.height;
        int xc = w / 2, yc = h / 2, pix[];
        int n = MainFrame.getColorCount(), g;
        Point p = new Point(xc, yc); // The center of cursor must be there
        pix = new int[w * h];

        // 0 - default cursor
        curs[0] = new Cursor[1];
        curs[0][0] = new Cursor(Cursor.DEFAULT_CURSOR);
        // 1 - one dot cursor
        // prepare array
        pix = fillArray(xc, yc, w, h, 9, false, pix);
        curs[1] = new Cursor[n];
        for (int i = 0; i < n; i++) {
            g = MainFrame.getColor(i).getRGB() | 0xFF000000;
            for (int j = 0; j < w * h; j++)
                if (pix[j] != 0)
                    pix[j] = g;
            curs[1][i] = tk.createCustomCursor(tk.createImage(new MemoryImageSource(w, h, pix, 0, w)), p, null);
        }
        // 2 - Explosion
        pix = fillArray(xc, yc, w, h, 50, false, pix);
        curs[2] = new Cursor[n];
        for (int i = 0; i < n; i++) {
            g = MainFrame.getColor(i).getRGB() | 0xFF000000;
            for (int j = 0; j < w * h; j++)
                if (pix[j] != 0)
                    pix[j] = g;
            curs[2][i] = tk.createCustomCursor(tk.createImage(new MemoryImageSource(w, h, pix, 0, w)), p, null);
        }
        // 3 - Erase
        pix = fillArray(xc, yc, w, h, 50, true, pix);
        curs[3] = new Cursor[1];
        curs[3][0] = tk.createCustomCursor(tk.createImage(new MemoryImageSource(w, h, pix, 0, w)), p, null);
    }

    private int[] fillArray(int xc, int yc, int w, int h, int d, boolean kind, int[] pix) {
        int k = 0, r = (d + 1) / 2;
        // calculate radius
        if (r > xc)
            r = xc;
        if (r > w - xc - 1)
            r = w - xc - 1;
        if (r > yc)
            r = yc;
        if (r > h - yc - 1)
            r = h - yc - 1;
        int rr = r * r;
        // Prepare colors
        int bdCol = 0x0FFF0000;
        int inCol;
        if (kind) {
            inCol = 0xFFFFFFFF;
            eraseCursorRadius = r;
        } else
            inCol = 0;
        // primary fill array
        for (int i = 0; i < w; i++)
            for (int j = 0; j < h; j++)
                if ((i - xc) * (i - xc) + (j - yc) * (j - yc) < rr)
                    pix[k++] = inCol;
                else
                    pix[k++] = 0;
        // Draw circle
        for (int i = 0; i <= r; i++) {
            // calculate y
            k = (int)Math.round(Math.sqrt(rr - i * i));
            pix[(yc + k) * w + xc + i] = bdCol;
            pix[(yc + k) * w + xc - i] = bdCol;
            pix[(yc - k) * w + xc + i] = bdCol;
            pix[(yc - k) * w + xc - i] = bdCol;

            pix[(yc + i) * w + xc + k] = bdCol;
            pix[(yc + i) * w + xc - k] = bdCol;
            pix[(yc - i) * w + xc + k] = bdCol;
            pix[(yc - i) * w + xc - k] = bdCol;

            pix[(yc + k - 1) * w + xc + i] = bdCol;
            pix[(yc + k) * w + xc + i - 1] = bdCol;
            pix[(yc + k - 1) * w + xc - i] = bdCol;
            pix[(yc + k) * w + xc - i + 1] = bdCol;
            pix[(yc - k + 1) * w + xc + i] = bdCol;
            pix[(yc - k) * w + xc + i - 1] = bdCol;
            pix[(yc - k + 1) * w + xc - i] = bdCol;
            pix[(yc - k) * w + xc - i + 1] = bdCol;

            pix[(yc + i - 1) * w + xc + k] = bdCol;
            pix[(yc + i) * w + xc + k - 1] = bdCol;
            pix[(yc + i - 1) * w + xc - k] = bdCol;
            pix[(yc + i) * w + xc - k + 1] = bdCol;
            pix[(yc - i + 1) * w + xc + k] = bdCol;
            pix[(yc - i) * w + xc + k - 1] = bdCol;
            pix[(yc - i + 1) * w + xc - k] = bdCol;
            pix[(yc - i) * w + xc - k + 1] = bdCol;
            // if not erase - prepare cross
            if (!kind) {
                pix[(yc + i) * w + xc] = bdCol;
                pix[(yc - i) * w + xc] = bdCol;
                pix[yc * w + xc + i] = bdCol;
                pix[yc * w + xc - i] = bdCol;
            }
        }
        return pix;
    }

    /**
     * changing cursor color.
     * @param i - number of color
     */
    public void changeCol(int i) { 
        col = i; // Remember color
        //        if (deskTop == null)
        //            return;
        if (curs[state].length == 1)
            return;
        MainFrame.getBody().setCursor(curs[state][col]);
    }

    /**
     * To retranslate message to DeskTop.
     * @param st - new state
     */
    public void changeState(int st) {
        state = st;
//        if (deskTop == null)
//            return;
        if (curs[state].length == 1)
            MainFrame.getBody().setCursor(curs[state][0]);
        else
            MainFrame.getBody().setCursor(curs[state][col]);
    }

    /**
     * Put full cursor state - kursor type and color number.
     * @param st
     */
    public void setFullState(int st){
        col = (st & 0xFF);
        changeState((st>>8));
    }

    /**
     * @return full cursor state - kursor type and color number.
     */
    public int getFullState() {
        return state*256+col;
    }

    /**
     * @return radius of "erase" cursor
     */
    public int getEraseRadius() {
        return eraseCursorRadius;
    }
}
