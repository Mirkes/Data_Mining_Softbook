package common;

import java.util.ArrayList;

/**
 * Special class to save history of learning. Class contains the collection of descendant of AbstractHistoryPoint.
 * To use this class it is necessary to create subclass of AbstractHistoryPoint and use it to store data.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class History {
    ArrayList<AbstractHistoryPoint> store = new ArrayList<AbstractHistoryPoint>();

    /**
     * Add new record to history.
     * @param member is descendant of AbstractHistoryPoint to add.
     */
    public final void add(AbstractHistoryPoint member) {
        store.add(member);
    }

    /**
     * Return requested history point. If index is greater than number of history points in store or is less than zero
     *      then the last history point is returned
     * @param index number of history point to return. If index is greater than number of history points in store 
     *      or is less than zero then the last history point is returned
     * @return requested history point or the last one if index exceeds number of the last history point or 
     *      is less than zero. 
     */
    public final AbstractHistoryPoint get(int index) {
        if (store.size()==0)
            return null;
        if (index<0 || index >= store.size())
            index = store.size() - 1;
        return store.get(index);
    }

    /**
     * Clear story by removing all stored history points.
     */
    public final void clear(){
        store.clear();
    }

    /**
     * @return the actual number of HistoryPoints in store
     */
    public final int getSize(){
        return store.size();
    }

    public static class AbstractHistoryPoint {
        protected String name = null;
        protected double gof = 0;

        /**
         * Construct new object and initialize standard fields.
         * @param name is name of data point
         * @param gof is goodness of fit of current point
         */
        public AbstractHistoryPoint(String name, double gof){
            this.name = name;
            this.gof = gof;
        }

        /**
         * @return name of history point
         */
        public final String getName(){
            return name;
        }

        /**
         * @return goodness of fit for history point
         */
        public final double getGOF(){
            return gof;
        }
    }
}
