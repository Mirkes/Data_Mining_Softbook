package common;

import java.util.EventObject;

/**
 * Class of application event
 * id  means
 * 0 - to enable/disable tabs. param is bit flag for 32 tabs.
 * 1 - to select tab by number. param is the number of tab
 * 2 - requesr for unerasable points
 * 3 - answer to request for unerasable points. Param does not used. Object is Point[]
 * 4 - clear all
 * 5 - data changed
 *
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class AppEvent extends EventObject {
    @SuppressWarnings("compatibility:-7444343028195770078")
    private static final long serialVersionUID = 1L;
    
    private int iD; // event identifier
    private int param; // event paramrter
    private transient Object paramO; // event paramrter
    
    public static final int ENABLE_TAB = 0;
    public static final int SELECT_TAB = 1;
    public static final int REQUEST_NONERASABLE = 2;
    public static final int ANSWER_NONARASEBLE = 3;
    public static final int CLEAR_ALL = 4;
    public static final int DATA_CHANGED = 5;

    /**
     * Constructor of new AppEvent.
     * @param source - object which create event
     * @param iD event identifier
     * @param param is additional integer paramener
     * @param oParam is additional Object type parameter
     */
    public AppEvent(Object source, int iD, int param, Object oParam) {
        super(source);
        this.iD = iD;
        this.param = param;
        paramO = oParam;
    }

    /**
     *
     * @param source - object which create event
     * @param iD event identifier
     * @param param - additional parameters
     */
    public AppEvent(Object source, int iD, int param) {
        this(source, iD, param, null);
    }

    /**
     *
     * @param source - object which create event
     * @param iD event identifier
     */
    public AppEvent(Object source, int iD) {
        this(source, iD, 0, null);
    }

    /**
     * @return identifier of event
     */
    public int getID() {
        return iD;
    }

    /**
     * @return parameter of event
     */
    public int getParam() {
        return param;
    }

    /**
     * @return object parameter of event
     */
    public Object getObjectParam() {
        return paramO;
    }
}
