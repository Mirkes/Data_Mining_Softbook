package knn;

import common.AppEvent;
import common.AppListener;
import common.DataSaveLoad;
import common.MainFrame;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Main class for kNN and potential energy.
 *
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */

public class Knn implements AppListener {
    protected static MainFrame frame;

    public Knn() {
        super();
        frame = MainFrame.getInstance(true);
    }

    /**
     * @param args is list of paremetrers which is ignored by this software
     */
    public static void main(String[] args) {
        Knn me = new Knn();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Data mining illustration: kNN and potential energy");
        frame.addTabPanel("Data reduce", new DimReduction());
        frame.addTabPanel("Tests", new Tests());
        frame.addTabPanel("Save/Load", new DataSaveLoad());
        frame.addAppListener(me);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                frame.setVisible(true);
                frame.finalResize();
                frame.fireAppHappend(AppEvent.SELECT_TAB, 15);
            }
        });
    }

    /**
     * @param e is AppEvent to handle
     */
    @Override
    public void appHappend(AppEvent e) {
        if (e.getID() == AppEvent.DATA_CHANGED) {
            //Check the number of data points
//            if (MainFrame.getData().getComponentCount() == 0) {
//                //there is no data points
//                frame.fireAppHappend(AppEvent.SELECT_TAB, 9);
//            } else {
//                frame.fireAppHappend(AppEvent.SELECT_TAB, 11);
//            }
        }
    }
}
