package knn;


import common.AbstractDot;
import common.MainFrame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

/**
 * Class to draw results of manual test and cross-validation.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class TestDot extends AbstractDot {
    @SuppressWarnings("compatibility:-5038089370834342776")
    private static final long serialVersionUID = -7072913262527775537L;

    private static final int radius = 10;
    private final Color[] colors;

    /**
     * It is class constructor.
     * @param kind is a kind of creating point
     * @param klass is array of classes creating point
     * @param p is the location of the centre of creating point
     */
    public TestDot(int kind,int[] klass, Point p) {
        super(kind, p, Color.WHITE, radius);
        int k = klass.length;
        colors = new Color[k];
        for (int i = 0; i < k; i++)
            colors[i] = MainFrame.getColor(klass[i]);
    }

    /**
     * @param g
     */
    public void paint(Graphics g) {
        int siz = 2 * radius;
        g.setColor(Color.black);
        g.fillOval(0, 0, siz, siz);
        siz -= 4;
        int angl = 0;
        int part = (360 + colors.length - 1) / colors.length;
        for (int i = 0; i < colors.length; i++) {
            g.setColor(colors[i]);
            g.fillArc(2, 2, siz, siz, angl, part);
            angl += part;
        }
    }

}
