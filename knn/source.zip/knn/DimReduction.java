package knn;

import common.AbstractDot;
import common.AddGBL;
import common.AppEvent;
import common.DataDot;
import common.MainFrame;
import common.MyMenuPane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Point;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Class for dimensionality reduction (CNN).
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class DimReduction extends MyMenuPane {
    @SuppressWarnings("compatibility:-576716862089610298")
    private static final long serialVersionUID = 5876949592478778703L;

    private JSpinner nCnn = new JSpinner(new SpinnerNumberModel(3, 1, 51, 1));
    //    private JButton reduction = new JButton("Implement reduction");
    private int threshold = 3;
    private JPanel info = null;
    private final JButton exec = new JButton("Implement reduction");

    public DimReduction() {
        super();
        setLayout(new GridBagLayout());
        nCnn.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                threshold = ((SpinnerNumberModel)nCnn.getModel()).getNumber().intValue();
            }
        });
        AddGBL.addGBL(this,
                      new JLabel("<html>Number of nearest neighbours of another class<br> to recognize point as outlier"),
                      0, 0);
        AddGBL.addGBL(this, nCnn, 1, 0);
        exec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (info == null) {
                    dataReduction();
                    if (info != null)
                        exec.setText("Undo reduction");
                } else {
                    exec.setText("Implement reduction");
                    DataDot[] dots = MainFrame.getDataDots(); // Array of points
                    for (DataDot d : dots)
                        d.setKind(0);
                    MainFrame.removeInfoPanel(info);
                    info = null;
                }
                MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
                MainFrame.getBody().repaint();
            }
        });
        AddGBL.addGBL(this, exec, 0, 2);

    }

    private void dataReduction() {
        DataDot[] dots = MainFrame.getDataDots(); // Array of points
        Point[] pp; // Array for dot position
        int[] klass; // Array for class numbers
        int[][] dist, distOrder;
        int maxKlass = MainFrame.getColorCount();

        //Length of dots array
        int n = dots.length;
        //Do we have points?
        if (n == 0)
            return;

        // Fill pp and klass
        pp = new Point[n];
        klass = new int[n];
        {
            for (int i = 0; i < n; i++) {
                pp[i] = dots[i].getPos(pp[i]);
                klass[i] = MainFrame.getColorNumber(dots[i].getColor());
            }
        }
        // calc all distance
        dist = new int[n][n];
        distOrder = new int[n][n];
        int[] tmp = new int[n];
        for (int i = 0; i < n; i++)
            tmp[i] = i;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                dist[i][j] = AbstractDot.calcDist(pp[i], pp[j]);
                dist[j][i] = dist[i][j];
            }
            System.arraycopy(tmp, 0, distOrder[i], 0, n);
        }
        // sort dist via distOrder
        for (int i = 0; i < n; i++) {
            qSort(dist[i], distOrder[i], 0, n - 1);
        }
        // Create set of dots
        int[] x = new int[n], u = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = i;
            u[i] = -1;
        }
        //Select outliers and mark them as -1 in x.
        for (int i = 0; i < n; i++) {
            int j = 1;
            while ((j < n) && (j <= threshold) && (klass[distOrder[i][j]] != klass[i]))
                j++;
            if (j > threshold) {
                x[i] = -1;
                dots[i].setKind(1);
            }
        }

        //Calculate boundary ratio.
        float[] bound = new float[n];
        for (int i = 0; i < n; i++)
            if (x[i] >= 0) {
                //Find nearest of other class
                int j = 1;
                while ((j < n) && ((x[distOrder[i][j]] == -1) || (klass[distOrder[i][j]] == klass[i])))
                    j++;
                if (j == n)
                    bound[i] = 1;
                else {
                    //Calculate the nearest to dot[distOrder[i][j]] point of the same class as dot[i]
                    int k = 1, jj = distOrder[i][j];
                    while ((k < n) && ((x[distOrder[jj][k]] == -1) || (klass[distOrder[jj][k]] != klass[i])))
                        k++;
                    bound[i] = ((float)(dist[jj][distOrder[jj][k]])) / dist[i][jj];
                }
            } else
                bound[i] = 0;
        // sort x index
        qSortx(bound, x, 0, n - 1);
        // Begin CNN
        int added;
        do {
            added = 0;
            for (int i = 0; i < n; i++)
                //Ignore outliers and prototypes
                if (x[i] >= 0) {
                    //Find nearest for x[i] in U
                    int j = 1;
                    while ((j < n) && (u[distOrder[x[i]][j]] < 0))
                        j++;
                    if ((j == n) || (klass[distOrder[x[i]][j]] != klass[x[i]])) {
                        u[x[i]] = x[i];
                        x[i] = -1;
                        added++;
                    }
                }
        } while (added > 0);
        //All nonnegative x are not in use
        for (int i = 0; i < n; i++)
            if (x[i] >= 0)
                dots[x[i]].setKind(2);
        //All nonnegative u are prototypes
        for (int i = 0; i < n; i++)
            if (u[i] >= 0)
                dots[i].setKind(3);
        //Calculate klass consistence
        int[] prot = new int[maxKlass], outlier = new int[maxKlass], empts = new int[maxKlass];
        for (int i = 0; i < maxKlass; i++) {
            prot[i] = 0;
            outlier[i] = 0;
            empts[i] = 0;
        }
        //Initial fill
        for (int i = 0; i < n; i++) {
            outlier[klass[i]]++;
            if (u[i] >= 0) {
                prot[klass[i]]++;
                outlier[klass[i]]--;
            }
            if (x[i] >= 0) {
                empts[klass[x[i]]]++;
                outlier[klass[x[i]]]--;
            }
        }
        //Create informative panel throw labels.
        info = new JPanel(new GridBagLayout());
        info.setBackground(Color.WHITE);
        info.setOpaque(true);
        //Create images for three labels
        int w = dots[0].getWidth();
        BufferedImage bi = new BufferedImage(w, w, BufferedImage.TYPE_INT_RGB);
        Graphics g = bi.getGraphics();
        g.setColor(Color.black);
        g.fillRect(0, 0, w, w);
        AddGBL.addGBL(info, new JLabel(new ImageIcon(bi)), 0, 0);
        bi = new BufferedImage(w, w, BufferedImage.TYPE_INT_RGB);
        g = bi.getGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, w);
        g.setColor(Color.black);
        g.drawLine(0, 0, 8, 8);
        g.drawLine(0, 1, 7, 8);
        g.drawLine(1, 0, 8, 7);
        g.drawLine(0, 8, 8, 0);
        g.drawLine(0, 7, 7, 0);
        g.drawLine(1, 8, 8, 1);
        AddGBL.addGBL(info, new JLabel(new ImageIcon(bi)), 1, 0);
        bi = new BufferedImage(w, w, BufferedImage.TYPE_INT_RGB);
        g = bi.getGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, w);
        g.setColor(Color.black);
        g.drawOval(0, 0, 8, 8);
        g.drawOval(1, 1, 6, 6);
        AddGBL.addGBL(info, new JLabel(new ImageIcon(bi)), 2, 0);
        //Transform into persent and draw
        JLabel lab;
        Color col;
        int k = 0;
        for (int i = 0; i < maxKlass; i++) {
            n = prot[i] + outlier[i] + empts[i];
            if (n > 0) {
                k++;
                col = MainFrame.getColor(i);
                lab = new JLabel("" + Math.round(((float)(prot[i] * 100)) / n) + "%");
                lab.setForeground(col);
                AddGBL.addGBL(info, lab, 0, k);
                lab = new JLabel("" + Math.round(((float)(outlier[i] * 100)) / n) + "%");
                lab.setForeground(col);
                AddGBL.addGBL(info, lab, 1, k);
                lab = new JLabel("" + Math.round(((float)(empts[i] * 100)) / n) + "%");
                lab.setForeground(col);
                AddGBL.addGBL(info, lab, 2, k);
            }
        }
        //Define size of panel
        Dimension d = info.getPreferredSize();
        AddGBL.setAllSizes(info, d);
        info = MainFrame.addInfoPanel(info, 2);
    }

    private void qSort(int[] dist, int[] distOrder, int beg, int end) {
        int d, q;
        // calc average dist
        d = 0;
        for (int i = beg; i <= end; i++)
            d = d + dist[distOrder[i]];
        d = d / (end - beg + 1);
        int i = beg, j = end;
        while (i < j) {
            while (i < j && dist[distOrder[i]] <= d)
                i++;
            while (i < j && dist[distOrder[j]] > d)
                j--;
            q = distOrder[i];
            distOrder[i] = distOrder[j];
            distOrder[j] = q;
        }
        if (i - 1 > beg)
            qSort(dist, distOrder, beg, i - 1);
        if (i < end)
            qSort(dist, distOrder, i, end);
    }

    private void qSortx(float[] dist, int[] distOrder, int beg, int end) {
        int q;
        float d;
        //Calc average dist
        d = 0;
        for (int i = beg; i <= end; i++)
            if (distOrder[i] >= 0)
                d = d + dist[distOrder[i]];
        d = d / (end - beg + 1);
        if (d == 0)
            return;
        int i = beg, j = end;
        while (i < j) {
            while (i < j && ((distOrder[i] < 0) || (dist[distOrder[i]] >= d)))
                i++;
            while ((i < j) && ((distOrder[j] < 0) || (dist[distOrder[j]] < d)))
                j--;
            q = distOrder[i];
            distOrder[i] = distOrder[j];
            distOrder[j] = q;
        }
        if (i - 1 > beg)
            qSortx(dist, distOrder, beg, i - 1);
        if (i < end)
            qSortx(dist, distOrder, i, end);
    }

}
