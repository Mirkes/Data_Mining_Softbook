package knn;

import common.AbstractDot;
import common.AddGBL;
import common.AppEvent;
import common.DataDot;
import common.MainFrame;
import common.MyMenuPane;
import common.ParamDialog;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

import methods.Classifier;
import methods.GaussPot;
import methods.KNN;
import methods.GravitationPot;
import methods.YukawaPot;

/**
 * Class for testing of classifiers.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */

public class Tests extends MyMenuPane {
    @SuppressWarnings("compatibility:-3083881057759207932")
    private static final long serialVersionUID = -5005763450447764442L;

    private final transient Classifier[] methods =
        new Classifier[] { new KNN("k nearest neghbours"), new YukawaPot("Yukawa potential"),
                           new GaussPot("Gaussian potential"), new GravitationPot("Gravitation potential") };
    private final JComboBox method = new JComboBox(methods);
    private JPanel info = null;

    public Tests() {
        super();
        setLayout(new GridBagLayout());
        Insets ins = new Insets(0, 0, 0, 0);
        AddGBL.setInsets(new Insets(0, 5, 0, 5));
        JPanel pan = new JPanel(new GridBagLayout());
        pan.setOpaque(false);
        AddGBL.addGBL(pan, new JLabel("Method to use"), 0, 0, GridBagConstraints.EAST);
        method.setSelectedIndex(0);
        AddGBL.addGBL(pan, method, 1, 0);
        JButton b = new JButton("Options");
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Check the method
                int m = method.getSelectedIndex();
                setOptions(m);
            }
        });
        AddGBL.addGBL(pan, b, 2, 0);
        AddGBL.addGBL(this, pan, 0, 0, 5, 1);

        //Manual test
        AddGBL.addGBL(this, new JLabel("Manual:"), 0, 1);
        AddGBL.addGBL(this, new JLabel("click mouse to tast poin"), 0, 2);
        b = new JButton("Remove results");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //remove results of manual test
                removeNodes(5);
                MainFrame.getBody().repaint();
            }
        });
        AddGBL.addGBLExp(this, b, 0, 3, GridBagConstraints.HORIZONTAL);
        //Add separator
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 1, 1, 1, 3, GridBagConstraints.VERTICAL);

        //Cross-validation
        AddGBL.addGBL(this, new JLabel("Cross-validation"), 2, 1);
        b = new JButton("Perform");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Add CV results
                removeNodes(0);
                if (info != null)
                    MainFrame.removeInfoPanel(info);
                crossValidation();
                MainFrame.getBody().revalidate();
            }
        });
        AddGBL.addGBLExp(this, b, 2, 2, GridBagConstraints.HORIZONTAL);
        b = new JButton("Remove");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Remove CV test
                if (info != null) {
                    removeNodes(0);
                    MainFrame.removeInfoPanel(info);
                    MainFrame.getBody().repaint();
                }
            }
        });
        AddGBL.addGBLExp(this, b, 2, 3, GridBagConstraints.HORIZONTAL);

        //Add separator
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 3, 1, 1, 3, GridBagConstraints.VERTICAL);

        //Cross-validation
        AddGBL.addGBL(this, new JLabel("Map"), 4, 1);
        b = new JButton("Create");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Create map
                formMap();
                MainFrame.getBody().repaint();
            }
        });
        AddGBL.addGBLExp(this, b, 4, 2, GridBagConstraints.HORIZONTAL);
        b = new JButton("Remove");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Remove map
                MainFrame.putMapImage(null);
            }
        });
        AddGBL.addGBLExp(this, b, 4, 3, GridBagConstraints.HORIZONTAL);

    }

    private final void setOptions(int m) {
        //Create dialog to ask
        ParamDialog pd = new ParamDialog(MainFrame.getInstance());
        Container cont = pd.getContentPane();
        AddGBL.addGBL(cont, new JLabel("Effective radius of interaction"), 0, 0);
        JSpinner tmp = new JSpinner(new SpinnerNumberModel(methods[m].getParameter(), //
                    methods[m].gerParamMin(), methods[m].gerParamMax(), methods[m].gerParamStep()));
        AddGBL.addGBL(cont, tmp, 1, 0);
        JCheckBox cb = new JCheckBox("Apply quadrupole approximation");
        if (m > 0) {
            cb.setSelected(methods[m].getUseQuadrupole());
            AddGBL.addGBL(cont, cb, 0, 1, 2, 1);
        }
        pd.finishCreation();
        //Show dialog
        pd.setVisible(true);
        //Get response if it is necessary
        if (pd.isOk()) {
            methods[m].setParameter((Integer)tmp.getModel().getValue());
            if (m > 0) {
                methods[m].setUseQuadrupole(cb.isSelected());
            }
        }
    }

    private final DataDot[] getUsedDots() {
        DataDot[] dots = MainFrame.getDataDots();
        //The first loop - calculate number of used points
        int n = 0, k;
        for (DataDot d : dots) {
            k = d.getKind();
            if (k == 0 || k == 3)
                n++;
        }
        //Create arrays for data
        DataDot[] res = new DataDot[n];
        n = 0;
        for (DataDot d : dots) {
            k = d.getKind();
            if (k == 0 || k == 3) {
                res[n++] = d;
            }
        }
        return res;
    }

    private final void removeNodes(int kind) {
        JPanel nod = MainFrame.getNodePanel();
        int n = nod.getComponentCount();
        AbstractDot d;
        for (int i = n - 1; i >= 0; i--) {
            d = (AbstractDot)nod.getComponent(i);
            if (d.getKind() == kind)
                nod.remove(i);
        }
    }

    private final void trainMethod(int m, DataDot[] dots) {
        int n = dots.length, k;
        //Create arrays for data
        int[] klass = new int[n];
        Point[] p = new Point[n];
        for (int i = 0; i < n; i++) {
            k = dots[i].getKind();
            if (k == 0 || k == 3) {
                p[i] = dots[i].getPos();
                klass[i] = MainFrame.getColorNumber(dots[i].getColor());
            }
        }
        //Train method
        methods[m].train(p, klass);
    }

    private final void crossValidation() {
        //Get maximal possible number of classes
        int maxKlass = MainFrame.getColorCount();
        //Get classifier
        int m = method.getSelectedIndex();
        //Get data points
        DataDot[] dots = MainFrame.getDataDots();
        boolean cv = true;
        {
            DataDot[] dot = getUsedDots();
            cv = dots.length == dot.length;
            if (!methods[m].isReady()) {
                //Get data and train method
                trainMethod(m, dot);
            }
        }
        //Test each points and check answers
        JPanel nod = MainFrame.getNodePanel();
        int k;
        int[] ans;
        Point p = new Point(0, 0);
        int[] errors = new int[maxKlass], count = new int[maxKlass];
        for (DataDot d : dots) {
            k = MainFrame.getColorNumber(d.getColor());
            count[k]++;
            p = d.getPos(p);
            ans = methods[m].predict(p, cv);
            if (ans.length == 0)
                continue;
            if (ans.length > 1 || ans[0] != k) {
                nod.add(new TestDot(0, new int[] { k }, p));
                errors[k]++;
            }
        }
        //calculate fraction of errors
        info = new JPanel(new GridBagLayout());
        info.setBackground(Color.WHITE);
        info.setOpaque(true);
        JLabel lab;
        int n = 0;
        for (int i = 0; i < maxKlass; i++)
            if (count[i] > 0) {
                k = (100 * errors[i]) / count[i];
                col = MainFrame.getColor(i);
                lab = new JLabel("" + k + "%");
                lab.setForeground(col);
                AddGBL.addGBL(info, lab, 0, n++);
            }
        Dimension d = info.getPreferredSize();
        AddGBL.setAllSizes(info, d);
        info = MainFrame.addInfoPanel(info, 3);
    }

    private final void formMap() {
        //Get maximal possible number of classes
        int maxKlass = MainFrame.getColorCount();
        //Get classifier
        int m = method.getSelectedIndex();
        //Get data points
        DataDot[] dots = getUsedDots();
        if (dots.length == 0)
            return;
        if (!methods[m].isReady()) {
            //Get data and train method
            long a = System.nanoTime();
            trainMethod(m, dots);
            a = System.nanoTime() - a;
            System.out.println("Time for training\t"+a);
        }
        //Get map and it size
        Dimension d = MainFrame.getMapSize();
        Point p = new Point(0, 0);
        //Create palette
        int[] pal = new int[7];
        float alpha = 0.3725f;
        float[] rgb = new float[3];
        for (int i = 0; i < maxKlass; i++) {
            rgb = MainFrame.getColor(i).getRGBColorComponents(rgb);
            for (int j = 0; j < 3; j++)
                rgb[j] = rgb[j] * alpha + 1 - alpha;
            pal[i] = new Color(rgb[0], rgb[1], rgb[2]).getRGB();
        }
        pal[maxKlass] = Color.WHITE.getRGB();
        int n = 0, k[];
        int[] pix = new int[d.width * d.height];
        
        
        long a = System.nanoTime();
        
        for (p.y = 0; p.y < d.height; p.y++)
            for (p.x = 0; p.x < d.width; p.x++) {
                k = methods[m].predict(p, false);
                if (k.length != 1)
                    pix[n++] = pal[maxKlass];
                else
                    pix[n++] = pal[k[0]];
            }
        
        a = System.nanoTime() - a;
        System.out.println("Time for test\t"+a);

        //Create image
        BufferedImage bi = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);
        //Put pixels into image
        bi.setRGB(0, 0, d.width, d.height, pix, 0, d.width);
        //Put map
        MainFrame.putMapImage(bi);
    }

    /**
     * @param e event to handle
     */
    public void mouseEventHandler(MouseEvent e) {
        //Get coordinates
        Point p = e.getPoint();
        //Get classifier
        int m = method.getSelectedIndex();
        //Get data points
        DataDot[] dots = getUsedDots();
        if (!methods[m].isReady()) {
            //Get data and train method
            trainMethod(m, dots);
        }
        int[] ans = methods[m].predict(p, false);
        if (ans.length == 0)
            return;
        //Remove results of previous test
        removeNodes(5);
        JPanel nod = MainFrame.getNodePanel();
        //Create object in space of nodes and put it
        nod.add(new TestDot(5, ans, p));
        ans = methods[m].getVoters();
        if (ans.length > 0) {
            DataDot dot;
            //Create voters to display
            for (int i = 0; i < ans.length; i++) {
                dot = (DataDot)dots[ans[i]].copy();
                dot.setKind(5);
                nod.add(dot);
            }
        }
        nod.repaint();
    }

    /**
     * @param e is AppEvent to handle
     */
    @Override
    public void appHappend(AppEvent e) {
        if (e.getID() == AppEvent.DATA_CHANGED) {
            for (Classifier cl : methods)
                cl.untrain();
        }
    }
}
