package methods;

import common.MyMath;
import common.Utils;

import java.util.Random;


/**
 * This class implements k-means and k-medoids. Implementation is universal and can be used without 
 * other classes of demonstration software.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class KMeans {
    private static final String[] metrics = new String[] { "Euclidean", "Manhattan" };
    public static final int METRICS_EUCLIDEAN = 0;
    public static final int METRICS_MANHATTAN = 1;

    private static final String[] methods = new String[] { "Partitioning Around Centroids", "Voronoi iteration" };
    public static final int METHOD_PAC = 0;
    public static final int METHOD_VORONOI = 1;

    private static final Random rnd = new Random();

    /**
     * @return the list of implemented metrics
     */
    public static final String[] getMetrics() {
        return metrics;
    }

    /**
     * @return the list of implemented methods of medoids search
     */
    public static final String[] getMethods() {
        return methods;
    }

    /**
     * perform the fitting of kMeans model.
     * @param data is array of data points. Each row corresponds to one point.
     * @param nodes is array of initial nodes. Each row corresponds to one node.
     * @param metric is number of metric in the metrics array.
     * @param listener is listener for fitting process tracking.
     * @return array of coordinates of fitted nodes.
     */
    public static double[][] kMeans(double[][] data, double[][] nodes, int metric, CallBackKMeans listener) {
        AbstractMetric dist = MetricFactory.getMetric(metric);
        if (dist == null)
            return new double[0][0];
        boolean call = listener != null;
        int k = nodes.length;
        int n = data.length;
        //Create copy of nodes to use
        double[][] node = (double[][])Utils.deepCopy(nodes);
        //Create auxiliary arrays for classes and distances
        int[] klass = new int[n];
        double[] dists = new double[n];
        //Add initial history point with zero class for all points
        if (call)
            listener.callBack(0, new int[0], node, MyMath.sum(dists), "Initiation");
        //Initiate array of clases to check the changes. Class k is impossible!
        for (int i = 0; i < n; i++)
            klass[i] = k;
        //Loop of optimization
        boolean changed;
        int iteration = 1;
        while (true) {
            //Association step
            changed = dist.associate(data, node, klass, dists);
            //If there is no changes then stop
            if (!changed)
                break;
            //Call callBack if it is necessary
            if (call)
                listener.callBack(iteration, klass, node, MyMath.sum(dists), "Association");
            iteration++;

            //Replacement of nodes
            dist.mean(data, node, klass, dists);
            //Call callBack if it is necessary
            if (call)
                listener.callBack(iteration, klass, node, MyMath.sum(dists), "Minimization");
            iteration++;
        }
        return node;
    }

    /**
     * perform the fitting of kMedoids model.
     * @param data is array of data points. Each row corresponds to one point.
     * @param nodes is array of initial medoids. Each row corresponds to one medoid.
     * @param metric is number of metric in the metrics array.
     * @param method is number of method of medoids fitting.
     * @param attempts is number of attempts for Partitioning Around Centroids.
     * @param listener is listener for fitting process tracking.
     * @return array of coordinates of fitted medoids.
     */
    public static double[][] kMedoids(double[][] data, double[][] nodes, int metric, int method, int attempts,
                                      CallBackKMeans listener) {
        AbstractMetric dist = MetricFactory.getMetric(metric);
        if (dist == null)
            return new double[0][0];
        switch (method) {
        case METHOD_PAC:
            return kMedoidsPAC(data, nodes, dist, listener, attempts);
        case METHOD_VORONOI:
            return kMedoidsVI(data, nodes, dist, listener);
        }
        return new double[0][0];
    }

    /**
     * Perform Partitioning Around Centroids method of medoids fitting.
     * @param data is array of data points. Each row corresponds to one point.
     * @param nodes is array of initial medoids. Each row corresponds to one medoid.
     * @param dist is metrics to use.
     * @param listener is listener for fitting process tracking.
     * @param attempts is number of attempts for Partitioning Around Centroids.
     * @return array of coordinates of fitted medoids.
     */
    public static double[][] kMedoidsPAC(double[][] data, double[][] nodes, AbstractMetric dist,
                                         CallBackKMeans listener, int attempts) {
        boolean call = listener != null;
        int k = nodes.length;
        int n = data.length;
        //Create copy of nodes to use
        //Create copy of nodes to use
        double[][] node = (double[][])Utils.deepCopy(nodes);
        //Create auxiliary arrays for classes and distances
        int[] klass = new int[n];
        double[] dists = new double[n];
        //Add initial history point with zero class for all points
        if (call)
            listener.callBack(0, new int[0], node, MyMath.sum(dists), "Initiation");
        dist.associate(data, node, klass, dists);
        double best = MyMath.sum(dists);
        double tmp[], w;
        int atts = attempts, med, dat, iteration = 0;
        //Loop of attempts
        while (atts > 0) {
            //Select the medoid to change
            med = rnd.nextInt(k);
            //Select data point to use as new mwdoid
            dat = rnd.nextInt(n);
            //Copy current medoid
            tmp = node[med];
            //Put new medoid
            node[med] = data[dat];
            //Calculate goodness of fit
            dist.associate(data, node, klass, dists);
            w = MyMath.sum(dists);
            //Check the quality of new medoid
            if (best > w) {
                best = w;
                if (call)
                    listener.callBack(iteration, klass, node, best, "Success at try " + (attempts - atts + 1));
                atts = attempts;
            } else {
                //Restore old medoid
                node[med] = tmp;
                atts--;
            }
        }
        return node;
    }

    /**
     * Perform Voronoi iteration method of medoids fitting.
     * @param data is array of data points. Each row corresponds to one point.
     * @param nodes is array of initial medoids. Each row corresponds to one medoid.
     * @param dist is metrics to use.
     * @param listener is listener for fitting process tracking.
     * @return array of coordinates of fitted medoids.
     */
    public static double[][] kMedoidsVI(double[][] data, double[][] nodes, AbstractMetric dist,
                                        CallBackKMeans listener) {
        boolean call = listener != null;
        int k = nodes.length;
        int n = data.length;
        //Create copy of nodes to use
        double[][] node = (double[][])Utils.deepCopy(nodes);
        //Create auxiliary arrays for classes and distances
        int[] klass = new int[n];
        double[] dists = new double[n];
        //Add initial history point with zero class for all points
        if (call)
            listener.callBack(0, new int[0], node, MyMath.sum(dists), "Initiation");
        //Initiate array of clases to check the changes. Class k is impossible!
        for (int i = 0; i < n; i++)
            klass[i] = k;
        //Loop of optimization
        boolean changed;
        int iteration = 0;
        while (true) {
            //Association step
            changed = dist.associate(data, node, klass, dists);
            //If there is no changes then stop
            if (!changed)
                break;
            //Call callBack if it is necessary
            if (call)
                listener.callBack(iteration, klass, node, MyMath.sum(dists), "Association");
            iteration++;

            //Replacement of nodes
            dist.medoid(data, node, klass, dists);
            //Call callBack if it is necessary
            if (call)
                listener.callBack(iteration, klass, node, MyMath.sum(dists), "Minimization");
            iteration++;
        }
        return node;
    }

    public interface CallBackKMeans {
        /**
         * This interface provide the possibility to track the process of model fiting.
         * @param iteration is number of iteration.
         * @param klass is array of classes for each data point.
         * @param nodes is array with coordinates of nodes.
         * @param gof is sum of distances (goodness of fit).
         * @param stepName is name of step
         */
        public void callBack(int iteration, int[] klass, double[][] nodes, double gof, String stepName);
    }

    public abstract static class AbstractMetric {
        /**
         * Calculate distance from point data to node node.
         * @param data is data point.
         * @param node is node
         * @return distance from point data to node node.
         */
        public abstract double dist(double[] data, double[] node);

        /**
         * For each data point (data[i]) identify the nearest node (node[j]) and
         * return number of nearest node (klass[i]) and distance to nearest node (dists[i]).
         * @param data is array of data points (data[i]).
         * @param node is array of nodes (node[j]).
         * @param klass is number of previously defined klasses before calculation and number of nearest
         *          node after calculation. Must have number of elements which is equal to number of data points.
         * @param dists has no meaning before calculation and is distance to nearest node after calculation.
         *          Must have number of elements which is equal to number of data points.
         * @return true if new class is not the same as old class for at least one data point.
         */
        public boolean associate(double[][] data, double[][] node, int[] klass, double[] dists) {
            //Number of classes
            int k = node.length;
            //Number of points
            int n = data.length;
            boolean changed = false;
            //Auxiliary variables
            int klas;
            double d;
            //For each point
            for (int i = 0; i < n; i++) {
                //Initialize variables to search node with minim
                klas = 0;
                dists[i] = dist(data[i], node[0]);
                //Calculate distance for each node
                for (int j = 1; j < k; j++) {
                    d = dist(data[i], node[j]);
                    //Search the nearest node
                    if (dists[i] > d) {
                        dists[i] = d;
                        klas = j;
                    }
                }
                //Check for changes
                changed |= klass[i] != klas;
                //Remember number of nearest node
                klass[i] = klas;
            }
            return changed;
        }

        /**
         * For each node calculate the optimal position of node.
         * @param data is array of data points (data[i]).
         * @param node is array of old nodes before calculation and array of new nodes after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points.
         * @param dists has no meaning before canculation and is array with distances from corresponding data points to
         *          the associated mean. Must have number of elements which is equal to numbed of data points.
         */
        public abstract void mean(double[][] data, double[][] node, int[] klass, double[] dists);

        /**
         * For each medoid calculate the optimal position of medoids.
         * @param data is array of data points (data[i]).
         * @param node is array of old medoids before calculation and array of new medoids after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points.
         * @param dists has no meaning before canculation and is array with sum of distances from node to all
         *          datapoints which are associated with this node. Must have number of elements which is not less
         *          then number of nodes
         */
        public abstract void medoid(double[][] data, double[][] node, int[] klass, double[] dists);
    }

    public static class Euclidean extends AbstractMetric {
        /**
         * Calculate distance from point data to node node.
         * @param data is data point.
         * @param node is node
         * @return distance from point data to node node.
         */
        @Override
        public double dist(double[] data, double[] node) {
            double d = 0, dd;
            for (int i = 0, n = node.length; i < n; i++) {
                dd = (data[i] - node[i]);
                d += dd * dd;
            }
            return d;
        }

        /**
         * For each node calculate the optimal position of node which is the average point.
         * @param data is array of data points (data[i]).
         * @param node is array of old nodes before calculation and array of new nodes after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points
         * @param dists has no meaning before canculation and is array with distances from corresponding data points to
         *          the associated mean. Must have number of elements which is equal to numbed of data points.
         */
        @Override
        public void mean(double[][] data, double[][] node, int[] klass, double[] dists) {
            int k = node.length, kk;
            int dim = node[0].length;
            int n = data.length;
            //Create arrays for calculation
            double work[][] = new double[k][dim];
            int count[] = new int[k];
            //Clear dists
            for (int i = 0; i < n; i++)
                dists[i] = 0;
            //For each data point add it to associated node
            for (int i = 0; i < n; i++) {
                //Get class of this point
                kk = klass[i];
                //Increase counter of points which are associated with this node
                count[kk]++;
                //Add this point to corresponding arrays
                for (int d = 0; d < dim; d++) {
                    work[kk][d] += data[i][d];
                }
            }
            //For each node calculate mean and sum of distances
            for (int j = 0; j < k; j++) {
                if (count[j] == 0) {
                    //There is no data points which are associated with this node.
                    //Node hold the same coordinates. SUm of distances is zero.
                    continue;
                }
                //Calculate mean of coordinates and sum of distances
                for (int d = 0; d < dim; d++) {
                    node[j][d] = work[j][d] / count[j];
                }
            }
            //Calculate distances from each data point to associated node
            for (int i = 0; i < n; i++) {
                dists[i] = dist(data[i], node[klass[i]]);
            }
        }

        /**
         * For each medoid calculate the optimal position of medoids.
         * @param data is array of data points (data[i]).
         * @param node is array of old medoids before calculation and array of new medoids after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points.
         * @param dists has no meaning before canculation and is array with sum of distances from node to all
         *          datapoints which are associated with this node. Must have number of elements which is not less
         *          then number of nodes
         */
        @Override
        public void medoid(double[][] data, double[][] node, int[] klass, double[] dists) {
            //Search means
            mean(data, node, klass, dists);
            //Create auxiliary arrays
            int k = node.length;
            int n = data.length;
            int[] best = new int[k];
            double d = Double.POSITIVE_INFINITY, dd[] = new double[k];
            for (int i = 0; i < k; i++) {
                best[i] = -1;
                dd[i] = d;
            }
            //For each node select the nearest data point
            for (int i = 0; i < n; i++) {
                if (dists[i] < dd[klass[i]]) {
                    best[klass[i]] = i;
                    dd[klass[i]] = dists[i];
                }
            }
            //Put new nodes to place
            for (int i = 0; i < k; i++)
                if (best[i] > -1)
                    node[i] = data[best[i]].clone();
            //Calculate distances from each data point to associated node
            for (int i = 0; i < n; i++) {
                dists[i] = dist(data[i], node[klass[i]]);
            }
        }
    }

    public static class Manhattan extends AbstractMetric {
        /**
         * Calculate distance from point data to node node.
         * @param data is data point.
         * @param node is node
         * @return distance from point data to node node.
         */
        @Override
        public double dist(double[] data, double[] node) {
            double d = 0;
            for (int i = 0, n = node.length; i < n; i++) {
                d += Math.abs(data[i] - node[i]);
            }
            return d;
        }

        /**
         * For each node calculate the optimal position of node which is the median for each coordinate separately.
         * @param data is array of data points (data[i]).
         * @param node is array of old nodes before calculation and array of new nodes after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points
         * @param dists has no meaning before canculation and is array with distances from corresponding data points to
         *          the associated mean. Must have number of elements which is equal to numbed of data points.
         */
        @Override
        public void mean(double[][] data, double[][] node, int[] klass, double[] dists) {
            int k = node.length, kk, best, w;
            int dim = node[0].length;
            int n = data.length;
            //Create auxiliary arrays
            int count[] = new int[k];
            int index[][] = new int[k][n];
            boolean odd;
            double dd;
            //Clear dists
            for (int i = 0, m = dists.length; i < m; i++)
                dists[i] = 0;
            //Calculate the number of points in each class
            for (int i = 0; i < n; i++) {
                //Get class number
                kk = klass[i];
                //Put this case into index and increase counter of points which are associated with this node
                index[kk][count[kk]++] = i;
            }
            //For each node calculate median for each coordinate
            for (int j = 0; j < k; j++) {
                if (count[j] == 0) {
                    //There is no data points which are associated with this node.
                    //Node hold the same coordinates. SUm of distances is zero.
                    continue;
                }
                //Calculate median of coordinates and sum of distances
                //Calculate half of size of points
                kk = count[j] / 2;
                odd = (kk + kk) == count[j];
                for (int d = 0; d < dim; d++) {
                    //Search k+1 minimal values
                    for (int m = 0; m <= kk; m++) {
                        //Search m-th minimal value
                        dd = data[index[j][m]][d];
                        best = m;
                        for (int mm = m + 1; mm < count[j]; mm++)
                            if (data[index[j][mm]][d] < dd) {
                                best = mm;
                                dd = data[index[j][mm]][d];
                            }
                        //Swap the best and m if necessary
                        if (best != m) {
                            w = index[j][m];
                            index[j][m] = index[j][best];
                            index[j][best] = w;
                        }
                    }
                    //If count[j] is odd then take average of kk and kk-1
                    if (odd)
                        node[j][d] = (data[index[j][kk]][d] + data[index[j][kk - 1]][d]) / 2;
                    else //Take the medium element
                        node[j][d] = data[index[j][kk]][d];
                }
            }
            //Calculate sum of distances from all points to new node
            for (int i = 0; i < n; i++)
                dists[i] = dist(data[i], node[klass[i]]);
        }

        /**
         * For each medoid calculate the optimal position of medoids.
         * @param data is array of data points (data[i]).
         * @param node is array of old medoids before calculation and array of new medoids after calculation.
         * @param klass is array with number of nearest node for each data point. Must have number of elements which
         *          is equal to number of data points.
         * @param dists has no meaning before canculation and is array with sum of distances from node to all
         *          datapoints which are associated with this node. Must have number of elements which is not less
         *          then number of nodes
         */
        @Override
        public void medoid(double[][] data, double[][] node, int[] klass, double[] dists) {
            //We have to calculate distances from each data point to each data point in the same class
            //and then select minimal value
            int k = node.length, kk, best;
            int n = data.length;
            //Create auxiliary arrays
            int count[] = new int[k];
            int index[][] = new int[k][n];
            double dd;
            //Calculate the number of points in each class
            for (int i = 0; i < n; i++) {
                //Get class number
                kk = klass[i];
                //Put this case into index and increase counter of points which are associated with this node
                index[kk][count[kk]++] = i;
            }
            //For each node calculate distances between all data points in this class.
            for (int j = 0; j < k; j++) {
                if (count[j] == 0) {
                    //There is no data points which are associated with this node.
                    //Node hold the same coordinates.
                    continue;
                }
                //Clear array of distances for calculations
                for (int i = 0; i < count[j]; i++)
                    dists[i] = 0;
                //Select the first data point
                for (int i = 0; i < count[j]; i++) {
                    //Select the second data point
                    for (int ii = i + 1; ii < count[j]; ii++) {
                        dd = dist(data[index[j][i]], data[index[j][ii]]);
                        dists[i] += dd;
                        dists[ii] += dd;
                    }
                }
                //Search minimal value
                dd = dists[0];
                best = 0;
                for (int i = 1; i < count[j]; i++)
                    if (dd > dists[i]) {
                        best = i;
                        dd = dists[i];
                    }
                //Put coordinates of new medoid
                node[j] = data[index[j][best]].clone();
            }
            //Calculate sum of distances from all points to new node
            for (int i = 0; i < n; i++)
                dists[i] = dist(data[i], node[klass[i]]);
        }
    }

    /**
     * Factory to create metric class by number of metric.
     */
    public static class MetricFactory {
        /**
         * Create metric class by number of metric.
         * @param metric is number of requested metric.
         * @return descendant of AbstractMetric or null if metric contains inapropriate value.
         */
        public static final AbstractMetric getMetric(int metric) {
            switch (metric) {
            case METRICS_EUCLIDEAN:
                {
                    return new Euclidean();
                }
            case METRICS_MANHATTAN:
                {
                    return new Manhattan();
                }
            }
            return null;
        }
    }
}
