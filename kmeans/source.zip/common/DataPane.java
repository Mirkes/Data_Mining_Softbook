package common;


import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.JToggleButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Special pane to work with data.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
*/
public class DataPane extends MyMenuPane implements ActionListener {
    @SuppressWarnings("compatibility:-7085071812521629203")
    private static final long serialVersionUID = -2737018312435081754L;

    private static DataPane dp = null;
    private JSlider caliber = new JSlider(10, 200, 50);
    private JSpinner dotNumbers = new JSpinner(new SpinnerNumberModel(20, 10, 5000, 10));
    private JLabel lCaliber = new JLabel("50");
    private ButtonGroup dotsBG = new ButtonGroup();
    private Point[] nonerasable = new Point[0];

    private DataPane(boolean changeColor) {
        super();
        setLayout(new GridBagLayout());
        setCursorState(512);
        ColorChooser com = ColorChooser.getInstance(changeColor);
        com.addListener(this);

        //Forrm middle part
        JPanel pan = new JPanel(new GridBagLayout());
        pan.setOpaque(false);
        AddGBL.setInsets(new Insets(0, 3, 0, 3));
        AddGBL.addGBL(pan, new JLabel("Caliber"), 0, 0);

        AddGBL.addGBL(pan, lCaliber, 1, 0, GridBagConstraints.WEST);

        AddGBL.setInsets(new Insets(0, 0, 0, 0));
        AddGBL.addGBL(pan, new JLabel("Number of points"), 0, 2, 2, 1);

        caliber.setOpaque(false);
        caliber.setMinimumSize(new Dimension(100, 16));
        caliber.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                lCaliber.setText("" + caliber.getValue());
            }
        });
        AddGBL.addGBLExp(pan, caliber, 0, 1, 2, 1, GridBagConstraints.HORIZONTAL);
        AddGBL.addGBL(pan, dotNumbers, 0, 3, 2, 1);

        AddGBL.setInsets(new Insets(0, 2, 0, 2));
        AddGBL.addGBL(this, com, 0, 0, 1, 3);

        //Add separator of the first and second parts
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 1, 0, 1, 3, GridBagConstraints.VERTICAL);

        //Add separator of the second and third parts
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 3, 0, 1, 3, GridBagConstraints.VERTICAL);

        //Add central panel
        AddGBL.addGBLExps(this, pan, 2, 0, 1, 3, 1, 0, GridBagConstraints.HORIZONTAL);

        //Right part: add buttons
        Insets butMarg = new Insets(1, 5, 1, 5);
        AddGBL.setInsets(new Insets(0, 0, 0, 3));
        JToggleButton tb = new JToggleButton("One point");
        tb.setActionCommand("one");
        tb.setMargin(butMarg);
        tb.addActionListener(this);
        dotsBG.add(tb);
        AddGBL.addGBLExp(this, tb, 4, 0, GridBagConstraints.HORIZONTAL);

        tb = new JToggleButton("Scatter", true);
        tb.setActionCommand("scatter");
        tb.setMargin(butMarg);
        tb.addActionListener(this);
        dotsBG.add(tb);
        AddGBL.addGBLExp(this, tb, 4, 1, GridBagConstraints.HORIZONTAL);

        tb = new JToggleButton("Erase");
        tb.setActionCommand("erase");
        tb.setMargin(butMarg);
        tb.addActionListener(this);
        dotsBG.add(tb);
        AddGBL.addGBLExp(this, tb, 5, 0, GridBagConstraints.HORIZONTAL);

        JButton bb = new JButton("Select");
        bb.setActionCommand("select");
        bb.setMargin(butMarg);
        bb.setEnabled(false);
        bb.addActionListener(this);
        AddGBL.addGBLExp(this, bb, 5, 1, GridBagConstraints.HORIZONTAL);

        bb = new JButton("Random");
        bb.setActionCommand("random");
        bb.setMargin(butMarg);
        bb.addActionListener(this);
        AddGBL.addGBLExp(this, bb, 4, 2, GridBagConstraints.HORIZONTAL);

        bb = new JButton("Clear all");
        bb.setActionCommand("clear");
        bb.setMargin(butMarg);
        bb.addActionListener(this);
        AddGBL.addGBLExp(this, bb, 5, 2, GridBagConstraints.HORIZONTAL);

        AddGBL.stdInsets();
        //Get pointer to drawing panel
        drPan = MainFrame.getData();
    }

    /**
     * Return the singleton instance of DataPane.
     * @param changeColor is the trigger for usage of different colour. 
     *          If changeColor is true then six colours can be used. 
     *          If changeColor is false then only one colour is accessible.
     * @return the singleton instance of DataPane
     */
    public static DataPane getInstance(boolean changeColor) {
        if (dp == null)
            dp = new DataPane(changeColor);
        return dp;
    }

    /**
     * @return the singleton instance of DataPane
     */
    public static DataPane getInstance() {
        if (dp == null)
            dp = new DataPane(false);
        return dp;
    }

    private void addDot(int x, int y) {
        DataDot dd = new DataDot(x, y, col);
        drPan.add(dd);
        dd.repaint();
        dataChanged = true;
    }

    private void randomAdd() {
        int n = ((SpinnerNumberModel)dotNumbers.getModel()).getNumber().intValue();
        int x, y, maxX = MainFrame.getSizeX(), maxY = MainFrame.getSizeY();
        for (; n > 0; n--) {
            x = rnd.nextInt(maxX);
            y = rnd.nextInt(maxY);
            addDot(x, y);
        }
    }


    /**
     * @param e event to handle
     */
    public void mouseEventHandler(MouseEvent e) {
        int kind = getCursorState() >> 8;
        switch (kind) {
        case 0:
            { // select
                break;
            }
        case 1:
            { // One dot
                addDot(e.getX(), e.getY());
                MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
                break;
            }
        case 2:
            { // Explosion
                int rad = caliber.getValue();
                int n = ((SpinnerNumberModel)dotNumbers.getModel()).getNumber().intValue();
                int xc = e.getX(), yc = e.getY();
                int x, y, rr = rad * rad, maxX = MainFrame.getSizeX(), maxY = MainFrame.getSizeY();
                if ((xc < 0) || (yc < 0) || (xc > maxX) || (yc > maxY))
                    break;
                for (; n > 0; n--) {
                    do {
                        x = rnd.nextInt(2 * rad) - rad;
                        y = rnd.nextInt(2 * rad) - rad;
                    } while ((x * x + y * y > rr) || (x + xc < 0) || (x + xc > maxX) || (y + yc < 0) ||
                             (y + yc > maxY));
                    addDot(x + xc, y + yc);
                }
                MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
                break;
            }
        case 3:
            {
                MainFrame.getInstance().fireAppHappend(AppEvent.REQUEST_NONERASABLE);
                int rr = CursorHandler.getInstance().getEraseRadius();
                Point p = new Point(), pc = e.getPoint();
                boolean b = false, bb;
                //                pc.x -= 5;
                //                pc.y -= 5;
                rr = rr * rr;
                // Go over white cursor points
                int n = drPan.getComponentCount();
                AbstractDot dot;
                for (int i = n - 1; i >= 0; i--) {
                    dot = (AbstractDot)drPan.getComponent(i);
                    p = dot.getPos(p);
                    if (AbstractDot.calcDist(p, pc) <= rr) {
                        //test for nonerasable
                        bb = false;
                        for (Point q : nonerasable) {
                            if (AbstractDot.calcDist(p, q) == 0) {
                                bb = true;
                                break;
                            }
                        }
                        if (!bb) {
                            drPan.remove(dot);
                            b = true;
                        }
                    }
                }
                if (b) {
                    dataChanged = true;
                    MainFrame.getBody().repaint();
                    MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
                }
                break;
            }
        }
    }

    /**
     * @param e is ActionEvent to handle 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        if ("one".equals(s)) {
            changeCursorState(256);
        } else if ("scatter".equals(s)) {
            changeCursorState(512);
        } else if ("erase".equals(s)) {
            changeCursorState(768);
        } else if ("select".equals(s)) {
        } else if ("random".equals(s)) {
            randomAdd();
            MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
        } else if ("clear".equals(s)) {
            MainFrame.getInstance().fireAppHappend(AppEvent.CLEAR_ALL);
        }
    }

    /**
     * @param e is AppEvent to handle
     */
    public void appHappend(AppEvent e) {
        if (e.getID() == AppEvent.ANSWER_NONARASEBLE) {
            nonerasable = (Point[])e.getObjectParam();
        } else if (e.getID() == AppEvent.CLEAR_ALL) {
            drPan.removeAll();
            drPan.repaint();
            dataChanged = true;
            MainFrame.getInstance().fireAppHappend(AppEvent.DATA_CHANGED);
        }
    }

}
