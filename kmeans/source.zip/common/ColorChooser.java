package common;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * Special pane to choose colour for classifiers and some other necessity.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class ColorChooser extends JPanel {
    @SuppressWarnings("compatibility:-1857102623270201800")
    private static final long serialVersionUID = -221019190144965284L;

    private static ColorChooser cc;
    private static JPanel currentPanel = new JPanel();
    private static boolean choose;

    private ColorChooser(boolean changeEnabled) {
        super();
        choose=changeEnabled;
        Dimension d = new Dimension(100, 72);
        setAllSizes(this, d);
        setLayout(new GridBagLayout());
        setOpaque(false);
        Color col = MainFrame.getColor(0);
        
        currentPanel.setBackground(col);
        AddGBL.setInsets(new Insets(0, 0, 0, 2));
        AddGBL.addGBLExp(this, currentPanel, 0, 2,1,2,GridBagConstraints.BOTH);
        AddGBL.addGBL(this, new JLabel("Current", JLabel.CENTER), 0, 1);
        
        AddGBL.setInsets(new Insets(0, 0, 0, 0));
        AddGBL.addGBL(this, new JLabel("Colors"), 0, 0, 3, 1);
        JPanel pan;
        d = new Dimension(19, 19);
        for (int i = 0; i < 6; i++) {
            pan = new JPanel();
            pan.setName("" + i);
            setAllSizes(pan, d);
            if (choose)
                pan.setBackground(MainFrame.getColor(i));
            else
                pan.setBackground(col);
            AddGBL.addGBL(this, pan, 1 + (i % 2), 1 + i / 2);
        }
        AddGBL.stdInsets();
        addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                mouseClickedEvent(e);
            }
        });
    }

    private void setAllSizes(JPanel pan, Dimension d) {
        pan.setSize(d);
        pan.setMinimumSize(d);
        pan.setMaximumSize(d);
        pan.setPreferredSize(d);
    }

    /**
     * @param changeEnabled is the trigger for usage of different colour. 
     *          If changeEnabled is true then six colours can be used. 
     *          If changeEnabled is false then only one colour is accessible.
     * @return the singleton instance of ColorChooser
     */
    public static ColorChooser getInstance(boolean changeEnabled) {
        if (cc == null)
            cc = new ColorChooser(changeEnabled);
        return cc;
    }

    private void mouseClickedEvent(MouseEvent e) {
        if (!choose)
            return;
        if (e.getButton() != MouseEvent.BUTTON1)
            return;
        int x=e.getX(), y=e.getY();
        Component comp = getComponentAt(x, y);
        String nam = comp.getName();
        if (nam==null)
            return;
        x=Integer.parseInt(nam);
        fireColorChanged(x);
    }


    /**
     * Realizing of color chooser interface
     */

    transient ArrayList<ColorChooserListener> listeners = new ArrayList<ColorChooserListener>();

    /**
     * @param ccl - color chooser listener to add into list
     */

    public void addListener(ColorChooserListener ccl) {
        listeners.add(ccl);
    }

    /**
     * @return return list of all listeners
     */
    public ColorChooserListener[] getColorChooserListeners() {
        return listeners.toArray(new ColorChooserListener[listeners.size()]);
    }

    /**
     * @param listener - listener
     */
    public void removeColorChooserListener(ColorChooserListener listener) {
        listeners.remove(listener);
    }

    private void fireColorChanged(int col) {
        currentPanel.setBackground(MainFrame.getColor(col));
        for (ColorChooserListener ccl : listeners)
            ccl.colorChanged(col);
    }

}
