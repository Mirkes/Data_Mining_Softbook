package common;


import common.History.AbstractHistoryPoint;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.Timer;

/**
 * Create universal panel for learning history manipulations.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
*/
public class ViewerPanel extends JPanel implements ActionListener {
    @SuppressWarnings("compatibility:4820181070002167811")
    private static final long serialVersionUID = 8726358084362113580L;

    //Source of data to draw
    private transient History history;

    //Class to draw
    transient ViewerListener listener;

    //For drawing
    protected int step = 0;
    protected int totStep = 0;
    protected int delay = 100;
    protected JLabel name = new JLabel("");
    protected JLabel lStep = new JLabel("0");
    protected JLabel tStep = new JLabel("0");
    protected JLabel gof = new JLabel("0.000");
    
    //For slide show
    private static ImageIcon iconPlay = Icons.getPlay();
    private static ImageIcon iconStop = Icons.getStop();
    private final JButton bPlay = new JButton();
    private boolean go = false;
    private Timer timer = new Timer(100, this);


    /**
     * Constructor to create panel for history viewing.
     * @param history is History object to view
     * @param fName is name of goodness of fit function.
     * @param listener is ViewerListener which draw history points
     */
    public ViewerPanel(History history, String fName, ViewerListener listener) {
        this.history = history;
        this.listener = listener;
        setLayout(new GridBagLayout());
        setBackground(MainFrame.bkGd);

        //Create insets
        Insets ins = new Insets(0, 0, 0, 0);
        AddGBL.setInsets(new Insets(0, 2, 0, 2));

        //For name
        AddGBL.addGBL(this, new JLabel("name"), 0, 0);
        name.setForeground(Color.BLUE);
        AddGBL.addGBL(this, name, 1, 0, 3, 1, GridBagConstraints.WEST);

        //For steps
        AddGBL.addGBL(this, new JLabel("step#"), 0, 1);
        lStep.setForeground(Color.BLUE);
        AddGBL.addGBL(this, lStep, 1, 1, GridBagConstraints.WEST);
        AddGBL.addGBL(this, new JLabel("from"), 2, 1);
        tStep.setForeground(Color.BLUE);
        AddGBL.addGBL(this, tStep, 3, 1, GridBagConstraints.WEST);

        //For goodness of fit
        AddGBL.addGBL(this, new JLabel(fName), 0, 2);
        gof.setForeground(Color.BLUE);
        AddGBL.addGBL(this, gof, 1, 2, 3, 1, GridBagConstraints.WEST);

        //Create button panel
        Box butt = Box.createHorizontalBox();

        //To begining
        JButton b = new JButton();
        b.setMargin(ins);
        b.setIcon(Icons.getBegin());
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (step == 0)
                    return;
                step = 0;
                drawStep();
            }
        });
        butt.add(b);

        //step back
        b = new JButton();
        b.setMargin(ins);
        b.setIcon(Icons.getBack());
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (step == 0)
                    return;
                step--;
                drawStep();
            }
        });
        butt.add(b);

        //Play/stop
        bPlay.setMargin(ins);
        bPlay.setIcon(iconPlay);
        bPlay.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (go) {
                    // to stop
                    bPlay.setIcon(iconPlay);
                    timer.stop();
                    go = false;
                } else {
                    // to start
                    bPlay.setIcon(iconStop);
                    timer.start();
                    go = true;
                    //                begin();
                }
            }
        });
        butt.add(bPlay);

        //step forward
        b = new JButton();
        b.setMargin(ins);
        b.setIcon(Icons.getForw());
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (step == totStep - 1)
                    return;
                step++;
                drawStep();
            }
        });
        butt.add(b);

        //To end
        b = new JButton();
        b.setMargin(ins);
        b.setIcon(Icons.getEnd());
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (step == totStep - 1)
                    return;
                step = totStep - 1;
                drawStep();
            }
        });
        butt.add(b);
        //To end
        b = new JButton("...");
        b.setMargin(ins);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Create dialog for delay request
                ParamDialog pd = new ParamDialog(null);
                //Creater panel for request
                Container cont = pd.getContentPane();
                AddGBL.addGBL(cont, new JLabel("Delay (ms)"), 0, 0);
                JSpinner dels = new JSpinner(new SpinnerNumberModel(delay, 10, 5000, 10));
                AddGBL.addGBL(cont, dels, 1, 0);
                pd.finishCreation();
                //Ask user
                pd.setVisible(true);
                if (pd.isOk()) {
                    delay = (Integer)dels.getModel().getValue();
                } else
                    return;
                timer.setDelay(delay);
            }
        });
        butt.add(b);
        //Add buttons panel
        AddGBL.addGBL(this, butt, 0, 3, 4, 1);

        //Restore insets
        AddGBL.stdInsets();
    }

    /**
     * @param history is new history to use.
     */
    public final void setHistory(History history) {
        this.history = history;
        renew();
    }

    public final void renew() {
        //Check all parameters rewrite all include panel
        //Get number of possible steps
        totStep = history.getSize();
        tStep.setText("" + (totStep-1));
        if (step >= totStep)
            step = totStep - 1;
        drawStep();
    }

    private final void drawStep() {
        //Write number of step
        lStep.setText("" + step);
        //Get historyPoint
        AbstractHistoryPoint hPoint = history.get(step);
        //Write name
        name.setText(hPoint.getName());
        //Write GoF
        gof.setText(String.format("%,5.3f", hPoint.getGOF()));
        //Call listener to draw current step
        listener.drawHistoryPoint(hPoint,step);
        //Final step is revalidation
        this.revalidate();
    }

    /**
     * @param e is Timer event to handle
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        //Timer
        if (step == totStep - 1){
            bPlay.setIcon(iconPlay);
            timer.stop();
            go = false;
        } else{
            step++;
            drawStep();
        }
    }

    /**
     * Interface for history viewer.
     */
    public interface ViewerListener {

        /**
         * Method to draw information from HistoryPoint. Standard fields name, gof and step are drown by ViewerPanel.
         * @param hPoint is descander of AbstractHistoryPoint.
         * @param step is the number of current history point.
         */
        public void drawHistoryPoint(AbstractHistoryPoint hPoint, int step);
    }
}
