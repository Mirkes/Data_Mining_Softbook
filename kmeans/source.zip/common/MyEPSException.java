package common;
/**
 * This class the special exception for the EPSGrapthics.
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
*/
public class MyEPSException extends RuntimeException {
    @SuppressWarnings("compatibility:8229530318704592448")
    private static final long serialVersionUID = 43284893790740006L;

    /**
     * @param string is the message for the created exception
     */
    public MyEPSException(String string) {
        super(string);
    }

}
