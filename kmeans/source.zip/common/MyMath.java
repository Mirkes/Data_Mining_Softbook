package common;

/**
 * Class for auxiliary mathematical routines.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class MyMath {

    /**
     * Calculate the sum of double array elements.
     * @param data is array to sum
     * @return the sum of double array elements
     */
    public static final double sum(double[] data){
        double d=0;
        for (double dd:data)
            d+=dd;
        return d;
    }
}
