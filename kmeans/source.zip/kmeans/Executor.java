package kmeans;


import common.AddGBL;
import common.AppEvent;
import common.DataDot;
import common.History;

import common.History.AbstractHistoryPoint;

import common.MainFrame;
import common.MyMenuPane;
import common.ParamDialog;
import common.Utils;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;

import java.util.ArrayList;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

import methods.KMeans;

import methods.KMeans.CallBackKMeans;

/**
 * Special panel to initiate and learning centroids.
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class Executor extends MyMenuPane implements CallBackKMeans {
    @SuppressWarnings("compatibility:6508380685314393938")
    private static final long serialVersionUID = -5317161012960381544L;

    private final JPanel nextColour = new JPanel();
    private final int maxCol = MainFrame.getColorCount();
    private int nCol = maxCol; //Number of centroids which can be added
    private final JLabel nCentroids = new JLabel("" + maxCol);

    //Buttons to enable/disable
    private final JButton bRand = new JButton("Random centroid");
    private final JButton bErase = new JButton("Erase cantroids");
    private final JButton bLearn = new JButton("Learn");
    private final JButton bUnlearn = new JButton("Unlearn");

    //For random selection of data points for centroids
    private final Random rnd = new Random();

    // List of selected data points (centroids)
    private final ArrayList<Point> nonerasable = new ArrayList<Point>(maxCol);

    //Initial means and medoids
    protected static final transient Centroids centr = new Centroids();

    //Method specification
    private int metric = 0; //Euclidean is 0, Manhattan is 1
    private int method = 1; //PAC is 0; Voronoi iteration is 1
    private int attempts = 100; //Number of unsuccessful attampts in row to stop PAC

    //Histories for viewer
    protected static final transient History kMeanHistory = new History();
    protected static final transient History kMedoidHistory = new History();
    private int minMed = 0; //Who is worked kMeans is 0, kMedoids is 1


    //State of panel
    private int state = 0;
    // 0 - there is no centroids
    // 1 - there is several centroids and cen be added at least one
    // 2 - all centroids added but do not learned
    // 3 - centroids have learned

    public Executor() {
        super();
        setLayout(new GridBagLayout());

        AddGBL.setInsets(new Insets(0, 3, 0, 3));

        //Next centroid colour part
        AddGBL.addGBL(this, new JLabel("Next centroid"), 0, 0);
        AddGBL.addGBL(this, new JLabel("color"), 0, 1);
        nextColour.setBackground(MainFrame.getColor(nCol - 1));
        nextColour.setMinimumSize(new Dimension(20, 20));
        AddGBL.addGBLExps(this, nextColour, 0, 2, 1, 2, 0, 0, GridBagConstraints.BOTH);

        //Add separator of the first and second parts
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 1, 0, 1, 4, GridBagConstraints.VERTICAL);

        //Number of centroid to add
        AddGBL.addGBL(this, new JLabel("You can"), 2, 0);
        AddGBL.addGBL(this, new JLabel("add"), 2, 1);
        AddGBL.addGBL(this, nCentroids, 2, 2);
        AddGBL.addGBL(this, new JLabel("centroids"), 2, 3);

        //Add separator of the second and third parts
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 3, 0, 1, 4, GridBagConstraints.VERTICAL);

        //Add buttons
        AddGBL.addGBLExp(this, bRand, 4, 0, 1, 2, GridBagConstraints.HORIZONTAL);
        AddGBL.addGBLExp(this, bErase, 4, 2, 1, 2, GridBagConstraints.HORIZONTAL);
        AddGBL.addGBLExp(this, bLearn, 5, 0, 1, 2, GridBagConstraints.HORIZONTAL);
        AddGBL.addGBLExp(this, bUnlearn, 5, 2, 1, 2, GridBagConstraints.HORIZONTAL);

        //Initialize enabling
        bErase.setEnabled(false);
        bLearn.setEnabled(false);
        bUnlearn.setEnabled(false);

        //Restore standard insets for further usage
        AddGBL.stdInsets();

        //Add listeners to buttons
        bRand.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Can we add something?
                if (nCol == 0)
                    return;
                //Get data plane
                JPanel data = MainFrame.getData();
                //Get number of data points
                int n = data.getComponentCount();
                int i;
                DataDot comp;
                //Randomly generate number of data point
                i = rnd.nextInt(n);
                //Get corresponding component
                comp = (DataDot)data.getComponent(i);
                addCentroid(comp);
            }
        });

        bErase.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eraseAllCentroids();
            }
        });

        bLearn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                learn();
            }
        });
        
        bUnlearn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                unlearn();
            }
        });

    }

    private final void addCentroid(DataDot comp) {
        //Get Node planel
        JPanel nodes = MainFrame.getNodePanel();

        //Add to list of nonerasable
        nonerasable.add(comp.getPos());

        //Get location
        Point p = comp.getPos();
        // create centroids

        centr.means[maxCol - nCol] = new DataDot(p, MainFrame.getColor(nCol - 1));
        centr.medoids[maxCol - nCol] = new DataDot(p, MainFrame.getColor(nCol - 1));
        centr.means[maxCol - nCol].setKind(4);
        centr.medoids[maxCol - nCol].setKind(5);

        // Add centroids to panel
        nodes.add(centr.means[maxCol - nCol]);
        nodes.add(centr.medoids[maxCol - nCol]);

        // Change state
        nCol--;
        changeState();
    }

    /**
     * Change state of panel
     */
    private final void changeState() {
        if (bUnlearn.isEnabled()) {
            state = 3;
            bErase.setEnabled(false);
            bLearn.setEnabled(false);
            bRand.setEnabled(false);
        } else {
            if (nCol == maxCol) {
                state = 0;
                bErase.setEnabled(false);
                bLearn.setEnabled(false);
                bRand.setEnabled(true);
            } else if (nCol > 0) {
                state = 1;
                bErase.setEnabled(true);
                bLearn.setEnabled(true);
                bRand.setEnabled(true);
            } else {
                state = 2;
                bErase.setEnabled(true);
                bLearn.setEnabled(true);
                bRand.setEnabled(false);
            }
        }

        //Change colour of next centroid
        if (state < 2)
            nextColour.setBackground(MainFrame.getColor(nCol - 1));

        //Change number of possible centroid
        nCentroids.setText("" + nCol);
        MainFrame.getNodePanel().repaint();
    }

    private final void eraseAllCentroids() {
        //Remove centroids from pane
        MainFrame.getNodePanel().removeAll();
        nCol = maxCol;
        nonerasable.clear();
        changeState();
    }

    private final void learn() {
        //Ask the option of methods
        ParamDialog pd = new ParamDialog(MainFrame.getInstance());
        Container cont = pd.getContentPane();
        ButtonGroup distBG = new ButtonGroup();
        String[] metrs = KMeans.getMetrics();
        AddGBL.addGBL(cont, AddGBL.createRadioButtonGroup("Metric", distBG, metrs), 0, 0, 2, 1);
        ButtonGroup methBG = new ButtonGroup();
        String[] meths = KMeans.getMethods();
        AddGBL.addGBL(cont, AddGBL.createRadioButtonGroup("Method for medoids", methBG, meths), 0, 1, 2, 1);
        AddGBL.addGBL(cont, new JLabel("# of attempts for PAC"), 0, 2, GridBagConstraints.WEST);
        JSpinner atts = new JSpinner(new SpinnerNumberModel(attempts, 10, 5000, 10));
        AddGBL.addGBL(cont, atts, 1, 2, GridBagConstraints.WEST);
        AddGBL.setSelected(distBG, "" + metric);
        AddGBL.setSelected(methBG, "" + method);
        pd.finishCreation();
        pd.setVisible(true);
        if (pd.isOk()) {
            metric = Integer.parseInt(distBG.getSelection().getActionCommand());
            method = Integer.parseInt(methBG.getSelection().getActionCommand());
            attempts = (Integer)atts.getModel().getValue();
        } else
            return;

        //Get data points as double array
        double[][] data = MainFrame.getDataPoints();
        //Get nodes as double array
        int k = maxCol - nCol;
        double[][] nodes = new double[k][2];
        Point p = new Point();
        for (int i = 0; i < k; i++) {
            p = centr.means[i].getPos(p);
            nodes[i][0] = p.x;
            nodes[i][1] = p.y;
        }



//        try {
//            MyBufferedWriter bw = new MyBufferedWriter(new FileWriter("C:\\LocalData\\em322\\Apps\\Leicester applets\\New Version\\debug.txt" ));
//            bw.writeString("Data");
//            for (double[] d: data)
//                bw.writeDoubleArrayLn(d);
//            bw.newLine();
//            bw.writeString("Node");
//            for (double[] d: nodes)
//                bw.writeDoubleArrayLn(d);
//            bw.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        
        
        //Perform kMeans and save history
        minMed = 0;
        KMeans.kMeans(data, nodes, metric, this);

        //Perform kMedoids and save history
        minMed = 1;
        KMeans.kMedoids(data, nodes, metric, method, attempts, this);

        //Set unlearn enabled and reset state
        bUnlearn.setEnabled(true);
        changeState();
        //Forbid the data correction and allow viewer
        MainFrame.getInstance().fireAppHappend(AppEvent.SELECT_TAB, 6);
    }

    private final void unlearn() {
        //Clear history
        kMeanHistory.clear();
        kMedoidHistory.clear();
        //set appropriate tabs
        MainFrame.getInstance().fireAppHappend(AppEvent.SELECT_TAB, 11);
        //Disable unlearn button and reset state
        bUnlearn.setEnabled(false);
        changeState();
    }

    /**
     * This interface provide the possibility to track the process of model fiting.
     * @param iteration is number of iteration.
     * @param klass is array of classes for each data point.
     * @param nodes is array with coordinates of nodes.
     * @param gof is sum of distances (goodness of fit).
     * @param stepName is name of step
     */
    @Override
    public void callBack(int iteration, int[] klass, double[][] nodes, double gof, String stepName) {
        //Copy klass
        klass = klass.clone();
        //Copy nodes
        nodes = (double[][])Utils.deepCopy(nodes);
        if (minMed == 0)
            kMeanHistory.add(new HistoryPoint(stepName, gof, klass, nodes));
        else
            kMedoidHistory.add(new HistoryPoint(stepName, gof, klass, nodes));
    }

    /**
     * @param e is AppEvent to handle
     */
    public void appHappend(AppEvent e) {
        switch (e.getID()) {
        case AppEvent.CLEAR_ALL:
            {
                eraseAllCentroids();
                break;
            }
        case AppEvent.REQUEST_NONERASABLE:
            {
                MainFrame.getInstance().fireAppHappend(AppEvent.ANSWER_NONARASEBLE, 0,
                                                       nonerasable.toArray(new Point[nonerasable.size()]));
            }
        }
    }

    /**
     * @param e is MouseEvent to handle
     */
    public void mouseEventHandler(MouseEvent e) {
        if (state > 1)
            return;
        //Get coordinates
        int x = e.getX(), y = e.getY();
        //try to find appropriate data point
        Component comp = MainFrame.getData().getComponentAt(x, y);
        if (comp == null || !(comp instanceof DataDot))
            return;
        addCentroid((DataDot)comp);
    }

    protected static class Centroids {
        protected DataDot[] means = new DataDot[MainFrame.getColorCount()];
        protected DataDot[] medoids = new DataDot[MainFrame.getColorCount()];
    }

    protected class HistoryPoint extends AbstractHistoryPoint {
        protected double[][] node = null;
        protected int[] klass = null;

        /**
         * Constructor to create HistoryPoint.
         * @param name is name of point
         * @param gof is goodness of fit for this point
         * @param klass is number of nearest node for each data point
         * @param node is array of coordinates of nodes
         */
        public HistoryPoint(String name, double gof, int[] klass, double[][] node) {
            super(name, gof);
            this.klass = klass;
            this.node = node;
        }
    }
}
