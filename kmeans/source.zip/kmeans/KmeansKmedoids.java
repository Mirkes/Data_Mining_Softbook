package kmeans;


import common.AppEvent;
import common.AppListener;
import common.DataSaveLoad;
import common.MainFrame;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Main class for k-means and k-medoids.
 * 
 *
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class KmeansKmedoids implements AppListener{
    protected static MainFrame frame;
    
    public KmeansKmedoids(){
        super();
        frame = MainFrame.getInstance();
    }

    /**
     * @param args is array of String attributes of the software starting command line.
     */
    public static void main(String[] args) {
        KmeansKmedoids me = new KmeansKmedoids();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Data mining illustration: KMeans & KMedoids");
        frame.addTabPanel("Execution", new Executor());
        frame.addTabPanel("History viewer", new Viewer());
        frame.addTabPanel("Save/Load", new DataSaveLoad());
        frame.addAppListener(me);
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                frame.setVisible(true);
                frame.finalResize();
                frame.fireAppHappend(AppEvent.SELECT_TAB, 9);
            }
        });
    }

    /**
     * @param e is AppEvent to handle
     */
    @Override
    public void appHappend(AppEvent e) {
        if (e.getID()==AppEvent.DATA_CHANGED){
            //Check the number of data points
            if (MainFrame.getData().getComponentCount()==0){
                //there is no data points
                frame.fireAppHappend(AppEvent.SELECT_TAB, 9);
            } else {
                frame.fireAppHappend(AppEvent.SELECT_TAB, 11);
            }
        }
    }
}
