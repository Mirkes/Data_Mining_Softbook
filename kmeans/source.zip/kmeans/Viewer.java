package kmeans;


import common.AddGBL;
import common.DataDot;
import common.History;
import common.MainFrame;
import common.MyMenuPane;
import common.ViewerPanel;

import common.ViewerPanel.ViewerListener;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Point2D;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * Learning history viewer for k-means and k-medoids.
 * 
 * @author Evgeny Mirkes (University of Leicester, UK)
 * Distributed under Creative Commons Attribution license
 */
public class Viewer extends MyMenuPane implements ItemListener, ViewerListener {
    @SuppressWarnings("compatibility:2726061855106648523")
    private static final long serialVersionUID = -2085887111243610486L;

    //History viewer panel
    private ViewerPanel vPanel = new ViewerPanel(Executor.kMeanHistory, "GoF", this);

    //For interface
    private final ButtonGroup bg = new ButtonGroup();

    //For drawing
    // 0 is kMeans only
    // 1 is kMeans and centroids of kMedoids
    // 2 is kMedoids only
    // 3 is kMedoids and centroids of kMeans
    private int who = 0;

    public Viewer() {
        super();
        setLayout(new GridBagLayout());

        Insets ins = new Insets(0, 0, 0, 0);
        AddGBL.setInsets(ins);
        //Add radiobuttons for content
        JRadioButton rb = new JRadioButton("k-means only", true);
        rb.addItemListener(this);
        rb.setActionCommand("0");
        bg.add(rb);
        rb.setMargin(ins);
        rb.setBackground(MainFrame.bkGd);
        AddGBL.addGBL(this, rb, 0, 0, GridBagConstraints.WEST);

        rb = new JRadioButton("k-means (show k-medoids centroids)", true);
        rb.addItemListener(this);
        rb.setActionCommand("1");
        bg.add(rb);
        rb.setMargin(ins);
        rb.setBackground(MainFrame.bkGd);
        AddGBL.addGBL(this, rb, 0, 1, GridBagConstraints.WEST);

        rb = new JRadioButton("k-medoids only", true);
        rb.addItemListener(this);
        rb.setActionCommand("2");
        bg.add(rb);
        rb.setMargin(ins);
        rb.setBackground(MainFrame.bkGd);
        AddGBL.addGBL(this, rb, 0, 2, GridBagConstraints.WEST);

        rb = new JRadioButton("k-medoids (show k-means centroids)", true);
        rb.addItemListener(this);
        rb.setActionCommand("3");
        bg.add(rb);
        rb.setMargin(ins);
        rb.setBackground(MainFrame.bkGd);
        AddGBL.addGBL(this, rb, 0, 3, GridBagConstraints.WEST);

        //Add separator of the first and second parts
        AddGBL.addGBLExp(this, new JSeparator(SwingConstants.VERTICAL), 1, 0, 1, 4, GridBagConstraints.VERTICAL);
        //Add Viewer panel
        AddGBL.addGBLExp(this, vPanel, 2, 0, 1, 4, GridBagConstraints.VERTICAL);


        //restore standard insets
        AddGBL.stdInsets();
    }

    /**
     * @param e is ItemEvent to handle
     */
    @Override
    public void itemStateChanged(ItemEvent e) {
        //Get new selection
        if (e.getStateChange() == e.SELECTED) {
            who = Integer.parseInt(((AbstractButton)e.getItem()).getActionCommand());
            if (who < 2)
                vPanel.setHistory(Executor.kMeanHistory);
            else
                vPanel.setHistory(Executor.kMedoidHistory);
        }
    }

    /**
     * Implementation of ViewerListener interface method to draw HistoryPoint.
     * @param hPoint is HistoryPoint to draw
     * @param step is number of step which is corresponds to HistoryPoint hPoint.
     */
    @Override
    public void drawHistoryPoint(History.AbstractHistoryPoint hPoint, int step) {
        //Get klass and recolour points
        int[] klass = ((Executor.HistoryPoint)hPoint).klass;
        JPanel data = MainFrame.getData();
        int n = data.getComponentCount();
        DataDot d;
        int maxCol = MainFrame.getColorCount() - 1;
        if (klass.length == 0)
            for (int i = 0; i < n; i++) {
                d = (DataDot)data.getComponent(i);
                d.setColor(MainFrame.getColor(0));
            }
        else
            for (int i = 0; i < n; i++) {
                d = (DataDot)data.getComponent(i);
                d.setColor(MainFrame.getColor(maxCol - klass[i]));
            }
        //Get nodes and repositioning its
        double[][] nodes;
        Point p = new Point(-100, -100);
        //Get main nodes
        double[][] node = ((Executor.HistoryPoint)hPoint).node;
        int k = node.length;
        for (int i = 0; i < k; i++) {
            Executor.centr.means[i].setPos(p);
            Executor.centr.medoids[i].setPos(p);
        }
        switch (who) {
        case 1:
            {
                //Medoids for main means
                nodes = ((Executor.HistoryPoint)Executor.kMedoidHistory.get(step)).node;
                for (int i = 0; i < k; i++)
                    Executor.centr.medoids[i].setPos(new Point2D.Double(nodes[i][0], nodes[i][1]));
            }
        case 0:
            {
                //Means
                for (int i = 0; i < k; i++)
                    Executor.centr.means[i].setPos(new Point2D.Double(node[i][0], node[i][1]));
                break;
            }
        case 3:
            {
                //Means for main medoids
                nodes = ((Executor.HistoryPoint)Executor.kMeanHistory.get(step)).node;
                for (int i = 0; i < k; i++)
                    Executor.centr.means[i].setPos(new Point2D.Double(nodes[i][0], nodes[i][1]));
            }
        case 2:
            {
                //Medoids
                for (int i = 0; i < k; i++)
                    Executor.centr.medoids[i].setPos(new Point2D.Double(node[i][0], node[i][1]));
                break;
            }
        }
        MainFrame.getBody().repaint();
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentShown(ComponentEvent e) {
        vPanel.renew();
    }

    /**
     * @param e event to handle
     */
    @Override
    public void componentHidden(ComponentEvent e) {
        //Check for nonempty history
        if (Executor.kMedoidHistory.get(0)==null)
            return;
        //Get klass and recolour points
        JPanel data = MainFrame.getData();
        int n = data.getComponentCount();
        DataDot d;
        for (int i = 0; i < n; i++) {
            d = (DataDot)data.getComponent(i);
            d.setColor(MainFrame.getColor(0));
        }
        //Get nodes and repositioning its
        double[][] nodes;
        //Medoids
        nodes = ((Executor.HistoryPoint)Executor.kMedoidHistory.get(0)).node;
        int k = nodes.length;
        for (int i = 0; i < k; i++)
            Executor.centr.medoids[i].setPos(new Point2D.Double(nodes[i][0], nodes[i][1]));
        //Means for main medoids
        nodes = ((Executor.HistoryPoint)Executor.kMeanHistory.get(0)).node;
        for (int i = 0; i < k; i++)
            Executor.centr.means[i].setPos(new Point2D.Double(nodes[i][0], nodes[i][1]));
        MainFrame.getBody().repaint();
    }
}
